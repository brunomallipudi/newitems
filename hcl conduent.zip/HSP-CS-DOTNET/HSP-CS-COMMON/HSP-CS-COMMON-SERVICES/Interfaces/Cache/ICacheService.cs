﻿using HSP_CS_COMMON_CORE.RequestHandling;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_HELPERS.Caching;
using System;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Interfaces.Cache
{

    /// <summary>
    /// MemoryCache Interface
    /// </summary>
    public interface ICacheService
    {
        /// <summary>
        /// Gets or Sets a Cache Entry
        /// </summary>
        /// <typeparam name="T1">
        ///     Refers to the Type
        ///     - Returned by this method
        ///     - Provided by the delegate method in the calling service.
        /// </typeparam>
        /// <param name="request"></param>
        /// <param name="repositoryCall">Delegate method</param>
        /// <param name="cacheKeyTag">Unique Identifier for the Cache</param>
        /// <returns>T1</returns>
        Task<(T, T1)> GetOrSetCachedItem<T, U, T1>(
            ICacheRequest request, Func<ICacheRequest, Task<(T, T1)>> repositoryCall, string cacheKeytag, CacheExpiryOption expiryOption) 
            where T : HSPDbResult<U>
            where U : HSPStatusRow;
    }
}
