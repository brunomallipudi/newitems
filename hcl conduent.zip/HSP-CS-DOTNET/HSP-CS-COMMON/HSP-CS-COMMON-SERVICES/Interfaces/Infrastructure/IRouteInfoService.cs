﻿using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.Infrastructure;
using System.Collections.Generic;
using System.Reflection;

namespace HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure
{
    /// <summary>
    /// RouteInfo Service
    /// 
    /// Responsible for returning route info
    /// </summary>
    public interface IRouteInfoService
    {
        /// <summary>
        /// Get Actions grouped by Controller.
        /// </summary>
        /// <param name="callingAssembly"></param>
        /// <returns></returns>
        List<ControllerInfo> GetControllers(Assembly callingAssembly);

        /// <summary>
        /// Get Controller Actions
        /// </summary>
        /// <param name="callingAssembly"></param>
        /// <returns></returns>
        List<ActionInfo> GetActions(Assembly callingAssembly);
    }
}