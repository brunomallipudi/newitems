﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Permissions;
using HSP_CS_COMMON_ENTITIES.Infrastructure;
using HSP_CS_COMMON_SERVICES.Request.Permissions;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Interfaces.Permissions
{
    public interface IPermissionsService
    {
        /// <summary>
        /// Gets the list of permissions for a user via
        ///  - UserId
        ///     If a UserId is present, the SessionId is ignored
        ///  - SessionId
        ///  - Usage
        ///         Defaults to USAGE1
        ///         Options
        ///             - USAGE1 => Allowed permissions
        ///             - USAGE2 => Not Allowed permissions
        ///             - USAGE3 => USAGE1 + USAGE 2
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="cacheKeyTag">
        ///     Unique Identifier for the Cache KVP
        /// </param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserPermission> results)> GetPermissionsAsync(GetPermissionsRequest parameters, string cacheKeyTag);

        /// <summary>
        /// Get ALL HSP permissions
        /// </summary>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<Permission> results)> GetPermissionsAsync();

        /// <summary>
        /// Map Controllers/Methods to the Permissions table
        /// and returns a list of not mapped permissions
        /// </summary>
        /// <param name="assembly"></param>
        IEnumerable<ActionInfo> GetMissingPermissionMappings(Assembly assembly);

        /// <summary>
        /// Map Controllers/Methods to the Permissions table
        /// Returns full list grouped by controller
        /// </summary>
        /// <param name="assembly"></param>
        IEnumerable<ControllerInfo> GetRouteInfo(Assembly assembly);

        /// <summary>
        /// Checks whether a user has a permission assigned to a role
        /// Must not be called async.
        /// </summary>
        /// <param name="AppName">Product Name | AppName</param>
        /// <param name="sessionId">HSP SessionId</param>
        /// <param name="usage">USAGE1|USAGE3</param>
        /// <param name="cacheKeyTag">PERMS</param>
        /// <param name="entityType">Controller</param>
        /// <param name="permissionName">Method</param>
        /// <returns>Whether the user has permission or not</returns>
        bool HasPermission(string AppName, int sessionId, string usage, string cacheKeyTag, string entityType, string permissionName);


        bool MapMissingPermissions(Assembly assembly);
        
    }
}
