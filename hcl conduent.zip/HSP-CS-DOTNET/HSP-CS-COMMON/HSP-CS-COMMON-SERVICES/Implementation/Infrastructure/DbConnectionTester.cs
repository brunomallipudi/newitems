﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Implementation.Infrastructure
{
    /// <summary>
    /// Connection Tester
    ///
    /// Contains method(s) that test the database connectivity
    /// </summary>
    public class DbConnectionTester : IDbConnectionTester
    {
        private readonly IDbConnectionString _dbConnectionString;
        private readonly ILogger<DbConnectionTester> _logger;

        public DbConnectionTester(IDbConnectionString connectionStrings, ILogger<DbConnectionTester> logger)
        {
            _dbConnectionString = connectionStrings;
            _logger = logger;
        }

        public async Task<(bool, string)> DbConnectTest()
        {
            bool isConnected = false;
            string message = string.Empty;

            using (SqlConnection connection = new SqlConnection(_dbConnectionString.DefaultConnectionString))
            {
                try
                {
                    await connection.OpenAsync();
                    isConnected = true;
                }
                catch (Exception exception)
                {
                    _logger.LogError(exception, $"Exception in {nameof(DbConnectionTester)}.");
                    message = exception.Message;
                }
                finally
                {
                    if (connection.State == ConnectionState.Open)
                        await connection.CloseAsync();
                }
            }
            return (isConnected, message);
        }
    }
}