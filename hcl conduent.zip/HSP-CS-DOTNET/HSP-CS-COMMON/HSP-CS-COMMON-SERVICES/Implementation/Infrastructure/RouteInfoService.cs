﻿using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.Infrastructure;
using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace HSP_CS_COMMON_SERVICES.Implementation.Infrastructure
{
    /// <summary>
    /// RouteInfo Service
    /// 
    /// Responsible for returning route info
    /// </summary>
    public class RouteInfoService : IRouteInfoService
    {

        /// <summary>
        /// Get Controller Actions
        /// </summary>
        /// <param name="callingAssembly"></param>
        /// <returns></returns>
        public List<ActionInfo> GetActions(Assembly callingAssembly)
            => GetRouteInfo(callingAssembly);


        /// <summary>
        /// Get Actions grouped by Controller.
        /// </summary>
        /// <param name="callingAssembly"></param>
        /// <returns></returns>
        public List<ControllerInfo> GetControllers(Assembly callingAssembly)
            => GetRouteInfo(callingAssembly)
                .GroupBy(
                      x => x.ControllerName, (ctrl) =>
                          new ActionInfo
                          {
                              ControllerName = ctrl.ControllerName,
                              ActionName = ctrl.ActionName,
                              Attributes = ctrl.Attributes
                          }
                 )
                .Select(
                      x =>
                          new ControllerInfo
                          {
                              ControllerName = x.Key,
                              Actions = x.ToList()
                          }
                ).ToList();

        /// <summary>
        /// Analyzed a WebAPI assembly and returns controllers & actions
        /// </summary>
        /// <param name="callingAssembly"></param>
        /// <param name="permissions"></param>
        /// <returns></returns>
        private List<ActionInfo> GetRouteInfo(Assembly callingAssembly)
        {
            var routeInfo =
                callingAssembly.GetTypes()
                    // Get Controllers
                    .Where(type => typeof(ControllerBase).IsAssignableFrom(type))
                    // Get Methods
                    .SelectMany
                    (
                        type =>
                            type.GetMethods(
                                BindingFlags.Instance // Only items that can be instantiated
                                | BindingFlags.DeclaredOnly // Only declared; no inheritaned items
                                | BindingFlags.Public
                            )
                    )
                    // No compiler generated stuff
                    .Where(m => !m.GetCustomAttributes(typeof(CompilerGeneratedAttribute), true).Any())
                    .Select(
                        x => new ActionInfo
                        {
                            ControllerName = x.DeclaringType.Name.Replace("Controller", ""),
                            ActionName = x.Name,
                            Attributes =
                                x.GetCustomAttributes()
                                    .Select(a => a.GetType().Name.Replace("Attribute", ""))
                        }
                    ).ToList();

            return routeInfo;
        }
    }
}