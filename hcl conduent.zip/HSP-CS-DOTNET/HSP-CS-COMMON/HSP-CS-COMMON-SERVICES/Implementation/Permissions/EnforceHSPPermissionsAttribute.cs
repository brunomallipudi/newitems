﻿using HSP_CS_COMMON_SERVICES.Interfaces.Permissions;
using HSP_CS_COMMON_SERVICES.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using System.Net;

namespace HSP_CS_COMMON_SERVICES.Implementation.Permissions
{
    /// <summary>
    /// Enforcing HSP Permissions with filter
    /// 
    /// Attribute cannot reside in the CORE project as it
    /// requires reference to the IPermissionsService interface.
    /// 
    /// Since this project already has a dependency to the CORE
    /// project, we cannot add this to the core - cyclic dependency.
    /// </summary>
    public class EnforceHSPPermissionsAttribute
        : Attribute, IActionFilter
    {
        private readonly string entityType;
        private readonly string permissionName;

        public EnforceHSPPermissionsAttribute(string entityType = null, string permissionName = null)
        {
            this.entityType = entityType;
            this.permissionName = permissionName;
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
        }

        /// <summary>
        /// Check whether a sessionId (user) has the permission mapped
        /// to an assigned role.
        /// </summary>
        /// <param name="context"></param>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            var service =
                context.HttpContext
                    .RequestServices
                    .GetService<IPermissionsService>();

            var configuration =
                context.HttpContext
                    .RequestServices
                    .GetService<IConfiguration>();

            var routeValues = context.HttpContext.Request.RouteValues;
            var controller = routeValues["controller"];
            var method = routeValues["action"];

            //  There is an issue with the JSON content-type headers
            //  and .net core 5. This resolves any issues.
            var body =
                context.ActionArguments
                    .ToList()
                    .FirstOrDefault();

            var sessionId = ((BaseRequest)body.Value).SessionId;

            //  this needs to be called synchronously.
            //  the list of permissions could exist in cache.
            var hasPermission =
                service.HasPermission
                (
                    //  in the future this needs to be provided by the applications
                    configuration["HSPSessionManagement:AppName"],
                    sessionId,
                    "USAGE1",
                    "PERMS",
                    entityType: entityType ?? controller.ToString(),
                    permissionName: permissionName ?? method.ToString()
                );

            //  This overrides the response headers and forces the application
            //  to skip the method call.
            if (!hasPermission)
            {
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                context.Result =
                    new JsonResult
                    (
                        new
                        {
                            Status = HttpStatusCode.Unauthorized,
                            ErrorMessage = "Insufficient HSP Permissions to execute action."
                        }
                    );
            }
        }
    }
}