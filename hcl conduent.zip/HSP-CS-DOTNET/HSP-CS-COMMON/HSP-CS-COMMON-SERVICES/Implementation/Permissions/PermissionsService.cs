﻿using HSP_CS_COMMON_CORE.RequestHandling;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Permissions;
using HSP_CS_COMMON_ENTITIES.Infrastructure;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Interfaces.Cache;
using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using HSP_CS_COMMON_SERVICES.Interfaces.Permissions;
using HSP_CS_COMMON_SERVICES.Request.Permissions;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Implementation.Permissions
{
    /// <summary>
    /// Permissions Service
    /// </summary>
    public class PermissionsService
        : IPermissionsService
    {
        #region Properties

        private readonly IPermissionsRepository _permissionsRepository;
        private readonly ICacheService _cacheService;
        private readonly IRouteInfoService _routeInfoService;

        #endregion Properties

        #region Constructors

        public PermissionsService(IPermissionsRepository permissionsRepository, ICacheService cacheService, IRouteInfoService routeInfoService)
        {
            _permissionsRepository = permissionsRepository;
            _cacheService = cacheService;
            _routeInfoService = routeInfoService;
        }

        #endregion Constructors

        /// <summary>
        /// Gets the list of permissions for a user via
        ///  - UserId
        ///     If a UserId is present, the SessionId is ignored
        ///  - SessionId
        ///  - Usage
        ///         Defaults to USAGE1
        ///         Options
        ///             - USAGE1 => Allowed permissions
        ///             - USAGE2 => Not Allowed permissions
        ///             - USAGE3 => USAGE1 + USAGE 2
        /// </summary>
        /// <param name="parameters"></param>
        /// <param name="cacheKeyTag">
        ///     Unique Identifier for the Cache KVP
        /// </param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserPermission> results)> GetPermissionsAsync(GetPermissionsRequest request, string cacheKeyTag)
        {
            var permissions =
                await _cacheService
                    .GetOrSetCachedItem<HSPDbResult<HSPSearchStatusRow>, HSPSearchStatusRow, IEnumerable<UserPermission>>
                    (
                        request,
                        RepositoryCall, // FUN FUN FUN
                        cacheKeyTag
                        , default
                    // , CacheExpiryOption.Low
                    );

            return permissions;
        }

        /// <summary>
        /// Delegate
        ///
        /// To be passed to the Cache Service
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private async Task<(HSPDbResult<HSPSearchStatusRow>, IEnumerable<UserPermission>)> RepositoryCall(ICacheRequest cacheRequest)
        {
            var request = (GetPermissionsRequest)cacheRequest;
            var repoRequest = new HSP_CS_COMMON_REPOSITORIES.Request.Permissions.GetPermissionsRequest
            {
                SessionId = request.SessionId,
                UserId = request.UserId,
                ProductName = request.ProductName,
                Usage = request.Usage
            };
            return await _permissionsRepository.GetPermissionsAsync(repoRequest);
        }

        /// <summary>
        /// Checks whether a user has a permission assigned to a role
        ///
        /// The response could be cached.
        /// </summary>
        /// <param name="AppName">Product Name | AppName</param>
        /// <param name="sessionId">HSP SessionId</param>
        /// <param name="usage">USAGE1|USAGE3</param>
        /// <param name="cacheKeyTag">PERMS</param>
        /// <param name="entityType">Controller</param>
        /// <param name="permissionName">Method</param>
        /// <returns>Whether the user has permission or not</returns>
        public bool HasPermission(string AppName, int sessionId, string usage, string cacheKeyTag, string entityType, string permissionName)
        {
            var permissions =
                GetPermissionsAsync
                (
                    new GetPermissionsRequest
                    {
                        ProductName = AppName,
                        SessionId = sessionId,
                        Usage = usage
                    },
                    cacheKeyTag
                ).Result;

            var perm =
                permissions.results
                    .Where
                    (
                        x =>
                            x.EntityType == entityType
                            && x.PermissionName == permissionName
                            && x.HasPermission // For USAGE1|USAGE3; USAGE2 will always be false
                    ).FirstOrDefault();

            return perm != null;
        }

        /// <summary>
        /// Get ALL HSP Permissions
        /// </summary>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<Permission> results)> GetPermissionsAsync()
            => await _permissionsRepository.GetPermissionsAsync();

        /// <summary>
        /// Returns missing permission mappings
        /// </summary>
        /// <param name="assembly">the calling assembly</param>
        public IEnumerable<ActionInfo> GetMissingPermissionMappings(Assembly assembly)
        {
            var permissions =
                GetPermissionsAsync()
                .ConfigureAwait(false)
                .GetAwaiter()
                .GetResult()
                .results;

            var actions =
                _routeInfoService
                    .GetActions(assembly);

            actions.ForEach
                (
                    x =>
                    {
                        if (x.EnforcesHspPermissions)
                        {
                            var perm =
                                permissions
                                    .Where(p => p.EntityType == x.ControllerName && p.PermissionName == x.ActionName)
                                    .FirstOrDefault();

                            x.IsMappingRequired = true;

                            if (perm != null)
                            {
                                x.Permission = perm;
                                x.IsMappingRequired = false;
                            }
                        }
                    }
                );

            return
                actions.Where
                (
                    x => x.IsMappingMissing
                );
        }

        /// <summary>
        /// Gets Route Info grouped by controller
        /// </summary>
        /// <param name="assembly"></param>
        /// <returns></returns>
        public IEnumerable<ControllerInfo> GetRouteInfo(Assembly assembly)
        {
            var permissions =
                GetPermissionsAsync()
                .ConfigureAwait(false)
                .GetAwaiter()
                .GetResult()
                .results;

            var controlers =
                _routeInfoService
                    .GetControllers(assembly);

            controlers
                .Where(x => x.EnforcesHspPermissions)
                .SelectMany(x => x.Actions).ToList()
                .ForEach
                (
                    x =>
                    {
                        if (x.EnforcesHspPermissions)
                        {
                            var perm =
                                permissions
                                    .Where(p => p.EntityType == x.ControllerName && p.PermissionName == x.ActionName)
                                    .FirstOrDefault();

                            x.IsMappingRequired = true;

                            if (perm != null)
                            {
                                x.Permission = perm;
                                x.IsMappingRequired = false;
                            }
                        }
                    }
                );

            return controlers;
        }

        public bool MapMissingPermissions(Assembly assembly)
            => throw new System.NotImplementedException();
    }
}