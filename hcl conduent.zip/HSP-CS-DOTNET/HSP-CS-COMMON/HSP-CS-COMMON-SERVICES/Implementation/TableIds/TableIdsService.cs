﻿using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Interfaces.TableIds;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Implementation.TableIds
{
    /// <summary>
    /// TableIds Service - dbo.Ids
    ///
    /// Responsible for creating/updating new PrimaryKey values for the
    /// tables, identified by a unique key.
    /// </summary>
    public class TableIdsService : ITableIdsService
    {
        private readonly ITableIdsRepository _tableIdsRepository;

        public TableIdsService(ITableIdsRepository tableIdsRepository)
            => _tableIdsRepository = tableIdsRepository;

        /// <summary>
        /// Creates a new entry or updates an existing entry
        /// to get a new primary key.
        ///
        /// This exists because the tables have Primary Keys, but no identities.
        /// </summary>
        /// <param name="IdType"></param>
        /// <returns>Int32 - new PKey</returns>
        public async Task<int> GetNewId(string IdType)
            => await _tableIdsRepository.GetNewIdAsync(IdType);
    }
}