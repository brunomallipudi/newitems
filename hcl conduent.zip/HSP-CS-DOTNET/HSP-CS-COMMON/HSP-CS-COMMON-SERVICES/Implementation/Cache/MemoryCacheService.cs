﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.RequestHandling;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_HELPERS.Caching;
using HSP_CS_COMMON_SERVICES.Interfaces.Cache;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Implementation.Cache
{
    /// <summary>
    /// MemoryCache Service
    ///
    /// Handles In-Memory Caching.
    /// </summary>
    public class MemoryCacheService : ICacheService
    {
        private readonly IMemoryCache _memoryCache;
        private readonly IConfiguration _config;

        /// <summary>
        /// We utilize this dictionary to ensure that
        /// only 1 thread will be running for a specific request
        /// </summary>
        private ConcurrentDictionary<object, SemaphoreSlim> _locks
            = new ConcurrentDictionary<object, SemaphoreSlim>();

        public MemoryCacheService(IMemoryCache memoryCache, IConfiguration config)
        {
            _memoryCache = memoryCache;
            _config = config;
        }

        /// <summary>
        /// Gets or Sets a Cache Entry
        ///
        /// This process will always add a cached item, and return it.
        /// </summary>
        /// <typeparam name="T1">
        ///     Refers to the Type
        ///     - Returned by this method
        ///     - Provided by the delegate method in the calling service.
        /// </typeparam>
        /// <param name="request"></param>
        /// <param name="repositoryCall">Delegate method</param>
        /// <param name="cacheKeyTag">Unique Identifier for the Cache</param>
        /// <returns>T1</returns>
        public async Task<(T, T1)> GetOrSetCachedItem<T, U, T1>(
            ICacheRequest request, Func<ICacheRequest, Task<(T, T1)>> repositoryCall, string cacheKeyTag, CacheExpiryOption expiryOption = CacheExpiryOption.Default)
            where T : HSPDbResult<U>
            where U : HSPStatusRow
        {
            var cachedItem = string.Empty;
            var keyTag = request.KeyTag(cacheKeyTag);

            //  Check the Cache for an existing entry
            //  keyTag => unique identifier
            if (!_memoryCache.TryGetValue(keyTag, out cachedItem))
            {
                //  Ensure that only 1 thread runs for a specific request
                var mylock = _locks.GetOrAdd(keyTag, k => new SemaphoreSlim(1, 1));
                await mylock.WaitAsync();

                try
                {
                    if (!_memoryCache.TryGetValue(keyTag, out cachedItem))
                    {
                        //  Delegate call
                        //  This enables us to call any method and cache the response.
                        var result = await repositoryCall(request);
                        var status = result.Item1;
                        if (status.DbStatus == HSPDbStatus.Normal && status.StatusRow.Success)
                        {
                            var expiry = CachingServiceHelper.GetExpiry(cacheKeyTag, expiryOption);
                            var cacheEntryOptions = new MemoryCacheEntryOptions()
                                .SetPriority(CacheItemPriority.Normal)
                                .SetSlidingExpiration(TimeSpan.FromSeconds(expiry.SlidingExpiration))
                                .SetAbsoluteExpiration(TimeSpan.FromSeconds(expiry.AbsoluteExpiration));

                            status.StatusRow.IsCached = true;
                            cachedItem = JsonConvert.SerializeObject(result);
                            //  Add a JSON object to the cache
                            _memoryCache.Set
                            (
                                keyTag, // unique identifier
                                cachedItem,
                                cacheEntryOptions
                            );
                        }
                        else
                        {
                            return result;
                        }
                    }
                }
                finally
                {
                    mylock.Release();
                }
            }

            //  return to the service what was expected
            return JsonConvert.DeserializeObject<(T, T1)>(cachedItem);
        }
    }
}