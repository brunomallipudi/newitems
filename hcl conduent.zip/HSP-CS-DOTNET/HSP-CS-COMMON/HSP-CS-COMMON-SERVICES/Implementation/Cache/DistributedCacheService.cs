﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.RequestHandling;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_HELPERS.Caching;
using HSP_CS_COMMON_SERVICES.Interfaces.Cache;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Implementation.Cache
{
    /// <summary>
    /// DistributedMemoryCache Service
    ///
    /// Handles Distributed Memory Caching.
    /// </summary>
    public class DistributedCacheService : ICacheService
    {
        private readonly IDistributedCache _memoryCache;
        private readonly IConfiguration _config;

        /// <summary>
        /// We utilize this dictionary to ensure that
        /// only 1 thread will be running for a specific request
        /// </summary>
        private ConcurrentDictionary<object, SemaphoreSlim> _locks
            = new ConcurrentDictionary<object, SemaphoreSlim>();

        public DistributedCacheService(IDistributedCache memoryCache, IConfiguration config)
        {
            _memoryCache = memoryCache;
            _config = config;
        }

        /// <summary>
        /// Gets or Sets a Cache Entry
        ///
        /// This process will always add a cached item, and return it.
        /// </summary>
        /// <typeparam name="T1">
        ///     Refers to the Type
        ///     - Returned by this method
        ///     - Provided by the delegate method in the calling service.
        /// </typeparam>
        /// <param name="request"></param>
        /// <param name="repositoryCall">Delegate method</param>
        /// <param name="cacheKeyTag">Unique Identifier for the Cache</param>
        /// <returns>T1</returns>
        public async Task<(T, T1)> GetOrSetCachedItem<T, U, T1>(
            ICacheRequest request, Func<ICacheRequest, Task<(T, T1)>> repositoryCall, string cacheKeyTag, CacheExpiryOption expiryOption = CacheExpiryOption.Default)
            where T : HSPDbResult<U>
            where U : HSPStatusRow
        {
            var keyTag = request.KeyTag(cacheKeyTag);
            string cachedItem = string.Empty;

            var useCache = _config.GetValue<bool>($"MemoryCache:UseCache");

            if (useCache) // this should be from a singleton not the config.
            {
                try
                {
                    // throws Exception; handled below.
                    cachedItem = await GetCacheItem(keyTag);

                    if (string.IsNullOrEmpty(cachedItem))
                    {
                        var mylock = _locks.GetOrAdd(keyTag, k => new SemaphoreSlim(1, 1));
                        await mylock.WaitAsync();

                        try
                        {
                            cachedItem = await GetCacheItem(keyTag);
                            if (string.IsNullOrEmpty(cachedItem))
                            {
                                //  Delegate call
                                //  This enables us to call any method and cache the response.
                                var result = await repositoryCall(request);
                                var status = result.Item1;
                                if (status.DbStatus == HSPDbStatus.Normal && status.StatusRow.Success) {
                                    var expiry = CachingServiceHelper.GetExpiry(cacheKeyTag, expiryOption);
                                    var cacheEntryOptions = new DistributedCacheEntryOptions()
                                        .SetSlidingExpiration(TimeSpan.FromSeconds(expiry.SlidingExpiration))
                                        .SetAbsoluteExpiration(TimeSpan.FromSeconds(expiry.AbsoluteExpiration));

                                    status.StatusRow.IsCached = true;
                                    cachedItem = JsonConvert.SerializeObject(result);

                                    //  Add a JSON object to the cache
                                    await _memoryCache.SetStringAsync
                                    (
                                        keyTag, // unique identifier
                                        cachedItem,
                                        cacheEntryOptions
                                    );
                                } 
                                else
                                {
                                    return result;
                                }
                            }
                        }
                        finally
                        {
                            mylock.Release();
                        }
                    }
                }
                // Handling Redis|SQL ConnectionTimeout here.
                catch (Exception)
                {
                    var result = await repositoryCall(request);
                    cachedItem = JsonConvert.SerializeObject(result);

                    // We also need a Singleton to hold cache status
                    // this would update the UseCache option to false
                    // so we do not wait for the timeout every time.
                }
            }
            else
            {
                var result = await repositoryCall(request);
                cachedItem = JsonConvert.SerializeObject(result);
            }
            return JsonConvert.DeserializeObject<(T, T1)>(cachedItem);
        }

        private async Task<string> GetCacheItem(string keyTag)
            => await _memoryCache.GetStringAsync(keyTag) ?? string.Empty;
    }
}