﻿using HSP_CS_COMMON_SERVICES.Interfaces.Security;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;

namespace HSP_CS_COMMON_SERVICES.Implementation.Security
{
    /// <summary>
    /// AES Cryptography Service
    /// FIPS 140-2 Valid
    /// </summary>
    /// <remarks>
    /// https://www.seguetech.com/fips-140-2-how-used-federal-government-dod/
    /// https://csrc.nist.gov/csrc/media/publications/fips/140/2/final/documents/fips1402.pdf
    /// https://docs.microsoft.com/en-us/dotnet/standard/security/encrypting-data
    ///
    /// According to the above documentation and some Google research
    /// C# has 3 encryption providers that "support" AES: 
    ///     RijndaelManaged, 
    ///     AesManaged, 
    ///     AesCryptoServiceProvider.
    /// 
    /// RijndaelManaged implements the full Rijnadael Algorithm(All Options) and so it is a super-set of AES capabilities; 
    /// it is not certified FIPS compliant
    /// 
    /// AesManaged is nothing more than a decorator/wrapper over RijndaelManaged that restrict it to a block-size of 128 bits
    /// but, because RijndaelManaged is not FIPS approved, neither is AesManaged
    ///
    /// AesCryptoServiceProvider is a C# wrapper over the C-library on Windows for AES that IS FIPS approved; 
    /// 
    /// Need to test with FIPS enabled.
    /// </remarks>
    public class AESCryptographyService
        : ICryptography
    {
        #region Properties

        private readonly IConfiguration _configuration;

        private int SALT_SIZE;
        private int AES_KEY_SIZE;

        #endregion Properties

        #region Constructors

        public AESCryptographyService(IConfiguration config)
        {
            _configuration = config;
            SALT_SIZE = _configuration.GetValue<int>("Cryptography:SALT_SIZE");
            AES_KEY_SIZE = _configuration.GetValue<int>("Cryptography:AES_KEY_SIZE");
        }

        #endregion Constructors

        /// <summary>
        /// Encrypt plain text with a key
        /// </summary>
        /// <param name="plainText">Plain text to encrypt</param>
        /// <param name="key">Encryption key</param>
        /// <returns>Encrypted string</returns>
        public string Encrypt(string plainText, string key)
        {
            if (string.IsNullOrEmpty(plainText))
                throw new ArgumentException("Cannot encrypt empty strings.");
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Encryption key is required");

            var keyDerivationFunction = new Rfc2898DeriveBytes(key, SALT_SIZE);
            byte[] saltBytes = keyDerivationFunction.Salt;
            byte[] keyBytes = keyDerivationFunction.GetBytes(32);
            byte[] ivBytes = keyDerivationFunction.GetBytes(16);

            using (var csp = new AesCryptoServiceProvider())
            {
                csp.KeySize = AES_KEY_SIZE;
                using (var encryptor = csp.CreateEncryptor(keyBytes, ivBytes))
                {
                    MemoryStream memoryStream = null;
                    CryptoStream cryptoStream = null;

                    try
                    {
                        memoryStream = new MemoryStream { };
                        try
                        {
                            cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
                            using (var streamWriter = new StreamWriter(cryptoStream))
                                streamWriter.Write(plainText);
                        }
                        finally
                        {
                            // Cleaning up
                            if (cryptoStream != null)
                                cryptoStream.Dispose();
                        }

                        var cipherTextBytes = memoryStream.ToArray();
                        Array.Resize(ref saltBytes, saltBytes.Length + cipherTextBytes.Length);
                        Array.Copy(cipherTextBytes, 0, saltBytes, SALT_SIZE, cipherTextBytes.Length);

                        return Convert.ToBase64String(saltBytes);
                    }
                    finally
                    {
                        // Cleaning up
                        if (memoryStream != null)
                            memoryStream.Dispose();
                    }
                }
            } // AESManaged
        }

        /// <summary>
        /// Decrypt a cipher with a key
        /// </summary>
        /// <param name="cipher">Encrypted cipher</param>
        /// <param name="key">Encryption key</param>
        /// <returns>Decrypted string</returns>
        public string Decrypt(string cipher, string key)
        {
            if (string.IsNullOrEmpty(cipher))
                throw new ArgumentException("Cannot decrypt empty strings.");
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException("Decryption key is required.");

            var allTheBytes = Convert.FromBase64String(cipher);
            var saltBytes = allTheBytes.Take(SALT_SIZE).ToArray();

            var ciphertextBytes =
                allTheBytes
                    .Skip(SALT_SIZE)
                    .Take(allTheBytes.Length - SALT_SIZE)
                    .ToArray();

            var keyDerivationFunction = new Rfc2898DeriveBytes(key, saltBytes);

            var keyBytes = keyDerivationFunction.GetBytes(32);
            var ivBytes = keyDerivationFunction.GetBytes(16);

            using (var csp = new AesCryptoServiceProvider())
            {
                using (var decryptor = csp.CreateDecryptor(keyBytes, ivBytes))
                {
                    MemoryStream memoryStream = null;
                    CryptoStream cryptoStream = null;

                    try
                    {
                        memoryStream = new MemoryStream(ciphertextBytes);
                        cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);

                        using (var streamReader = new StreamReader(cryptoStream))
                            return streamReader.ReadToEnd();
                    }
                    catch (CryptographicException)
                    {
                        throw new CryptographicException("Wrong [en/de]cryption key.");
                    }
                    finally
                    {
                        if (memoryStream != null)
                            memoryStream.Dispose();
                    }
                }
            }
        }
    }
}