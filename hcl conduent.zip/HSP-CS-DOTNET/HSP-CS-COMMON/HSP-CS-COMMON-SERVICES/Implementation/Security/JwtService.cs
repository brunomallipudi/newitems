﻿using HSP_CS_COMMON_SERVICES.Interfaces.Security;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace HSP_CS_COMMON_SERVICES.Implementation.Security
{
    public class JwtService : IJwtService
    {
        #region Properties

        private readonly IConfiguration _configuration;

        #endregion Properties

        #region Constructors

        public JwtService(IConfiguration config)
        {
            _configuration = config;
        }

        #endregion Constructors

        #region Private methods

        /// <summary>
        /// Get signing credentials for the token.
        /// </summary>
        /// <returns>SigningCredentials</returns>
        private SigningCredentials GetCredentials() =>
            new SigningCredentials
                (
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration.GetValue<string>("IssuerKey"))),
                    SecurityAlgorithms.HmacSha256

                );

        #endregion Private methods

        /// <summary>
        /// Creates a JSON Web Token
        /// </summary>
        /// <param name="claims">
        ///     Claims to be included with the token.
        ///
        ///     Note that all claims are visible and must not contain
        ///     any data that can compromise the user/system.
        /// </param>
        /// <param name="expirationDateTime">
        ///     Expiration DateTime
        /// </param>
        /// <returns>Signed JSON Web Token</returns>
        public JwtSecurityToken Create(List<Claim> claims, DateTime expirationDateTime)
            => new JwtSecurityToken
                (
                    _configuration.GetValue<string>("Issuer"),
                    _configuration.GetValue<string>("Audience"),
                    claims,
                    expires: expirationDateTime,
                    signingCredentials: GetCredentials()
                );

        /// <summary>
        /// Issues the JSON Web Token for consumption.
        /// </summary>
        /// <param name="claims">
        ///     Claims to be included with the token.
        /// </param>
        /// <param name="expirationDateTime">
        ///     Expiration DateTime
        /// </param>
        /// <returns>String version of the token for the web application.</returns>
        public string Issue(List<Claim> claims, DateTime expirationDateTime)
            => new JwtSecurityTokenHandler()
                     .WriteToken(Create(claims, expirationDateTime));
    }
}