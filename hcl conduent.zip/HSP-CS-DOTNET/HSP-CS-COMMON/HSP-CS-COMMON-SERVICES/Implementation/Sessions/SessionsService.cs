﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Implementation;
using HSP_CS_COMMON_ENTITIES.DTO.Sessions;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Interfaces.Sessions;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_SERVICES.Implementation.Sessions
{
    /// <summary>
    /// Session Service
    ///
    /// Responsible for handling the database sessions
    /// </summary>
    public class SessionsService : ISessionsService
    {
        private readonly ISessionsRepository _sessionsRepository;

        public SessionsService(ISessionsRepository sessionsRepository)
           => _sessionsRepository = sessionsRepository;

        /// <summary>
        /// Connects a logged on user to the database and provides a SessionId
        /// </summary>
        /// <remarks>
        /// We will not be implementing automatic user disconnect here.
        /// The Web UI is responsible for handling the flow.
        ///
        /// Attempting to force disconnection on a non existing or already disconnerted
        /// session will result in Success being false.
        /// </remarks>
        /// <param name="username">Logged on username</param>
        /// <param name="disconnectOldSession">Whether to disconnect an existing session.</param>
        /// <returns></returns>
        public async Task<(HSPDbResult<SessionStatusRow> StatusRow, IEnumerable<ExistingSessionDto> results)> ConnectUserAsync(string username, bool disconnectOldSession, string webSessionId)
            => await _sessionsRepository.ConnectUserAsync(username, disconnectOldSession, webSessionId);

        /// <summary>
        /// Disconnects/Invalidates an existing session
        /// </summary>
        /// <param name="sessionId">SessionId to disconnect</param>
        /// <returns>bool</returns>
        public async Task<bool> DisconnectUserAsync(int sessionId, string webSessionId = null)
            => await _sessionsRepository.DisconnectUserAsync(sessionId, webSessionId);

        public async Task<(string AppVersion, string DbAppVersion, bool IsCompatible)> GetAppVersionCompatibilityAsync()
            => await _sessionsRepository.GetAppVersionCompatibilityAsync();

        /// <summary>
        /// Checks if the session is valid or not.
        /// </summary>
        /// <param name="sessionId">Id of the session</param>
        /// <returns>If session is still valid or not, UserId and ProductName.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> StatusRow, int UserId, string ProductName)> CheckSessionAsync(int sessionId)
            => await _sessionsRepository.CheckSessionAsync(sessionId);
    }
}