﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Documents
{
    public class AddDocumentForEntityRequestDto
    {
        public int SessionId { get; set; }
        public int EntityId { get; set; }
        public string EntityType { get; set; }
        public string DocumentNumber { get; set; }
        public string DocumentTypeCode { get; set; }
        public string Subject { get; set; }
        public string Description { get; set; }
        public string IndividualNumber { get; set; }
        public string IndividualCode { get; set; }
        public string ReferenceNumber { get; set; }
        public DateTime? ReferenceDate { get; set; }
        public string ContentType { get; set; }
        public string ContentSubType { get; set; }
        public int? TransactionId { get; set; }
        public string OriginalDocumentName { get; set; }
        public string ImageType { get; set; }
        public string Location { get; set; }
        public string TimeStamp { get; set; }
        public string FromWeb { get; set; }
        public int? ReferralDocumentID { get; set; }
        public string Usage { get; set; }
    }
}
