﻿
namespace HSP_CS_COMMON_REPOSITORIES.Request.Events
{
    public class EventSearchDetailsRequest
    {
        public int SessionId { get; set; }
        public int? EventId { get; set; }
    }
}
