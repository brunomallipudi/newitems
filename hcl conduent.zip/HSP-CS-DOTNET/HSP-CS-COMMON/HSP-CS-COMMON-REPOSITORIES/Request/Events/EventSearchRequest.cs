﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Events
{
    public class EventSearchRequest 
    {
        public int SessionId { get; set; }
        public string LOB { get; set; }
        public string ClientName { get; set; }
        public int? EventID { get; set; }
        public int? MemberId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }        
        public DateTime? DOB { get; set; }
        public int? ResultPageNumber { get; set; }
        public int? ResultCount { get; set; }
        public string GroupName { get; set; }
        public string TrackingNumber { get; set; }
        public string MemberNumber { get; set; }
    }
}
