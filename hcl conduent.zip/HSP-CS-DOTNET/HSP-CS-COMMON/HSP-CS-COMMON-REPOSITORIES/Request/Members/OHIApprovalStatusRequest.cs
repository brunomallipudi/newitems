﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class OHIApprovalStatusRequest
    {
        public int SessionId { get; set; }
        public int? MemberId { get; set; }
        public string TrackingNumber { get; set; }
    }
}