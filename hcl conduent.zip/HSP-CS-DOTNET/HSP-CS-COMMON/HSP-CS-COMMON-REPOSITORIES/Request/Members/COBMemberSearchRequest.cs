﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class COBMemberSearchRequest
    {
        public int SessionId { get; set; }
        public int? MemberId { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string MemberLastName { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberMiddleInitial { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Subscriber { get; set; }
        public DateTime? SubscriberDateOfBirth { get; set; }
        public string SubscriberGender { get; set; }
        public string OHIName { get; set; }
        public string OHINumber { get; set; }
        public DateTime? OHIEffectiveDate { get; set; }
        public DateTime? OHIExpirationDate { get; set; }
        public string LOB { get; set; }
        public string ClientName { get; set; }
        public string AllowPartialSearch { get; set; }
        public int? ResultCount { get; set; }    
        public int? ResultPageNumber { get; set; }
        public string MemberNumber { get; set; }
    }
}
