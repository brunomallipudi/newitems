﻿using System.Collections.Generic;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class ProcessCOBChangesRequestDto
    {
        public int SessionId { get; set; }
        public int MemberId { get; set; }
        public IEnumerable<AddMemberCarrierMapRequestDto> AddMemberCarrierMapRequests { get; set; }
        public IEnumerable<DeleteMemberCarrierMapRequestDto> DeleteMemberCarrierMapRequest { get; set; }
        public IEnumerable<UpdateMemberCarrierMapRequestDto> UpdateMemberCarrierMapRequest { get; set; }
    }
}
