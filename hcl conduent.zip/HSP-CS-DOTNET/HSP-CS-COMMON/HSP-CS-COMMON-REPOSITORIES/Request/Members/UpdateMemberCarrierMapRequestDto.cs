﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class UpdateMemberCarrierMapRequestDto
    {
        public int SessionId { get; set; }
        public int? RowID { get; set; }
        public int? MemberId { get; set; }
        public int? SubscriberContractId { get; set; }
        public string COBType { get; set; }
        public string COBPrecedence { get; set; }
        public string COBClass { get; set; }
        public string COBSubClass { get; set; }
        public int? PayerId { get; set; }
        public string InternalPayerType { get; set; }
        public string PayerEmpName { get; set; }
        public string PayerGroupNumber { get; set; }
        public string PayerMemberNumber { get; set; }
        public string RelationshipToSubscriber { get; set; }
        public string Coverage { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string PolicyHolderLastName { get; set; }
        public string PolicyHolderFirstName { get; set; }
        public string PolicyHolderMiddleName { get; set; }
        public string PolicyHolderNameSuffix { get; set; }
        public string PolicyHolderSSN { get; set; }
        public DateTime? PolicyHolderDOB { get; set; }
        public string PolicyHolderPhone { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string Zip { get; set; }
        public int? ZipCodeId { get; set; }
        public string CountryCode { get; set; }
        public string UpdateUsage { get; set; } = "|Normal|";
        public int? InboundJobDetailId { get; set; }
        public string Import { get; set; }
        public string MultiCoverages { get; set; }
        public string MultipleMemberIDs { get; set; }
        public string RowIds { get; set; }
        public string RxBinNumber { get; set; }
        public string RxPcnNumber { get; set; }
        public string SupplementalType { get; set; }
        public string MSPType { get; set; }
        public string PayerOrder { get; set; }
        public string PolicyHolderGender { get; set; }
        public string SequenceNumber { get; set; }
        public DateTime? MACOBEffectiveDate { get; set; }
        public string RxIDNumber { get; set; }
        public string RxGroupNumber { get; set; }
        public string RxPhoneNumber { get; set; }
        public string PAPNationalDrugCode1 { get; set; }
        public string PAPNationalDrugCode2 { get; set; }
        public string PAPNationalDrugCode3 { get; set; }
        public string PAPNationalDrugCode4 { get; set; }
        public string PAPNationalDrugCode5 { get; set; }
        public string ExternalIdNumber { get; set; }
        public string RetirementDate { get; set; }
        public string EmployementStatus { get; set; }
        public string NoOfEmployees { get; set; }        
    }
}
