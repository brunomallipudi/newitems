﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class MemberSearchRequest
    {
        public int SessionId { get; set; }
        //public int? MemberId { get; set; }
        public string MemberNumber { get; set; }
        public string GroupName { get; set; }
        public string LOB { get; set; }
        public int? RowId { get; set; }
        public string AllowPartialSearch { get; set; }
        public int? ResultCount { get; set; }
        public int? ResultPageNumber { get; set; }
    }
}
