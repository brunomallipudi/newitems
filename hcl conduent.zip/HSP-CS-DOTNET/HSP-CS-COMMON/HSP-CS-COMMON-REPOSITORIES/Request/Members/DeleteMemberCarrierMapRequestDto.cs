﻿namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class DeleteMemberCarrierMapRequestDto
    {
        public int SessionId { get; set; }
        public int? RowId { get; set; }
        public string MultipleRowIDs { get; set; }
        public string Usage { get; set; } = "|Normal|";
    }
}
