﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Members
{
    public class COBLoginRequest
    {
        public int SessionId { get; set; }
        public string TrackingNumber { get; set; }
        public string MemberNumber { get; set; }
        public DateTime? DateOfBirth { get; set; }
    }
}
