﻿namespace HSP_CS_COMMON_REPOSITORIES.Request.Reports
{
    public class GetReportExportsStatusRequest
    {
        public int[] ReportUsageIds { get; set; }
        public int Userid { get; set; }
    }
}
