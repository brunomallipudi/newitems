﻿using System.ComponentModel.DataAnnotations;

namespace HSP_CS_COMMON_REPOSITORIES.Request.Reports
{
    public class FindReportsRequest
    {
        public string CategoryName { get; set; }

        public string SubCategoryName { get; set; }

        public string ReportName { get; set; }

        [Required]
        public string ProductName { get; set; }
    }
}
