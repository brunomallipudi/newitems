﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Request.FormLetters
{
    public class BatchStatusRequest
    {
        [Required]
        public int[] BatchIds { get; set; }

    }
}
