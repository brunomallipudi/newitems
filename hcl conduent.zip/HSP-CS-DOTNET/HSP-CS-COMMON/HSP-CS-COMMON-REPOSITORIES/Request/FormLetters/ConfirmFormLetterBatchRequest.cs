﻿using System;

namespace HSP_CS_COMMON_REPOSITORIES.Request.FormLetters
{
    public class ConfirmFormLetterBatchRequest
    {
        public int SessionId { get; set; }
        public int? BatchId { get; set; }
        public string SetMailDateToConfirmDate { get; set; }
    }

    
}
