﻿namespace HSP_CS_COMMON_REPOSITORIES.Request.Permissions
{
    /// <summary>
    /// Permissions Request
    /// Binds to the request body.
    /// </summary>
    public class GetPermissionsRequest
    {

        public int SessionId { get; set; }

        public int? UserId { get; set; }

        public string ProductName { get; set; }

        public string Usage { get; set; } = "USAGE1";        
    }
}