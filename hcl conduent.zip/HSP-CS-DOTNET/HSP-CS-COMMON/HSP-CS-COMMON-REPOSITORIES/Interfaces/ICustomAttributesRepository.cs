﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Custom Attributes Repository Interface.
    /// </summary>
    public interface ICustomAttributesRepository
    {
        /// <summary>
        /// Gets the values of a list.
        /// </summary>
        /// <param name="parameters">
        ///     SessionId   => HSP SessionId.
        ///     ListName    => Name of the list.
        ///     EntityId    => Id of the Entity.
        ///     EntityType  => Type of the Entity.
        ///     EntityAttributeMapperId => Id of the Entity Attribute mapping.
        ///     UseAdvancedFiltering => Does it use Advanced Filtering. Y or N.
        ///     Usage       => Stored procedure usage.
        ///     ListValue   => Filter by a specific value.
        ///     ResultCount => How many rows to return.
        /// </param>
        /// <returns>
        /// Values from a specific list.
        /// </returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ListValueDto> results)> GetListValues(object parameters);

        /// <summary>
        /// Gets the custom attribute categories.
        /// </summary>
        /// <param name="parameters">Custom attribute categories request.</param>
        /// <returns>List of custom attribute categories.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributeCategoryDto> results)> GetCustomAttributesCategory(object parameters);

        /// <summary>
        /// Get the custom attributes mapped to an entity.
        /// </summary>
        /// <param name="parameters">Custom attributes mapped to an entity request.</param>
        /// <returns>List of custom attributes mapped to an entity.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributeEntityMappingDto> results)> GetCustomAttributesForEntity(object parameters);

        /// <summary>
        /// Add a custom attribute entity value.
        /// </summary>
        /// <param name="parameters">Custom attribute entity value request.</param>
        /// <returns>Status row of the entity attributes request.</returns>
        Task<HSPDbResult<HSPAddEntryStatusRow>> AddEntityAttributes(object parameters);

        /// <summary>
        /// Get the custom attribute entity values history in xml.
        /// </summary>
        /// <param name="parameters">Custom attribute entity values history request.</param>
        /// <returns>Xml string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetCustomAttributeHistoryXMLForEntity(object parameters);

        /// <summary>
        /// Get custom attributes, version 2.
        /// </summary>
        /// <param name="parameters">Custom attributes mapped to an entity request.</param>
        /// <returns>List of custom attributes.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributes_V2Dto> results)> GetCustomAttributesV2(object parameters);

        /// <summary>
        /// Get custom attributes, version 3.
        /// </summary>
        /// <param name="parameters">Custom attributes mapped to an entity request.</param>
        /// <returns>List of custom attributes.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributes_V3Dto> results)> GetCustomAttributesV3(object parameters);

        /// <summary>
        /// Get Entity Attribute Mappings
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>List of Entity Attribute Mappings</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EntityAttributeMappingDto> results)> GetEntityAttributeMappings(object parameters);
    }
}
