﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Groups;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Groups repository.
    /// </summary>
    public interface IGroupsRepository
    {
        /// <summary>
        /// Get list of groups
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<GroupDto> results)> GetGroups(object parameters);

        /// <summary>
        /// Returns the Group profile xml.
        /// </summary>
        /// <param name="parameters">Request for Group profile xml.</param>
        /// <returns>Group profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetGroupProfile_XML(object parameters);
    }
}