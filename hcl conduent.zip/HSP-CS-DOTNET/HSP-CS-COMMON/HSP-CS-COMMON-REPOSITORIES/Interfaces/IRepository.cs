﻿using HSP_CS_COMMON_CORE.ResultHandling;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Base repository interface
    /// </summary>
    public interface IRepository
    {

        /// <summary>
        /// This method returns 2 objects.
        ///     HSP Database Status row
        ///     List of items returned by the database.
        ///     
        /// This method can be used for the API searches, when a stored procedure returns 2 result sets.
        /// </summary>
        /// <typeparam name="T">Type of Object to return</typeparam>
        /// <param name="storedProcedure">The name of the stored procedure to execute</param>
        /// <param name="parameters">An object containing the paramters for the stored procedure.</param>
        /// <returns>
        ///     HSPDbResult => a database result with the database status
        ///     ResultSet   => List of items in the result set.
        /// </returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<T> results)> GetAsync<T>(string storedProcedure, object parameters);

        /// <summary>
        /// This method returns 2 objects.
        ///     HSP Database Status row
        ///     Item returned by the database.
        ///     
        /// This method can be used for the API entity gets, when a stored procedure returns 2 result sets
        /// </summary>
        /// <typeparam name="T">Type of Object to return</typeparam>
        /// <param name="storedProcedure">The name of the stored procedure to execute</param>
        /// <param name="parameters">An object containing the paramters for the stored procedure.</param>
        /// <returns>
        ///     HSPDbResult => a database result with the database status
        ///     Results   => Item returned in the result set.
        /// </returns>
        Task<(HSPDbResult<TStatusRow> statusRow, T result)> GetOneAsync<TStatusRow, T>(string storedProcedure, object parameters) 
            where TStatusRow : HSPStatusRow, new();

        /// <summary>
        /// This method returns 1 objects.
        ///     HSP Database Status row, with the newly added EntityId

        /// </summary>
        /// <typeparam name="T">Type of Object to return</typeparam>
        /// <param name="storedProcedure">The name of the stored procedure to execute</param>
        /// <param name="parameters">An object containing the paramters for the stored procedure.</param>
        /// <returns>
        ///     HSPDbResult => a database result with the database status, and the newly added EntityId
        /// </returns>
        Task<HSPDbResult<HSPAddEntryStatusRow>> AddOneAsync(string storedProcedure, object parameters);
    }
}

