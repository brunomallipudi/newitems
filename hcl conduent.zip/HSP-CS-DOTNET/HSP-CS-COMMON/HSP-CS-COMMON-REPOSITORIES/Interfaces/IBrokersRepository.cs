﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IBrokersRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BrokerDto> results)> GetBrokers(object parameters);

        /// <summary>
        /// Returns the Broker's profile xml.
        /// </summary>
        /// <param name="parameters">Request for Broker profile xml.</param>
        /// <returns>Broker's profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetBrokerProfile_XML(object parameters);
    }
}

