﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.CapitationRates;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// CapitationRates repository.
    /// </summary>
    public interface ICapitationRatesRepository
    {
        /// <summary>
        /// Get list of CapitationRates
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CapitationRateDto> results)> GetCapitationRates(object parameters);
    }
}