﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Records;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Records repository.
    /// </summary>
    public interface IRecordsRepository
    {
         /// <summary>
        /// Get Document Request Records
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DocumentRequestRecordDto> results)> GetDocumentRequestRecords(object parameters);

        /// <summary>
        /// Get Records
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RecordDto> results)> GetRecords(object parameters);

        /// <summary>
        /// Get Record Details
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RecordDetailDto> results)> GetRecordDetails(object parameters);
    }
}