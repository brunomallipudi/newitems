﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.ListViewProfileSettings;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IListViewProfileSettingsRepository
    {
        /// <summary>
        /// Returns a ListViewProfileSetting from the stored procedure.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, ListViewProfileSettingDto result)> GetListViewProfileSettingsAsync(object parameters);

        /// <summary>
        /// Update Profile Setting
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> SaveListviewProfileSettings(object parameters);
    }
}