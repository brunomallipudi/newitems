﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Payers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IPayersRepository
    {
        /// <summary>
        /// Get Payers
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<PayerDto> results)> GetPayers(object parameters);

        /// <summary>
        /// Add Payer
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        Task<HSPDbResult<HSPAddEntryStatusRow>> AddPayer(object parameters);
    }
}
