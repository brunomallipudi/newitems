﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Providers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IProvidersRepository
    {
        /// <summary>
        /// Returns providers only
        /// Provides are unique here.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetProviders(object parameters);

        /// <summary>
        /// Returns providers with offices
        /// Providers returned are not unique
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetProvidersWithOffices(object parameters);

        /// <summary>
        /// Returns providers with offices and contracts
        /// Providers returned are not unique
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetProvidersWithOfficesAndContracts(object parameters);

        /// <summary>
        /// Return Provider Credentials
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ProviderCredentialDto> results)> GetProviderCredentials(object parameters);

        /// <summary>
        /// Returns the provider's profile xml.
        /// </summary>
        /// <param name="parameters">Request for provider profile xml.</param>
        /// <returns>Provider's profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetProviderCredentialsXML(object parameters);
    }
}