﻿using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// TableIds Repository - dbo.Ids
    ///
    /// Responsible for creating/updating new PrimaryKey values for the
    /// tables, identified by a unique key.
    /// </summary>
    public interface ITableIdsRepository
    {
        /// <summary>
        /// Creates a new entry or updates an existing entry
        /// to get a new primary key.
        ///
        /// This exists because the tables have Primary Keys, but no identities.
        /// </summary>
        /// <param name="IdType"></param>
        /// <returns>Int32 - new PKey</returns>
        Task<int> GetNewIdAsync(string IdType);
    }
}