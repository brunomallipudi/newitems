﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.BenefitCoverages;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// BenefitCoverages repository.
    /// </summary>
    public interface IBenefitCoveragesRepository
    {
        /// <summary>
        /// Get BenefitCoverages
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BenefitCoverageDto> results)> GetBenefitCoverages(object parameters);
    }
}
