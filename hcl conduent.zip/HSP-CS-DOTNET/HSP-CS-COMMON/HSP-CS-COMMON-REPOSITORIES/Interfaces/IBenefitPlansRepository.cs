﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.BenefitPlans;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IBenefitPlansRepository
    {
        /// <summary>
        /// Get Benefit Plans
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BenefitForPlanDto> results)> GetBenefitsForPlan_Levels(object parameters);
    }
}
