﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_ENTITIES.DTO.WorkGroups;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IWorkGroupsRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<WorkGroupDto> results)> GetWorkGroups(object parameters);

        /// <summary>
        /// Work Group Request
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return work group request</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<WorkGroupRequestDto> results)> GetWorkGroupRequests(object parameters);

    }
}
