﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Members;
using HSP_CS_COMMON_REPOSITORIES.Request.Members;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IMembersRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> FindMemberCoverages(object parameters);

        /// <summary>
        /// Find Members for COB
        /// </summary>
        /// <param name="parameters">Find Members for COB</param>
        /// <returns>Find Members for COB</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindMembersCoveragesV2Dto> results)> FindMemberCoveragesV2(object parameters);

        /// <summary>
        /// Gets the family for a member.
        /// </summary>
        /// <param name="parameters">Get Family request.</param>
        /// <returns>List of family members.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FamilyMemberDto> results)> GetFamily(object parameters);

        /// <summary>
        /// Returns the member's profile xml.
        /// </summary>
        /// <param name="parameters">Request for member profile xml.</param>
        /// <returns>Member's profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetMemberProfile_XML(object parameters);

        /// <summary>
        /// Changes Member Provider Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> ChangeMemberProviderMapManual(object parameters);

        /// <summary>
        /// Gets the member's PCP.
        /// </summary>
        /// <param name="parameters">Get member pcp request.</param>
        /// <returns>List of pcp for the member.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<MemberPCPDto> results)> GetMemberPCPInfo(object parameters);

        /// <summary>
        /// Gets the member's responsible parties.
        /// </summary>
        /// <param name="parameters">Get member's responsible parties request.</param>
        /// <returns>List of responsible parties for the member.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ResponsiblePartyDto> results)> GetResponsiblePartyCoverageMap(object parameters);

        /// <summary>
        /// Gets the member's carrier map.
        /// </summary>
        /// <param name="parameters">Get member's carrier map request.</param>
        /// <returns>List of carrier map for the member.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<MemberCarrierMapDto> results)> GetMemberCarrierMap(object parameters);

        /// <summary>
        /// Add Member carrier Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, IEnumerable<AddMemberCarrierMapDto> results)> AddMemberCarrierMap(object parameters);

        /// <summary>
        /// Update Member carrier Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateMemberCarrierMap(object parameters);

        /// <summary>
        /// Delete Member carrier Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> DeleteMemberCarrierMap(object parameters);

        /// <summary>
        /// Gets COB's History.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<COBsHistoryDto> results)> GetCOBHistory(object parameters);

        /// <summary>
        /// Process COB Changes
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> ProcessCOBChanges(ProcessCOBChangesRequestDto parameters);

        /// <summary>
        /// Get Member Search Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<MemberSearchFileDBResult> results)> GetMemberSearchResult(MemberSearchRequest memberSearchRequest);

        /// <summary>
        /// Get Member Search Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<OHIApprovalStatusDto> results)> GetOHIApprovalStatus(OHIApprovalStatusRequest oHIApprovalStatusRequest);

        /// <summary>
        /// COB Login Request with LetterID and MemberNumber
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<COBLoginDto> results)> COBLogin(COBLoginRequest cOBLoginRequest);

        /// <summary>
        /// Member Search for COB
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<COBMemberSearchDto> results)> COBMemberSearch(COBMemberSearchRequest cOBMemberSearchRequest);
    }
}
