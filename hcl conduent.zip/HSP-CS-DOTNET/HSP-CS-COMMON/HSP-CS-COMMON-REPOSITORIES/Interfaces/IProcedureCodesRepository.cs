﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IProcedureCodesRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ProcedureCodeDto> results)> GetProcedureCodes(object parameters);
    }
}
