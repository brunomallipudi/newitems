﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Reports;
using HSP_CS_COMMON_REPOSITORIES.Request.Reports;
using HSP_CS_COMMON_REPOSITORIES.ResultHandling.Reports;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IReportsRepository
    {
        /// <summary>
        /// Get User Report Maps
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserReportMapDto> results)> GetUserReportMaps(object parameters);

        /// <summary>
        /// Add User Report Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        Task<HSPDbResult<HSPAddEntryStatusRow>> AddUserReportMap(object parameters);

        /// <summary>
        /// Delete User Report Map.
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> DeleteUserReportMap(object parameters);

        /// <summary>
        /// Update User Report Map.
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> UpdateUserReportMap(object parameters);

        /// <summary>
        /// Get User Report Default Columns
        /// </summary>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserReportDefaultColumnDto> results)> UserReportDefaultColumns(object parameters);

        /// <summary>
        /// Get Reports Category
        /// </summary>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportCategoryDto> results)> GetReportCategories(int sessionId, string productName);

        /// <summary>
        /// Get Reports Sub Category
        /// </summary>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportSubCategoryDto> results)> GetReportSubCategories(int sessionId, string productName, string categoryName);

        /// <summary>
        /// Get Online Reports
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<OnlineReportDto> results)> GetOnlineReports(object parameters);

        /// <summary>
        /// Get Reports
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportDto> results)> GetReports(object parameters);

        /// <summary>
        /// Get Parameters
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportParameterDto> results)> GetReportParameters(object parameters);

        /// <summary>
        /// Find Reports
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindReportDto> results)> FindReports(FindReportsRequest findReportsRequest);

        /// <summary>
        /// Get Report Usage
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportUsageDto> results)> GetReportUsage(object parameters);

        /// <summary>
        /// Update Report Usage.
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> UpdateReportUsage(object parameters);

        /// <summary>
        /// Add Report Usage
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        Task<HSPDbResult<HSPAddReportRequestStatusRow>> AddReportUsage(object parameters);

        /// <summary>
        /// Get Report ExportsStatus
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportExportStatusDto> results)> GetReportExportsStatus(GetReportExportsStatusRequest getReportExportsStatusReposRequest);

        /// <summary>
        /// Get Report Status
        /// For One report UsageID
        /// </summary>
        /// <param name="ReportUsageID"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, ReportExportStatusDto result)> GetReportStatus(int reportUsageID);
    }
}
