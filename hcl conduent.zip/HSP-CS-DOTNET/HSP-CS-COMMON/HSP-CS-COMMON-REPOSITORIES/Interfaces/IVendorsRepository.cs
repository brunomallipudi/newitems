﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IVendorsRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<VendorDto> results)> GetVendors(object parameters);

        /// <summary>
        /// Returns the Vendor's profile xml.
        /// </summary>
        /// <param name="parameters">Request for Vendor profile xml.</param>
        /// <returns>Vendor's profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetVendorProfile_XML(object parameters);
    }
}
