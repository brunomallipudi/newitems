﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Contracts;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IContractsRepository
    {
        /// <summary>
        /// Get list of contracts
        /// </summary>
        /// <param name="parameters">Get contracts request</param>
        /// <returns>List of contracts</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContractDto> results)> GetContracts(object parameters);
    }
}
