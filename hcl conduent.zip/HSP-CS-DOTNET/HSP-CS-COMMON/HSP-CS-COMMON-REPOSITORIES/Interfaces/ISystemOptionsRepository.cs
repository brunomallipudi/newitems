﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface ISystemOptionsRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<SystemOptionDto> results)> GetSystemOptions(object parameters);
    }
}
