﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IOfficesRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetOffices(object parameters);

        /// <summary>
        /// Returns the Office profile xml.
        /// </summary>
        /// <param name="parameters">Request for Office profile xml.</param>
        /// <returns>Office profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetOfficeProfile_XML(object parameters);
    }
}
