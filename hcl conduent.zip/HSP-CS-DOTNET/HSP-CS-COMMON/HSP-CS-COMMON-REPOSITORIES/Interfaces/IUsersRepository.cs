﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IUsersRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserDto> results)> GetUsers(object parameters);

        /// <summary>
        /// Find an User.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Find User.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindUserDto> results)> FindUser(object parameters);
    }
}
