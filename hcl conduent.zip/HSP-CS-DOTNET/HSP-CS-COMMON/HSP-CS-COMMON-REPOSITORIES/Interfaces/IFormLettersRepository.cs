﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.FormLetters;
using HSP_CS_COMMON_REPOSITORIES.Request.FormLetters;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IFormLettersRepository
    {
        /// <summary>
        /// Get Letter Details.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Details</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetLetterDetails(object parameters);

        /// <summary>
        /// Get Letter Categories.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Categories</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<LetterCategoryDto> results)> GetLetterCategories(object parameters);

        /// <summary>
        /// Get Letter Batches.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Batches</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<LetterBatchDto> results)> GetLetterBatches(object parameters);

        /// <summary>
        /// Get Letter Contact Step Forms.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Contact Step Forms</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactStepFormLetterDto> results)> GetContactStepFormLetters(object parameters);

        /// <summary>
        /// Update Form Letter.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Update Form Letter</returns>     
        Task<HSPDbResult<HSPStatusRow>> UpdateFormLetter(object parameters);

        /// <summary>
        /// Confirm Form Letter.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Update Form Letter</returns>     
        Task<HSPDbResult<HSPStatusRow>> ConfirmFormLetterBatch(ConfirmFormLetterBatchRequest confirmFormLetterBatchRequest);

        /// <summary>
        /// Update Extracted Data Batch.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Extracted Data Batch</returns>     
        Task<HSPDbResult<HSPStatusRow>> UpdateExtractedDataBatch(object parameters);

        /// <summary>
        /// Delete Form Letter.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Delete Form Letter</returns>    
        Task<HSPDbResult<HSPStatusRow>> DeleteFormLetter(object parameters);

        /// <summary>
        /// Add Extracted Data Master
        /// </summary>
        Task<(HSPDbResult<HSPStatusRow> statusRow, AddExtractedDataMasterDto result)> AddExtractedDataMaster(object parameters);

        /// <summary>
        /// Add Extracted Data Details to batch
        /// </summary>
        /// <param name="parameters"></param>       
        Task<(HSPDbResult<HSPStatusRow> statusRow, AddExtractedDataDetailToBatchDto result)> AddExtractedDataDetailToBatch(object parameters);

        /// <summary>
        /// Get Extracted FormLetter.
        /// </summary>        
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<GetExtractedFormLetterBatchDto> results)> GetExtractedFormLetterBatches(object parameters);

        /// <summary>
        /// Get Batches Status
        /// </summary>
        /// <param name="batchStatusRequest"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BatchStatusDto> results)> GetBatchesStatus(BatchStatusRequest batchStatusRequest);

        /// <summary>
        /// Clear Confirm Date
        /// </summary>
        /// <param name="RowIds"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> ClearConfirmDate(int[] RowIds);
    }
}
