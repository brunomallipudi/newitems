﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Demographics;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Demographics repository.
    /// </summary>
    public interface IDemographicsRepository
    {
        /// <summary>
        /// Get list of Demographics
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DemographicDto> results)> GetDemographicsFromZips(object parameters);
    }
}