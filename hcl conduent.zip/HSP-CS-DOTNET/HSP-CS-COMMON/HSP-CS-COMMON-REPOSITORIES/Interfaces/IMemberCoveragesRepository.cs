﻿using HSP_CS_COMMON_CORE.ResultHandling;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IMemberCoveragesRepository
    {
        /// <summary>
        /// Get Member Coverages .
        /// </summary>
        /// <param name="parameters">Member Coverages request.</param>
        /// <returns>List of Member Coverages.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetMemberCoveragesAsync(object parameters);
    }
}
