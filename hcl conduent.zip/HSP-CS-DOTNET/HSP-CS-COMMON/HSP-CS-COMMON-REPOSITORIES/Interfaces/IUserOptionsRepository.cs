﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.UserOptions;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IUserOptionsRepository
    {
        /// <summary>
        /// Gets a User Option - or options - depending on the parameters.
        /// </summary>
        /// <param name="parameters">
        ///     SessionId   => HSP SessionId
        ///     ItemType    => Can be a value, or null
        ///                    If null, it returns all user options
        /// </param>
        /// <returns>
        /// Returns 1 or multiple User Options
        /// </returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserOptionDto> results)> GetUserOption(object parameters);

        /// <summary>
        /// Set User Option
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> SetUserOption(object parameters);
    }
}