﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Find;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    //todo
    public interface IFindRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindCommandDto> results)> GetFindCommandsAsync(object parameters);

        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindControlDto> results)> GetFindControlsAsync(object parameters);
    }
}