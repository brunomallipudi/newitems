﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.RiskGroups;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IRiskGroupsRepository
    {
        /// <summary>
        /// Get list of risk groups.
        /// </summary>
        /// <param name="parameters">Get riskgroups request</param>
        /// <returns>List of Riskgroups</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RiskGroupDto> results)> GetRiskGroups(object parameters);
    }
}
