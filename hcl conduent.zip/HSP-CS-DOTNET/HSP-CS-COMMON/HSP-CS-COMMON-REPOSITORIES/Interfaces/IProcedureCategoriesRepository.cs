﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.ProcedureCategories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Procedure Categories repository.
    /// </summary>
    public interface IProcedureCategoriesRepository
    {
        /// <summary>
        /// Get list of procedure categories
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ProcedureCategoryDto> results)> GetProcedureCategories(object parameters);
    }
}