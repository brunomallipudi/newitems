﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Events;
using HSP_CS_COMMON_REPOSITORIES.Request.Events;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IEventsRepository
    {
        /// <summary>
        /// Adds a new File Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        Task<HSPDbResult<HSPAddEntryStatusRow>> AddFileEntityMap(object parameters);

        /// <summary>
        /// Adds a new Transaction to File
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        Task<(HSPDbResult<HSPStatusRow>, AddTransactionToFileDto results)> AddTransactionToFile(object parameters);

        /// <summary>
        /// Get File Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FileEntityMapDto> results)> GetFileEntityMap(object parameters);

        /// <summary>
        /// Get Time Items
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<TimeItemDto> results)> GetTimeItems(object parameters);

        /// <summary>
        /// Add Time Item
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow>, AddTimeItemDto result)> AddTimeItem(object parameters);

        /// <summary>
        /// Update Time Item
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateTimeItem(object parameters);

        /// <summary>
        /// Get Event Info
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetEventInfo(object parameters);

        /// <summary>
        /// Get Event Transactions
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventTransactionDto> results)> GetEventTransactions(object parameters);

        /// <summary>
        /// Find Events
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventDto> results)> FindEvents(object parameters);

        /// <summary>
        /// Find Contact Files.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> FindContactFilesV3(object parameters);

        /// <summary>
        /// Reclassify an Event
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> ReclassifyEvent(object parameters);

        /// <summary>
        /// Void Event.
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> VoidEvent(object parameters);

        /// <summary>
        /// Update Event.
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> UpdateEvent(object parameters);

        /// <summary>
        /// Get Smart Routing Info
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, SmartRoutingInfoDto result)> GetSmartRoutingInfo(object parameters);

        /// <summary>
        /// Get Routing Info for Uniflow
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, RoutingInfoDto result)> GetRoutingInfoForuniflow(object parameters);

        /// <summary>
        /// Delete File Entity Map.
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> DeleteFileEntityMap(object parameters);

        /// <summary>
        /// Delete Time Item.
        /// </summary>      
        Task<HSPDbResult<HSPStatusRow>> DeleteTimeItem(int timeItemId, int userId);

        /// <summary>
        /// Get Events TimeItems
        /// </summary>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<TimeItemDto> results)> GetEventsTimeItems(DateTime? fromDate, DateTime? ToDate, int[] events, int? resultPageNumber = 1, int? ResultCount = null);

        /// <summary>
        /// Get Event Search Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventSearchDto> results)> GetEventSearchResult(EventSearchRequest eventSearchRequest);

        /// <summary>
        /// Get Event Search Details Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>       
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventSearchDBResult> results)> GetEventSearchDetailsResult(EventSearchDetailsRequest eventSearchDetailsRequest);

    }
}
