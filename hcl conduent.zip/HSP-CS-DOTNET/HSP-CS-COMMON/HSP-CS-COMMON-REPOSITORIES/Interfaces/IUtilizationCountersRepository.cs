﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.UtilizationCounters;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IUtilizationCountersRepository
    {
        /// <summary>
        /// Gets the Utilization Counters.
        /// </summary>
        /// <param name="parameters"> Utilization Counters request.</param>
        /// <returns>List of Utilization Counters.</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UtilizationCounterDto> results)> GetUtilizationCountersAsync(object parameters);

        /// <summary>
        /// Gets the Utilization Counters Xml.
        /// </summary>
        /// <param name="parameters"> Utilization Counters Xml request.</param>
        /// <returns>Utilization Counters Xml as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetUtilizationCountersXml(object parameters);
    }
}
