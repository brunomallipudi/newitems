﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_ENTITIES.DTO.Individuals;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IIndividualsRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<IndividualDto> results)> FindIndividuals(object parameters);

        /// <summary>
        /// Update Individual
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateIndividual(object parameters);

        /// <summary>
        /// Add Individual
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, AddIndividualDto result)> AddIndividual(object parameters);

        /// <summary>
        /// Returns the Individual profile xml.
        /// </summary>
        /// <param name="parameters">Request for Individual profile xml.</param>
        /// <returns>Individual profile in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetIndividualProfile_XML(object parameters);

        /// <summary>
        /// Returns the Find Individual Info xml.
        /// </summary>
        /// <param name="parameters">Request for Find Individual Info xml.</param>
        /// <returns>Find Individual Info in Xml format as a string.</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> FindIndividualInfo(object parameters);
    }
}
