﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Notes;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface INotesRepository
    {
        /// <summary>
        /// Get list of Notes Categories
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<NotesCategoriesDto> results)> GetNotesCategories(object parameters);

        /// <summary>
        /// Get Notes for Entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Notes for Entity</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<NoteDto> results)> GetNotes(object parameters);

        /// <summary>
        /// Get amount of notes for an entity
        /// </summary>
        /// <param name="entityType">Entity Type</param>
        /// <param name="entityId">Id of the entity</param>
        /// <returns>The amount of notes for an entity</returns>
        Task<int> GetNotesCount(string entityType, int entityId);
    }
}
