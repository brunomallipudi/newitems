﻿using HSP_CS_COMMON_ENTITIES.Domain;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IListviewSettingsRepository
    {
        /// <summary>
        /// Get the listview settings for a particular listview.
        /// </summary>
        /// <param name="listviewName">Name of the listview.</param>
        /// <returns>The listview column settings.</returns>
        Task<ListviewSetting> GetListviewSettings(string listviewName);
    }
}
