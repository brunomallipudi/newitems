﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.WorkRequests;
using HSP_CS_COMMON_REPOSITORIES.ResultHandling;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IWorkRequestsRepository
    {
        Task<(HSPDbResult<HSPGetWorkRequestStatusRow> statusRow, WorkRequestDto result)> GetWorkRequest(object parameters);

        /// <summary>
        /// Route Work Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> RouteWorkRequest(object parameters);

        /// <summary>
        /// Update the Work Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateWorkRequest(object parameters);

        /// <summary>
        /// Detail of Work Group Request
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return detail of work group request</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<WorkRequestDetailDto> results)> GetWorkRequestDetail(object parameters);

        /// <summary>
        /// cancel Work Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> CancelWorkRequest(object parameters);

        /// <summary>
        /// Get the current work.
        /// </summary>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CurrentWorkDto> results)> GetCurrentWork(int userId, int? assignedToId = null, DateTime? lastSyncDate = null);

        /// <summary>
        /// Get Work Stats.
        /// </summary>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<GetWorkStatsDto> results)> GetWorkStats(int userId);
    }
}
