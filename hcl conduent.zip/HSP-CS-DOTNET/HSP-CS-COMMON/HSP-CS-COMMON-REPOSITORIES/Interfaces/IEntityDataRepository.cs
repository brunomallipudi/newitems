﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.EntityData;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IEntityDataRepository
    {
        /// <summary>
        /// Get list of Entity Data
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EntityDataDto> results)> GetEntityData(object parameters);

        /// <summary>
        /// Create an Entity Data entry
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> AddEntityData(object parameters);

        /// <summary>
        /// Delete an Entity Data entry
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> DeleteEntityData(object parameters);

        /// <summary>
        /// Update an Entity Data entry
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateEntityData(object parameters);
    }
}