﻿using HSP_CS_COMMON_CORE.ResultHandling;
using System.Threading.Tasks;
using HSP_CS_COMMON_ENTITIES.DTO.Find;
using System.Collections.Generic;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IFindProfilesRepository
    {
        /// <summary>
        /// Get Find Profile Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindProfileMapDto> results)> GetFindProfileMap(object parameters);

        /// <summary>
        /// Get Find Profile Custom Attributes
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindProfileCustomAttributeDto> results)> GetFindProfilesCustomAttribute(object parameters);

        /// <summary>
        /// Copy Profile
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Profile Copy Status</returns>
        Task<HSPDbResult<HSPStatusRow>> CopyFindProfileMap(object parameters);

        /// <summary>
        /// Find Profiles
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Admin and User Profiles</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, IEnumerable<FindProfileDto> userProfiles, IEnumerable<FindProfileDto> adminProfiles)> GetFindProfiles(object parameters);

         
        /// <summary>
        /// Get Profile Roles
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Prifile's Roles</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindProfileRoleDto> results)> GetFindProfileRoles(object parameters);

        /// <summary>
        /// Save Profile Roles
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Status of Save Profile Roles</returns>
        Task<HSPDbResult<HSPStatusRow>> SaveFindProfileRole(object parameters);
    }
}
