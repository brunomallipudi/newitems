﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.UserReports;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IUserReportsRepository
    {
        /// <summary>
        /// Gets User Reports.
        /// </summary>
        /// <param name="parameters">
        ///     SessionId   => HSP SessionId
        ///     Usage       => Usage
        ///     OperationalReportId => If pulling by operational report Id
        ///     UserReportId => Filter by User Report Id
        ///     GetFavoriteDefaultParameters => If it should return the favorite default parameters
        ///     GetUserReportDefaultColumns => If it should return the default columns
        ///     UserReportMapId => User Report Map Id
        ///     CategoryCode => Category Code
        ///     SubCategoryCode => Sub category code
        ///     ReportName  => Filter by report
        ///     Product     => Filter by product
        /// </param>
        /// <returns>
        /// Returns 1 or multiple User Reports
        /// </returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserReportDto> results)> GetUserReports(object parameters);

        /// <summary>
        /// Get User Report
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Returns Only 1 User Report</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, UserReportDto results)> GetUserReport(object parameters);
    }
}
