﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Claims;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Claims repository.
    /// </summary>
    public interface IClaimsRepository
    {
        /// <summary>
        /// Get list of claims for an entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimForEntityV2Dto> results)> GetClaimsForEntityV2(object parameters);

        /// <summary>
        /// Get claims for an entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimForEntityDto> results)> GetClaimsForEntity(object parameters);

        /// <summary>
        /// Get claims action codes
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimActionCodeDto> results)> GetClaimActionCodes(object parameters);

        /// <summary>
        /// Get claim explanations
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimExplanationDto> results)> GetClaimExplanations(object parameters);

        /// <summary>
        /// Get ClaimId For Number
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimIdForNumberDto> results)> GetClaimIdForNumber(object parameters);
    }
}