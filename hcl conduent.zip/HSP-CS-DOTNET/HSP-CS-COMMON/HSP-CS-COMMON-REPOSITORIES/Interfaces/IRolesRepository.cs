﻿using HSP_CS_COMMON_CORE.ResultHandling;
using System.Threading.Tasks;
using HSP_CS_COMMON_ENTITIES.DTO.Roles;
using System.Collections.Generic;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IRolesRepository
    {
        /// <summary>
        /// Get Billing Role for Users
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BillingRoleDto> results)> GetBillingRolesforUser(object parameters);

        /// <summary>
        /// Get Roles
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>List of Roles</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RoleDto> results)> GetRoles(object parameters);
    }
}
