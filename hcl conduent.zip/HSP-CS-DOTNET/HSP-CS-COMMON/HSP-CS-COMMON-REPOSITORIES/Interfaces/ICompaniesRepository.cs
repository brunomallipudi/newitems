﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Companies;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Custom Attributes Repository Interface.
    /// </summary>
    public interface ICompaniesRepository
    {
        /// <summary>
        /// Get Companies
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CompanyDto> results)> GetCompanies(object parameters);
    }
}
