﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Permissions;
using HSP_CS_COMMON_REPOSITORIES.Request.Permissions;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IPermissionsRepository
    {
        /// <summary>
        /// Gets the list of permissions for a user via
        ///  - UserId
        ///     If a UserId is present, the SessionId is ignored
        ///  - SessionId
        ///  - Usage
        ///         Defaults to USAGE1
        ///         Options
        ///             - USAGE1 => Allowed permissions
        ///             - USAGE2 => Not Allowed permissions
        ///             - USAGE3 => USAGE1 + USAGE 2
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> status, IEnumerable<UserPermission> results)> GetPermissionsAsync(GetPermissionsRequest parameters);

        /// <summary>
        /// Get the list of permissions
        /// </summary>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> status, IEnumerable<Permission> results)> GetPermissionsAsync();
    }
}
