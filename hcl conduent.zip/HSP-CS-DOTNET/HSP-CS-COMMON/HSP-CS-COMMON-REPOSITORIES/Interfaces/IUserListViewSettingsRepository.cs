﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.UserListViewSettings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// UserListViewSettings Repository
    /// </summary>
    public interface IUserListViewSettingsRepository
    {
        /// <summary>
        /// Gets any stored user settings for list views
        /// </summary>
        /// <param name="parameters">search parameters</param>
        /// <returns>(dbstatus, dbresult)</returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, UserListViewSettingDto result)> GetUserListViewSettingsAsync(object parameters);

        /// <summary>
        /// Adds a new entry for a list view
        /// </summary>
        /// <param name="parameters">settings</param>
        /// <returns>dbstatus</returns>
        Task<HSPDbResult<HSPAddEntryStatusRow>> AddUserListViewSettingsAsync(object parameters);

        /// <summary>
        /// Update an entry for a list view
        /// </summary>
        /// <param name="parameters">settings</param>
        /// <returns>dbstatus</returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateUserListViewSettingsAsync(object parameters);
    }
}
