﻿using HSP_CS_COMMON_CORE.ResultHandling;
using System;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IManageWorkRepository
    {
        /// <summary>
        /// Update multiple work requests
        /// </summary>
        Task<HSPDbResult<HSPStatusRow>> UpdateWorkRequests(int[] requestIds, DateTime? dueDate, DateTime? workDate, int? checkOutUserId, Single? Priority);
    }
}
