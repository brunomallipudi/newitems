﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Metadata;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IMetadataRepository
    {
        /// <summary>
        /// Get metadata from the SP.
        /// </summary>
        Task<(HSPDbResult<HSPStatusRow> statusRow, IEnumerable<MetadataDto> results)> GetMetadata(int sessionId, string interfaceName, bool shortName);
    }
}
