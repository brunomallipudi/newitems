﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.SummaryOfBenefits;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface ISummaryOfBenefitsRepository
    {
        /// <summary>
        ///Get Top Level Summary Of Benefit Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, TopLevelSummaryOfBenefitMapDto results)> GetTopLevelSummaryOfBenefitMap(object parameters);
    }
}
