﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Documents;
using HSP_CS_COMMON_REPOSITORIES.Request.Documents;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IDocumentsRepository
    {
        /// <summary>
        ///Get Entity Documents
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        /// 
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DocumentEntityMapDto> results)> GetEntityDocuments(object parameters);

        /// <summary>
        /// Get Documents
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DocumentDto> results)> GetDocuments(object parameters);

        /// <summary>
        /// Get document by Id.
        /// </summary>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, DocumentFullDto result)> GetDocumentById(int sessionId, int documentId);

        /// <summary>
        /// Create a Document Entity Map entry
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> AddDocumentEntityMap(object parameters);

        /// <summary>
        /// Add Document For Entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, AddDocumentForEntityDto result)> AddDocumentForEntity(AddDocumentForEntityRequestDto parameters);

        /// <summary>
        /// Get Done Path
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow> statusRow, DonePathDto results)> GetDonePath(object parameters);

        /// <summary>
        /// Delete Document Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> DeleteDocumentEntityMap(object parameters);

        /// <summary>
        /// Update Document Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateDocumentEntityMap(object parameters);

        /// <summary>
        /// Update Document
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateDocument(object parameters);

        /// <summary>
        /// Adds Document
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPStatusRow>, AddDocumentDto result)> AddDocument(object parameters);
       

    }
}
