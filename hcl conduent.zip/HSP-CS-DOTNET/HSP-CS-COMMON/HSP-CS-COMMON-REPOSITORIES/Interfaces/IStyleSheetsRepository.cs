﻿using HSP_CS_COMMON_CORE.ResultHandling;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IStyleSheetsRepository
    {
        /// <summary>
        /// Get XML Record
        /// </summary>
        /// <param name="storeProcedureName"></param>
        /// <param name="parameters"></param>
        /// <param name="returnStatus"></param>
        /// <returns>Return record in XML based on 'ReturnStatus' param</returns>
        Task<(HSPDbResult<HSPStatusRow>, string results)> GetXMLRecord(string storeProcedureName, object parameters, bool returnStatus);
    }
}
