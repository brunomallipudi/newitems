﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.ContactReasons;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IContactReasonsRepository
    {
        /// <summary>
        /// Get list of contact reasons
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactReasonDto> results)> GetContactReasons(object parameters);

        /// <summary>
        /// Get list of contact reasons for step
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactReasonForStepDto> results)> GetContactReasonsForStep(object parameters);

        /// <summary>
        /// Get list of contact steps to skip to
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactStepToSkipToDto> results)> GetContactStepsToSkipTo(object parameters);
    }
}