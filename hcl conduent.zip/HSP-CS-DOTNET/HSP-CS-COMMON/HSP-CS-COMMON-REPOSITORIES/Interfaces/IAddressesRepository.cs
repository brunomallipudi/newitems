﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Addresses;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    /// <summary>
    /// Addresses repository.
    /// </summary>
    public interface IAddressesRepository
    {
        /// <summary>
        /// Get list of Countries
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CountyDto> results)> GetCounties(object parameters);

        /// <summary>
        /// Validate City, State and Zip
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ValidateCityStateZipDto> results)> ValidateCityStateZip(object parameters);


    }
}
