﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.IDCards;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IIDCardsRepository
    {
        /// <summary>
        /// Get list of id cards
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<IDCardRequestDto> results)> GetIDCardRequests(object parameters);

        /// <summary>
        /// Add an ID Card Request
        /// </summary>
        Task<(HSPDbResult<HSPStatusRow> statusRow, AddIDCardRequestDto result)> AddIDCardRequest(object parameters);

        /// <summary>
        /// Update ID Card Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> UpdateIDCardRequest(object parameters);

        /// <summary>
        /// Get list of id card packages
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<IDCardPackageDto> results)> GetIDCardPackages(object parameters);
    }
}