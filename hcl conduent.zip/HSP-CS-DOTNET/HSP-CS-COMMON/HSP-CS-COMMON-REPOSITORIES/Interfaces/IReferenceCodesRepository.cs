﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface IReferenceCodesRepository
    {
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReferenceCode> results)> GetReferenceCodes(object parameters);

        /// <summary>
        /// Get Entity Reference Code Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EntityReferenceCodeMapDto> results)> GetEntityReferenceCodeMap(object parameters);
    }
}
