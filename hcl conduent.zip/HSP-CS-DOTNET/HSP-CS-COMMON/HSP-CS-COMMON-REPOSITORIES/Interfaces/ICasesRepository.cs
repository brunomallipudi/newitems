﻿using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Cases;
using HSP_CS_COMMON_REPOSITORIES.ResultHandling;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Interfaces
{
    public interface ICasesRepository
    {
        /// <summary>
        /// Detail of Cases
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return detail of cases</returns>
        Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CaseDto> results)> GetCases(object parameters);
    }
}
