﻿using HSP_CS_COMMON_CORE.ResultHandling;

namespace HSP_CS_COMMON_REPOSITORIES.ResultHandling.Reports
{
    public class HSPAddReportRequestStatusRow : HSPStatusRow
    {
        public int? ReportUsageID { get; set; }
    }
}
