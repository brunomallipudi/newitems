﻿using HSP_CS_COMMON_CORE.ResultHandling;

namespace HSP_CS_COMMON_REPOSITORIES.ResultHandling
{
    public class HSPGetWorkRequestStatusRow : HSPStatusRow
    {
        public int? TotalCount { get; set; }

        public int? RestrictedCount { get; set; }

        public int? OtherRestrictedCount { get; set; }
    }
}
