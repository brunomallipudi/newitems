﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ActionCodesRepository : Repository, IActionCodesRepository
    {
        public const string HSP_SP_GetActionCodes = "ee_GetActionCodes";

        public ActionCodesRepository(IDbConnectionString connectionStrings, ILogger<ActionCodesRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Get a list of Action Codes.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Action Codes.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ActionCodeDto> results)> GetActionCodes(object parameters)
        {
            return await GetAsync<ActionCodeDto>(HSP_SP_GetActionCodes, parameters);
        }
    }
}