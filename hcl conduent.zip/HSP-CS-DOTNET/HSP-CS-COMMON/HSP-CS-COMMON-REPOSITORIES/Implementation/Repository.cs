﻿using Dapper;
using HSP_CS_COMMON_CORE.Attributes;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.ErrorHandling;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// Base Repository Class
    ///
    /// Contains methods that can be utilized by all repositories
    /// </summary>
    public abstract class Repository : IRepository
    {
        private readonly ILogger<Repository> Logger;
        private readonly int CommandTimeout = 300;
        protected readonly IDbConnectionString DbConnectionString;
        protected readonly IConfiguration Configuration;
        protected readonly IHSPSession HSPSession;

        #region Constructors

        protected Repository
        (
            IDbConnectionString connectionStrings,
            ILogger<Repository> logger,
            IConfiguration config
        )
        {
            DbConnectionString = connectionStrings;
            Logger = logger;
            Configuration = config;
        }

        protected Repository
        (
            IDbConnectionString connectionStrings,
            IHSPSession session,
            ILogger<Repository> logger,
            IConfiguration config
        )
        {
            DbConnectionString = connectionStrings;
            HSPSession = session ?? throw new ArgumentNullException(nameof(session));
            Logger = logger;
            Configuration = config;
        }

        #endregion Constructors

        /// <summary>
        /// This method returns 2 objects.
        ///     HSP Database Status row
        ///     List of items returned by the database.
        ///
        /// This method can be used for the API searches, when a stored procedure returns 2 result sets.
        /// </summary>
        /// <typeparam name="T">Type of Object to return</typeparam>
        /// <param name="storedProcedure">The name of the stored procedure to execute</param>
        /// <param name="parameters">An object containing the paramters for the stored procedure.</param>
        /// <returns>
        ///     HSPDbResult => a database result with the database status
        ///     ResultSet   => List of items in the result set.
        /// </returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<T> results)> GetAsync<T>(string storedProcedure, object parameters)
        {
            try
            {
                var rs = Enumerable.Empty<T>();

                Func<SqlMapper.GridReader, Task> readerProcessor = async reader
                    => rs = await reader.ReadAsync<T>();

                parameters = ParseParametersObjectForAttributeSearch(parameters);

                var dbResult =
                    await ExecuteReaderAsync<HSPSearchStatusRow>
                    (
                        storedProcedure,
                        parameters,
                        readerProcessor
                    );

                return (dbResult, rs);
            }
            catch (Exception e)
            {
                Logger.LogCritical(e, $"Exception in {nameof(GetAsync)}");
                throw;
            }
        }

        /// <summary>
        /// This method returns 2 objects.
        ///     HSP Database Status row
        ///     Item returned by the database.
        ///
        /// This method can be used for the API entity gets, when a stored procedure returns 2 result sets
        /// </summary>
        /// <typeparam name="T">Type of Object to return</typeparam>
        /// <param name="storedProcedure">The name of the stored procedure to execute</param>
        /// <param name="parameters">An object containing the paramters for the stored procedure.</param>
        /// <returns>
        ///     HSPDbResult => a database result with the database status
        ///     Results   => Item returned in the result set.
        /// </returns>
        public async Task<(HSPDbResult<TStatusRow> statusRow, T result)> GetOneAsync<TStatusRow, T>(string storedProcedure, object parameters) where TStatusRow : HSPStatusRow, new()
        {
            try
            {
                var rs = default(T);

                Func<SqlMapper.GridReader, Task> readerProcessor = async reader =>
                    rs = (await ReadResultSetAsync<T>(reader)).FirstOrDefault();

                parameters = ParseParametersObjectForAttributeSearch(parameters);

                var dbResult =
                    await ExecuteReaderAsync<TStatusRow>
                    (
                        storedProcedure,
                        parameters,
                        readerProcessor
                    );

                return (dbResult, rs);
            }
            catch (Exception e)
            {
                Logger.LogCritical(e, $"Exception in {nameof(GetOneAsync)}");
                throw;
            }
        }

        public async Task<HSPDbResult<HSPAddEntryStatusRow>> AddOneAsync(string storedProcedure, object parameters)
        {
            try
            {
                parameters = ParseParametersObjectForParameterRemoval(parameters);

                return
                    await AddWithReaderAsync
                    (
                        storedProcedure,
                        parameters,
                        readerProcessor: null
                    );
            }
            catch (Exception e)
            {
                Logger.LogCritical(e, $"Exception in {nameof(AddOneAsync)}");
                throw;
            }
        }

        /// <summary>
        /// Calls to SP that perform Adds and return a second resultset with the ID and
        /// any other information.
        /// </summary>
        public async Task<(HSPDbResult<TStatusRow> statusRow, T result)> AddOneAsync<TStatusRow, T>(string storedProcedure, object parameters) where TStatusRow : HSPStatusRow, new()
        {
            try
            {
                var result = default(T);

                var dbResult = await ExecuteReaderAsync<TStatusRow>
                                (
                                    storedProcedure, 
                                    parameters, 
                                    async reader => result = await reader.ReadFirstOrDefaultAsync<T>()
                                );

                return (dbResult, result);
            }
            catch (Exception e)
            {
                Logger.LogCritical(e, $"Exception in {nameof(AddOneAsync)}");
                throw;
            }
        }

        public async Task<HSPDbResult<TStatusRow>> ExecuteAsync<TStatusRow>(string storedProcedure, object parameters) where TStatusRow : HSPStatusRow, new()
        {
            try
            {
                parameters = ParseParametersObjectForParameterRemoval(parameters);

                return
                    await ExecuteReaderAsync<TStatusRow>
                    (
                        storedProcedure,
                        parameters
                    );
            }
            catch (Exception exception)
            {
                Logger.LogCritical(exception, $"Exception in {nameof(ExecuteAsync)}");
                throw;
            }
        }

        public async Task<(HSPDbResult<TStatusRow>, IEnumerable<T>)> ExecuteAsync<TStatusRow, T>(string storedProcedure, object parameters) where TStatusRow : HSPStatusRow, new()
        {
            try
            {
                parameters = ParseParametersObjectForParameterRemoval(parameters);
                var result = Enumerable.Empty<T>();

                var dbResult = await ExecuteReaderAsync<TStatusRow>
                                (
                                    storedProcedure,
                                    parameters,
                                    async reader => result = await reader.ReadAsync<T>()
                                );

                return (dbResult, result);
            }
            catch (Exception exception)
            {
                Logger.LogCritical(exception, $"Exception in {nameof(ExecuteAsync)}");
                throw;
            }
        }

        /// <summary>
        /// Execute a SQL call and use the passed in reader processor to process the results.
        /// </summary>
        public async Task<HSPDbResult<TStatusRow>> ExecuteAsync<TStatusRow>(string storedProcedure, object parameters, Func<SqlMapper.GridReader, Task> readerProcessor) where TStatusRow : HSPStatusRow, new()
        {
            try
            {
                parameters = ParseParametersObjectForParameterRemoval(parameters);

                return
                    await ExecuteReaderAsync<TStatusRow>
                    (
                        storedProcedure,
                        parameters,
                        readerProcessor
                    );
            }
            catch (Exception exception)
            {
                Logger.LogCritical(exception, $"Exception in {nameof(ExecuteAsync)}");
                throw;
            }
        }

        /// <summary>
        /// For stored procedures that return xml split in multiple result sets
        /// and do return status rows.
        /// </summary>
        /// <param name="storedProcedure">Name of the stored procedure.</param>
        /// <param name="parameters">Parameters for stored procedure.</param>
        /// <returns>Xml as string.</returns>
        public async Task<(HSPDbResult<TStatusRow> statusRow, string result)> GetXmlAsync<TStatusRow>(string storedProcedure, object parameters) where TStatusRow : HSPStatusRow, new()
        {
            try
            {
                var sb = new StringBuilder();

                Func<SqlMapper.GridReader, Task> readerProcessor = async reader
                    =>
                    {
                        while (!reader.IsConsumed)
                        {
                            // each result set can contain more than 1 line if enough data
                            // so concatenate them
                            sb.Append(string.Join(string.Empty, await reader.ReadAsync<string>()));
                        }
                    };

                parameters = ParseParametersObjectForAttributeSearch(parameters);

                var dbResult =
                    await ExecuteReaderAsync<TStatusRow>
                    (
                        storedProcedure,
                        parameters,
                        readerProcessor
                    );

                return (dbResult, sb.ToString());
            }
            catch (Exception e)
            {
                Logger.LogCritical(e, $"Exception in {nameof(GetXmlAsync)}");
                throw;
            }
        }

        /// <summary>
        /// For stored procedures that return xml split in multiple result sets.
        /// Some of these procedures only return a status row when an error occurs, so this overload will be used for those scenarios.
        /// For xml procedures that return multiple result sets and return a status row, 
        /// we can use ExecuteReaderAsync and pass a processor that reads all rows.
        /// </summary>
        /// <param name="storedProcedure">Name of the stored procedure.</param>
        /// <param name="parameters">Parameters for stored procedure.</param>
        /// <returns>Xml as string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetXmlAsync(string storedProcedure, object parameters)
        {
            try
            {
                var dbResult = new HSPDbResult<HSPStatusRow>();
                var sb = new StringBuilder();

                using (SqlConnection connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
                {
                    SetupInfoMessageHandling(connection, dbResult);

                    using var dapperResult =
                        await connection.QueryMultipleAsync
                            (
                                storedProcedure,
                                parameters,
                                commandType: CommandType.StoredProcedure,
                                commandTimeout: CommandTimeout
                            );

                    // SP doesn't return status row, only on error
                    // so if status row is null, then no error and we can read and set it to normal
                    if (dbResult.StatusRow == null)
                    {
                        while (!dapperResult.IsConsumed)
                        {
                            // each result set can contain more than 1 line if enough data
                            // so concatenate them
                            sb.Append(string.Join(string.Empty, await dapperResult.ReadAsync<string>()));
                        }

                        dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.Normal };
                        dbResult.StatusRow.Success = true;
                    }
                    else
                    {
                        // error was returned, so read status row
                        dbResult.StatusRow = await dapperResult.ReadFirstAsync<HSPStatusRow>();
                    }

                    return (dbResult, sb.ToString());
                }
            }
            catch (Exception e)
            {
                Logger.LogCritical(e, $"Exception in {nameof(GetXmlAsync)}");
                throw;
            }
        }

        #region Private Methods

        private async Task<IEnumerable<T>> ReadResultSetAsync<T>(SqlMapper.GridReader reader)
            => await reader.ReadAsync<T>();

        private async ValueTask<HSPDbResult<TStatusRow>> ExecuteReaderAsync<TStatusRow>(string storedProcedure, object parameters, Func<SqlMapper.GridReader, Task> readerProcessor = null) where TStatusRow : HSPStatusRow, new()
        {
            var dbResult = new HSPDbResult<TStatusRow>();
            using (SqlConnection connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
            {
                SetupInfoMessageHandling(connection, dbResult);

                using var dapperResult =
                    await connection.QueryMultipleAsync
                        (
                            storedProcedure,
                            parameters,
                            commandType: CommandType.StoredProcedure,
                            commandTimeout: CommandTimeout
                        );

                // if the status row has been initialized, it means an exception was thrown
                if (dbResult.DbStatus != HSPDbStatus.Uninitialized)
                {
                    using (dapperResult)
                    {
                        throw new HSPRepositoryException(dbResult.DbStatus, dbResult.ErrorMessage);
                    }
                }

                var statusRow =
                    await dapperResult
                        .ReadFirstOrDefaultAsync<TStatusRow>();

                dbResult.StatusRow = statusRow ?? new TStatusRow() { Status = HSPDbStatus.ServerError };

                dbResult.StatusRow.Success =
                     dbResult.StatusRow.Status == HSPDbStatus.Normal;

                if (dbResult.DbStatus == HSPDbStatus.Normal && readerProcessor != null)
                    await readerProcessor(dapperResult);
            }

            return dbResult;
        }

        /// <summary>
        /// Identifies existing errors on the SqlConnection
        /// and updates the database status object accordingly.
        /// </summary>
        /// <typeparam name="TStatusRow">Type of StatusRow</typeparam>
        /// <param name="connection">The DbConnection object</param>
        /// <param name="result">StatusRow object</param>
        protected void SetupInfoMessageHandling<TStatusRow>(SqlConnection connection, HSPDbResult<TStatusRow> result) where TStatusRow : HSPStatusRow, new()
        {
            connection.FireInfoMessageEventOnUserErrors = true;
            connection.InfoMessage += (sender, sqlEventArgs) =>
            {
                SqlError error = sqlEventArgs.Errors.OfType<SqlError>().FirstOrDefault();

                if (error != null)
                {
                    if (error.Class == 16 && new int[] { 50001, 50002, 50003 }.Contains(error.Number))
                    {
                        var statusRow = new TStatusRow();
                        // application error should be 50003 and server 50002
                        // db error functions need to be updated
                        statusRow.Status = error.Number switch
                        {
                            50001 => HSPDbStatus.BusinessError,
                            50002 => HSPDbStatus.ApplicationError,
                            50003 => HSPDbStatus.ServerError,
                            _ => HSPDbStatus.ServerError
                        };
                        result.StatusRow = statusRow;
                        result.ErrorMessage = error.Message;
                    }
                    else
                    {
                        result.StatusRow =
                            new TStatusRow()
                            {
                                Status = HSPDbStatus.Uninitialized
                            };

                        result.ErrorMessage = ParseHSPRaiseErrorMessage(error);
                    }
                }
            };
        }

        /// <summary>
        /// Parses a SqlError message
        ///
        /// If the error messages matches a specific regular expression, a custom user message
        /// gets returned. If there is no match, the SqlError message gets returned.
        /// </summary>
        /// <param name="sqlError">SqlError object</param>
        /// <returns>string</returns>
        private string ParseHSPRaiseErrorMessage(SqlError sqlError)
        {
            var _parseSqlErrorMessage =
                new Regex
                (
                    @"(?:<)(?<FieldName>\w+?)(?:>=)(?<Val>.+?)(?=(?:;)(?=<\w+>=)|$|;$)",
                    RegexOptions.Singleline
                );

            var userMessageValue =
                _parseSqlErrorMessage
                    .Matches(sqlError.Message)
                    .OfType<Match>()
                    .Where(m => m.Success)
                    .Where(m => m.Groups["FieldName"].Value.Equals("UserMessage", StringComparison.OrdinalIgnoreCase))
                    .Select(m => m.Groups["Val"].Value.Trim())
                    .FirstOrDefault();

            return userMessageValue ?? sqlError.Message;
        }

        /// <summary>
        /// Get an object that represents the parameters for the stored procedure.
        ///
        /// If the input object contains a property with the name CustomAttributeSearch
        /// it will then attempt to convert it to XML for our stored procedure by
        /// a series of JSON to XML serialization calls.
        ///
        /// This method can be modified to work with other XML based parameters if needed.
        ///
        /// </summary>
        /// <param name="input">Object</param>
        /// <returns>Object</returns>
        private object ParseParametersObjectForAttributeSearch(object input)
        {
            IDictionary<string, string> dynParams =
                new Dictionary<string, string>();

            var output = input;
            bool useExpando = false;
            var type = input.GetType();

            dynamic attribForXml = null;

            var props = new List<PropertyInfo>(type.GetProperties());

            if (type == typeof(ExpandoObject))
            {
                var property =
                    ((ExpandoObject)input as IDictionary<string, object>)
                        .ToList()
                        .Where(x => x.Key == "CustomAttributeSearch")
                        .FirstOrDefault().Value;

                ((ExpandoObject)input as IDictionary<string, object>)
                    .Where(x => x.Key != "CustomAttributeSearch")
                    .ToList()
                    .ForEach(x => dynParams.Add(x.Key, x.Value.ToString()));

                if (property != null)
                    attribForXml = property;
            }
            else
            {
                PropertyInfo property =
                    props.ToList()
                        .Where(x => x.Name == "CustomAttributeSearch")
                        .FirstOrDefault();

                props.ToList()
                    .Where(x => x.Name != "CustomAttributeSearch")
                    .ToList()
                    .ForEach(x => dynParams.Add(x.Name, x.GetValue(input)?.ToString()));

                if (property != null)
                    attribForXml = property.GetValue(input);

                // if we have a static request type and the custom attribute search is null
                // we'll proceed with using expando so the parameter is not added
                // to the SP call.
                if (property != null
                    && attribForXml == null)
                {
                    useExpando = true;
                }
            }

            string xmlAttribSearch = string.Empty;

            if (attribForXml != null)
            {
                var obj = attribForXml;
                var objForXml = new { CustomAttributeSearch = obj };
                var jsonForXml = JsonConvert.SerializeObject(objForXml);
                var doc = JsonConvert.DeserializeXmlNode(jsonForXml);
                xmlAttribSearch = doc.InnerXml.ToString();
                useExpando = true;
            }

            if (useExpando)
            {
                var expObj = new ExpandoObject() as IDictionary<string, object>;
                dynParams.ToList().ForEach(x => expObj.Add(x.Key, x.Value));
                expObj.Add("CustomAttributeSearchXML", xmlAttribSearch);
                output = expObj;
            }
            return output;
        }

        /// <summary>
        /// Get an object that represents the parameters for the stored procedure.
        ///
        /// If the input object contains a property decorated with the name RemovableParameter
        /// attribute, it will be removed.
        /// </summary>
        /// <param name="input">Object</param>
        /// <returns>Object</returns>
        private object ParseParametersObjectForParameterRemoval(object input)
        {
            var output = new ExpandoObject() as IDictionary<string, object>;

            var type = input.GetType();
            var props = new List<PropertyInfo>(type.GetProperties());

            foreach (var prop in props)
            {
                var attr = prop.GetCustomAttributes(typeof(RemovableParameterAttribute)).FirstOrDefault();
                if (attr == null)
                    output.Add(prop.Name, prop.GetValue(input)); ;
            }
            return (object)output;
        }

        /// <summary>
        /// Adds a new entry in the database, utilizing a stored procedure.
        /// Allows for processing of a resultset (usually creating/updating/deleting
        /// processes return only the number of affected rows).
        /// </summary>
        /// <param name="storedProcedure">stored procedure to execute</param>
        /// <param name="parameters">parameters to use in the procedure</param>
        /// <param name="readerProcessor">reader processor for the resultset, if applicable</param>
        /// <returns></returns>
        private async ValueTask<HSPDbResult<HSPAddEntryStatusRow>> AddWithReaderAsync
        (
            string storedProcedure,
            object parameters,
            Func<SqlMapper.GridReader, Task> readerProcessor = null
        )
        {
            var dbResult = new HSPDbResult<HSPAddEntryStatusRow>();
            using (SqlConnection connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
            {
                SetupInfoMessageHandling(connection, dbResult);

                var dapperResult =
                    await connection.QueryMultipleAsync
                        (
                            sql: storedProcedure,
                            param: parameters,
                            commandType: CommandType.StoredProcedure,
                            commandTimeout: CommandTimeout
                        );

                // if the status row has been initialized, it means an exception was thrown
                if (dbResult.DbStatus != HSPDbStatus.Uninitialized)
                    throw new HSPRepositoryException(dbResult.DbStatus, dbResult.ErrorMessage);

                var statusRow = new HSPAddEntryStatusRow();

                // Manually processing the result allows us to capture
                // the status and newly added EntityId.
                //
                // Each Add procedure returns the Status of the request
                // and the new EntityId aliased as the PrimaryKey
                // Example: AddPerson => Status: 0, PersonId: {ID}
                var resultSet = await dapperResult.ReadAsync();
                if (resultSet.Any())
                {
                    var row = (IDictionary<string, object>)
                        resultSet.FirstOrDefault();

                    statusRow.Status = (HSPDbStatus)Convert.ToInt32(row.ElementAt(0).Value);
                    statusRow.EntityId = Convert.ToInt32(row.ElementAt(1).Value);
                }

                statusRow.Success =
                     statusRow.Status == HSPDbStatus.Normal;

                dbResult.StatusRow = statusRow ?? new HSPAddEntryStatusRow() { Status = HSPDbStatus.ServerError };

                if (dbResult.DbStatus == HSPDbStatus.Normal && readerProcessor != null)
                    await readerProcessor(dapperResult);
            }

            return dbResult;
        }

        #endregion Private Methods
    }
}