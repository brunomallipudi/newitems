﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// Custom Attributes repository.
    /// </summary>
    public class CustomAttributesRepository : Repository, ICustomAttributesRepository
    {
        #region Procedure Names

        public const string HSP_SP_AddEntityAttributes = "ee_AddEntityAttributes";
        public const string HSP_SP_GetCustomAttributesCategory = "ee_GetCustomAttributesCategory";
        public const string HSP_SP_GetCustomAttributesForEntity = "ee_GetAttributesForEntity";
        public const string HSP_SP_GetCustomAttributeHistoryXMLForEntity = "ee_GetCustomAttributeHistoryXMLForEntity";
        public const string HSP_SP_GetListValues = "ee_GetListValues";
        public const string HSP_SP_GetCustomAttributes_V2 = "ee_GetCustomAttributes_V2";
        public const string HSP_SP_GetCustomAttributes_V3 = "ee_GetCustomAttributes_V3";
        public const string HSP_SP_GetEntityAttributeMappings = "ee_GetEntityAttributeMappings";

        #endregion Procedure Names

        #region Constructors

        public CustomAttributesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public CustomAttributesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Gets the values of a list.
        /// </summary>
        /// <param name="parameters">
        ///     SessionId   => HSP SessionId.
        ///     ListName    => Name of the list.
        ///     EntityId    => Id of the Entity.
        ///     EntityType  => Type of the Entity.
        ///     EntityAttributeMapperId => Id of the Entity Attribute mapping.
        ///     UseAdvancedFiltering => Does it use Advanced Filtering. Y or N.
        ///     Usage       => Stored procedure usage.
        ///     ListValue   => Filter by a specific value.
        ///     ResultCount => How many rows to return.
        /// </param>
        /// <returns>
        /// Values from a specific list.
        /// </returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ListValueDto> results)> GetListValues(object parameters)
            => await GetAsync<ListValueDto>(HSP_SP_GetListValues, parameters);

        /// <summary>
        /// Gets the custom attribute categories.
        /// </summary>
        /// <param name="parameters">Custom attribute categories request.</param>
        /// <returns>List of custom attribute categories.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributeCategoryDto> results)> GetCustomAttributesCategory(object parameters)
            => await GetAsync<CustomAttributeCategoryDto>(HSP_SP_GetCustomAttributesCategory, parameters);

        /// <summary>
        /// Get the custom attributes mapped to an entity.
        /// </summary>
        /// <param name="parameters">Custom attributes mapped to an entity request.</param>
        /// <returns>List of custom attributes mapped to an entity.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributeEntityMappingDto> results)> GetCustomAttributesForEntity(object parameters)
            => await GetAsync<CustomAttributeEntityMappingDto>(HSP_SP_GetCustomAttributesForEntity, parameters);

        /// <summary>
        /// Add a custom attribute entity value.
        /// </summary>
        /// <param name="parameters">Custom attribute entity value request.</param>
        /// <returns>Status row of the mapping value request.</returns>
        public async Task<HSPDbResult<HSPAddEntryStatusRow>> AddEntityAttributes(object parameters)
            => await ExecuteAsync<HSPAddEntryStatusRow>(HSP_SP_AddEntityAttributes, parameters);

        /// <summary>
        /// Get the custom attribute entity values history in xml.
        /// </summary>
        /// <param name="parameters">Custom attribute entity values history request.</param>
        /// <returns>Xml string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetCustomAttributeHistoryXMLForEntity(object parameters)
            => await GetXmlAsync(HSP_SP_GetCustomAttributeHistoryXMLForEntity, parameters);

        /// <summary>
        /// Get custom attributes, version 2.
        /// </summary>
        /// <param name="parameters">Custom attributes V2</param>
        /// <returns>List of custom attributes</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributes_V2Dto> results)> GetCustomAttributesV2(object parameters)
            => await GetAsync<CustomAttributes_V2Dto>(HSP_SP_GetCustomAttributes_V2, parameters);

        /// <summary>
        /// Get custom attributes, version 3.
        /// </summary>
        /// <param name="parameters">Custom attributes V3</param>
        /// <returns>List of custom attributes</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CustomAttributes_V3Dto> results)> GetCustomAttributesV3(object parameters)
            => await GetAsync<CustomAttributes_V3Dto>(HSP_SP_GetCustomAttributes_V3, parameters);

        /// <summary>
        /// Get Entity Attribute Mappings
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>List of Entity Attribute Mappings</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EntityAttributeMappingDto> results)> GetEntityAttributeMappings(object parameters)
            => await GetAsync<EntityAttributeMappingDto>(HSP_SP_GetEntityAttributeMappings, parameters);
    }
}
