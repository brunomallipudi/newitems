﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.ListViewProfileSettings;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// ListViewProfileSettings Repository
    /// </summary>
    public class ListViewProfileSettingsRepository
        : Repository, IListViewProfileSettingsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GETLISTVIEWPROFILESETTINGS = "EE_GETLISTVIEWPROFILESETTINGS";
        public const string HSP_SP_SaveListviewProfileSettings = "ee_SaveListviewProfileSetting";

        #endregion Procedure Names

        #region Constructors

        public ListViewProfileSettingsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public ListViewProfileSettingsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Returns a ListViewProfileSetting from the stored procedure.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, ListViewProfileSettingDto result)> GetListViewProfileSettingsAsync(object parameters)
                => await GetOneAsync<HSPStatusRow, ListViewProfileSettingDto>(HSP_SP_GETLISTVIEWPROFILESETTINGS, parameters);

        /// <summary>
        /// Update Profile Setting
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> SaveListviewProfileSettings(object parameters)
        {
            return await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_SaveListviewProfileSettings,
                    parameters
                );
        }
    }
}