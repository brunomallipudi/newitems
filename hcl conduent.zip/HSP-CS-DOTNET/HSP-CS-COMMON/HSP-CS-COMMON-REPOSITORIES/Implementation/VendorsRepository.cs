﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class VendorsRepository : Repository, IVendorsRepository
    {
        public const string HSP_SP_GetVendors = "ee_GetVendors";
        public const string HSP_SP_GetVendorProfile_XML = "ee_GetVendorProfile_XML";

        public VendorsRepository(IDbConnectionString connectionStrings, ILogger<VendorsRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Get a list of Vendors.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Vendors.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<VendorDto> results)> GetVendors(object parameters)
        {
            return await GetAsync<VendorDto>(HSP_SP_GetVendors, parameters);
        }

        /// <summary>
        /// Returns the Vendor's profile xml.
        /// </summary>
        /// <param name="parameters">Request for Vendor profile xml.</param>
        /// <returns>Vendor's profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetVendorProfile_XML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetVendorProfile_XML, parameters);
    }
}