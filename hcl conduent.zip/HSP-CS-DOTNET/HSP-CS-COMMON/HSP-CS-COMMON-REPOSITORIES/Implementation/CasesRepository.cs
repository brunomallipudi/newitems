﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Cases;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class CasesRepository : Repository, ICasesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetCases = "ee_GetCases";

        #endregion

        #region constructors

        public CasesRepository(IDbConnectionString connectionStrings, ILogger<CasesRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        #endregion

        /// <summary>
        /// Get the list of cases.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return the list of cases</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CaseDto> results)> GetCases(object parameters)
            => await GetAsync<CaseDto>(HSP_SP_GetCases, parameters);
    }
}
