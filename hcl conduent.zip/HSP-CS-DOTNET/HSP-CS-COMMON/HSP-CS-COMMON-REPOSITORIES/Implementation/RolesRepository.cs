﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Roles;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class RolesRepository : Repository, IRolesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetBillingRolesForUser = "ee_GetBillingRolesForUser";
        public const string HSP_SP_GetRoles = "ee_GetRoles";

        #endregion Procedure Names

        #region Constructors

        public RolesRepository (IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public RolesRepository (IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get Billing Roles for Users.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>User's Billing Roles</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BillingRoleDto> results)> GetBillingRolesforUser(object parameters)
            => await GetAsync<BillingRoleDto>(HSP_SP_GetBillingRolesForUser, parameters);

        /// <summary>
        /// Get Roles.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>List of Roles</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RoleDto> results)> GetRoles(object parameters)
            => await GetAsync<RoleDto>(HSP_SP_GetRoles, parameters);
    }
}
