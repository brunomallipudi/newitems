﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Explanations;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ExplanationsRepository
        : Repository, IExplanationsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetExplanations = "ee_GetExplanations";
        public const string HSP_SP_GetExplanationCategories = "ee_GetExplanationCategories";

        #endregion Procedure Names

        #region Constructors

        public ExplanationsRepository(IDbConnectionString connectionStrings, ILogger<ExplanationsRepository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public ExplanationsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<ExplanationsRepository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of Explanation
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ExplanationDto> results)> GetExplanations(object parameters)
            => await GetAsync<ExplanationDto>(HSP_SP_GetExplanations, parameters);

        /// <summary>
        /// Get a list of Explanation categories
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ExplanationCategoryDto> results)> GetExplanationCategories(object parameters)
            => await GetAsync<ExplanationCategoryDto>(HSP_SP_GetExplanationCategories, parameters);
    }
}