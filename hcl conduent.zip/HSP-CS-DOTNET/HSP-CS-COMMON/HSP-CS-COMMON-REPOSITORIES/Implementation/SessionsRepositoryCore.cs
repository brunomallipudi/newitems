﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Implementation;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Sessions;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// SessionsRepository : Entity Framework
    /// </summary>
    public class SessionsRepositoryCore : ISessionsRepository
    {
        private readonly HSPDbContext context;
        private readonly IConfiguration _config;

        /// <summary>
        /// Needed in order to generate PKey
        /// </summary>
        private readonly ITableIdsRepository _tableIdsRepository;

        /// <summary>
        /// Needed in order to generate PKey
        /// </summary>
        private static readonly string NEWID_IDENTIFIER = "SESSION";

        public SessionsRepositoryCore(HSPDbContext ctx, IConfiguration config, ITableIdsRepository tableIdsRepository)
        {
            context = ctx;
            _config = config;
            _tableIdsRepository = tableIdsRepository;
        }

        /// <summary>
        /// Connects a logged on user to the database and provides a SessionId
        /// </summary>
        /// <remarks>
        /// We will not be implementing automatic user disconnect here.
        /// The Web UI is responsible for handling the flow.
        ///
        /// Attempting to force disconnection on a non existing or already disconnerted
        /// session will result in Success being false.
        /// </remarks>
        /// <param name="username">Logged on username</param>
        /// <param name="disconnectOldSession">Whether to disconnect an existing session.</param>
        /// <returns></returns>
        public async Task<(HSPDbResult<SessionStatusRow> StatusRow, IEnumerable<ExistingSessionDto> results)> ConnectUserAsync(string userName, bool disconnectOldSession, string webSessionId)
        {
            var sessionsList = new List<ExistingSessionDto>();
            var statusRow = new SessionStatusRow();
            var dbResult = new HSPDbResult<SessionStatusRow>();

            var compatibilityResult =
                await GetAppVersionCompatibilityAsync();

            if (compatibilityResult.IsCompatible)
            {

                var userId = 0;
                var user =
                    await context.Users
                        .Where(x => x.UserName == userName)
                        .FirstOrDefaultAsync();

                if (user != null)
                    userId = user.UserId;

                //  In the stored procedure there is code
                //  that checks whether a user has access to the product.
                if (userId != 0 && await HasAccessAsync(userId))
                {
                    var sessions = await GetOpenSessionAsync(userId);

                    //  If there is an open session and the user is not forcing
                    //  the disconnection, show them the last active session.
                    if (sessions.Any() && !disconnectOldSession)
                    {
                        statusRow.Status = HSPDbStatus.ApplicationError;
                        statusRow.ErrorMessage = "Could not create session; user already has active session.";
                        statusRow.HasOpenSessions = "Y";
                        statusRow.UserId = userId;

                        sessions.ToList().ForEach(
                            x => sessionsList.Add(
                                    new ExistingSessionDto
                                    {
                                        ComputerName = x.ComputerName,
                                        ConnectTime = x.ConnectTime,
                                        FullName = x.User.FullName
                                    }
                            ));
                    }

                    //  Force disconnect.
                    var sessionDisconnected = false;
                    if (sessions.Any() && disconnectOldSession)
                        sessionDisconnected =
                            await DisconnectUserAsync(sessions.FirstOrDefault().SessionId, webSessionId, true);

                    if (
                        //  This blocks the ability to always force a connection
                        //  Implemented to match the stored procedure functionality
                        //  Removing ther && !disconnectOldSession will allow to always
                        //  force disconnect
                        (!sessions.Any() && !disconnectOldSession)
                        //  This allows to force disconnect
                        || (sessions.Any() && disconnectOldSession && sessionDisconnected))
                    {
                        var newSession = await AddSessionAsync(userId, webSessionId);
                        statusRow.Status = HSPDbStatus.Normal;
                        statusRow.UserId = userId;
                        statusRow.SessionId = newSession.SessionId;
                    }
                }
                else
                {
                    if(userId == 0)
                    {
                        statusRow.Status = HSPDbStatus.ApplicationError;
                        statusRow.ErrorMessage = "Authentication fails for given username and password";
                        statusRow.HasOpenSessions = null;
                    }
                }
            } // ENDIF - ISCOMPATIBLE
            else {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = 
                    $"The application version {compatibilityResult.AppVersion} " +
                    $"does not match the database version {compatibilityResult.DbAppVersion}.";
                statusRow.HasOpenSessions = null;
            }

            dbResult.StatusRow = statusRow;
            return (dbResult, sessionsList);
        }

        /// <summary>
        /// Add a new HSP Session
        /// </summary>
        /// <param name="userId">userId</param>
        /// <param name="webSessionId">computer name or web session id</param>
        /// <returns></returns>
        public async Task<Session> AddSessionAsync(int userId, string webSessionId)
        {
            //  In this instance we are calling GetNewId directly from another repository
            //  Our repositories and services are different projects and we cannot add
            //  cyclic dependencies.
            //
            //  This approach is also very simple, and easy to follow.
            var newId = await _tableIdsRepository.GetNewIdAsync(NEWID_IDENTIFIER);

            var session = new Session
            {
                SessionId = newId,
                UserId = userId,
                RoleId = 0,
                ProductName = _config["HSPSessionManagement:AppName"],
                ProductVersion = _config["HSPSessionManagement:AppVersion"],
                ComputerName = webSessionId,
                ConnectTime = DateTime.Now
            };

            await context.Sessions.AddAsync(session);
            await context.SaveChangesAsync();
            return session;
        }

        /// <summary>
        /// Disconnect a user
        ///
        /// When passing IsForced TRUE, it is the same as utilizing USAGE3
        /// </summary>
        /// <param name="sessionId">sessionId</param>
        /// <param name="webSessionId">computer name or web saession id</param>
        /// <param name="isForced">true|false</param>
        /// <returns></returns>
        public async Task<bool> DisconnectUserAsync(int sessionId, string webSessionId = null, bool isForced = false)
        {
            var session =
                await context.Sessions
                    .Where(x => x.SessionId == sessionId)
                    .FirstOrDefaultAsync();

            if (session != null)
            {
                session.DisconnectMode = isForced ? "FORCED" : "NORMAL";
                session.DisconnectedBy = session.UserId;
                session.DisconnectedFrom = webSessionId;
                session.DisconnectTime = DateTime.Now;
                var res = await context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Whether the user has access to use the product
        /// Code extracted from the stored procedure.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<bool> HasAccessAsync(int userId)
            => await
                (
                    from ur in context.UserRoles
                    join r in context.Roles
                        on ur.RoleId equals r.RoleId
                    where ur.UserId == userId
                    where r.RoleStatus == "2"
                    where r.RoleType == "FBA"
                    select r.RoleId
                ).AnyAsync();

        /// <summary>
        /// Gets the last open session for a user and a product
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Session>> GetOpenSessionAsync(int userId)
        {
            return await
               (
                   from session in context.Sessions
                   where session.UserId == userId
                   where session.ProductName == _config["HSPSessionManagement:AppName"]
                   where session.ProductVersion == _config["HSPSessionManagement:AppVersion"]
                   where session.DisconnectTime == null
                   orderby session.SessionId descending
                   select session
               ).Take(1).ToListAsync();
        }

        /// <summary>
        /// Checks the application version against the database application version
        /// 
        /// If in the configuration file we are not enforcing the version checking,
        /// this will always return Compatible = TRUE, even if the versions are different
        /// 
        /// This ensures that we can flip a switch and continue development without
        /// having to wait for a new redeployed version.
        /// </summary>
        /// <returns>
        /// (string) AppVersion from the config file
        /// (string) AppVersion fron the database entry
        /// (Bool) Whether it is compatible or not.
        /// </returns>
        public async Task<(string AppVersion, string DbAppVersion, bool IsCompatible)> GetAppVersionCompatibilityAsync()
        {
            var enforceCheck = 
                Convert.ToBoolean(_config["HSPSessionManagement:EnforceCompatibilityCheck"]);

            var cmEntry = await
                (
                    from cm in context.VersionCompatibilityMap
                    where cm.ProductName == _config["HSPSessionManagement:AppName"]
                    select cm
                ).FirstOrDefaultAsync();

            return
            (
                _config["HSPSessionManagement:AppVersion"],
                cmEntry?.AppVersion,
                enforceCheck
                    ? _config["HSPSessionManagement:AppVersion"] == cmEntry?.AppVersion
                    : true
            );
        }

        /// <summary>
        /// Checks if the session is valid or not.
        /// </summary>
        /// <param name="sessionId">Id of the session</param>
        /// <returns>If session is still valid or not, UserId and ProductName.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> StatusRow, int UserId, string ProductName)> CheckSessionAsync(int sessionId)
        {
            var dbResult = new HSPDbResult<HSPStatusRow>();
            var statusRow = new HSPStatusRow();

            var openSession = await (from session in context.Sessions
                                     where session.SessionId == sessionId
                                       && session.DisconnectTime == null
                                     select new { session.UserId, session.ProductName }
                                    ).FirstOrDefaultAsync();

            if (openSession == null)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = "Your session is no longer valid. Please create a new session.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, 0, string.Empty);
            }
            else
            {
                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                dbResult.StatusRow = statusRow;
                return (dbResult, openSession.UserId, openSession.ProductName);
            }
        }

        /// <summary>
        /// Checks if the session is valid or not.
        /// </summary>
        /// <param name="sessionId">Id of the session</param>
        /// <returns>If session is still valid or not, UserId and ProductName.</returns>
        public async Task<(HSPDbResult<TStatusRow> StatusRow, int UserId, string ProductName)> CheckSessionAsync<TStatusRow>(int sessionId) where TStatusRow : HSPStatusRow, new()
        {
            var dbResult = new HSPDbResult<TStatusRow>();
            var statusRow = new TStatusRow();

            var openSession = await(from session in context.Sessions
                                    where session.SessionId == sessionId
                                      && session.DisconnectTime == null
                                    select new { session.UserId, session.ProductName }
                                    ).FirstOrDefaultAsync();

            if (openSession == null)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = "Your session is no longer valid. Please create a new session.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, 0, string.Empty);
            }
            else
            {
                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                dbResult.StatusRow = statusRow;
                return (dbResult, openSession.UserId, openSession.ProductName);
            }
        }
    }
}