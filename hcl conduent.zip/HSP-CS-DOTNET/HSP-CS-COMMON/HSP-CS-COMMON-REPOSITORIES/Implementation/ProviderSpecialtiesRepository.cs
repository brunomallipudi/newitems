﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.ProviderSpecialties;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ProviderSpecialtiesRepository
        : Repository, IProviderSpecialtiesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GETPROVIDERSPECIALTIES = "EE_GETPROVIDERSPECIALTIES";

        #endregion Procedure Names

        #region Constructors

        public ProviderSpecialtiesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public ProviderSpecialtiesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of provider specialties
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ProviderSpecialtyDto> results)> GetProviderSpecialties(object parameters)
            => await GetAsync<ProviderSpecialtyDto>(HSP_SP_GETPROVIDERSPECIALTIES, parameters);
    }
}