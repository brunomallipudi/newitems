﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class TransmittalsRepository : Repository, ITransmittalsRepository
    {
        #region Procedure Names

        public const string HSP_SP_CreateTransmittals = "rr_CreateTransmittals";

        #endregion Procedure Names

        #region Constructors

        public TransmittalsRepository(IDbConnectionString connectionStrings, ILogger<TransmittalsRepository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public TransmittalsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<TransmittalsRepository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Create Transmittals
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> CreateTransmittals(object parameters)
            => await GetAsync<dynamic>(HSP_SP_CreateTransmittals, parameters);
    }
}
