﻿using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Notes;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class NotesRepository 
        : Repository, INotesRepository
    {
        private HSPDbContext _context;

        #region Procedure Names

        public const string HSP_SP_GetNotesCategories = "ee_GetNotesCategories";
        public const string HSP_SP_GetNotes = "ee_GetDataForEntity";

        #endregion Procedure Names

        #region Constructors

        public NotesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config, HSPDbContext context) : base(connectionStrings, logger, config)
        {
            _context = context;
        }

        public NotesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get list of Notes Categories
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<NotesCategoriesDto> results)> GetNotesCategories(object parameters)
        {
            (var status, var result) =
                await GetAsync<NotesCategoriesDto>
                (
                    HSP_SP_GetNotesCategories,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Get Notes for Entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Notes for Entity</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<NoteDto> results)> GetNotes(object parameters)
        {
            (var status, var result) =
                await GetAsync<NoteDto>
                (
                    HSP_SP_GetNotes,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Get amount of notes for an entity
        /// </summary>
        /// <param name="entityType">Entity Type</param>
        /// <param name="entityId">Id of the entity</param>
        /// <returns>The amount of notes for an entity</returns>
        public async Task<int> GetNotesCount(string entityType, int entityId)
            => await _context.EntityData
                             .CountAsync(data => data.EntityType == entityType
                                                && data.EntityId == entityId
                                                && data.SchemaType == "NOTES");
    }
}
