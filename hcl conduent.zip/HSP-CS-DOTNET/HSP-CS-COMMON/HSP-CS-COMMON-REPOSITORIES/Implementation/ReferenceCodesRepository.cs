﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ReferenceCodesRepository : Repository, IReferenceCodesRepository
    {
        public const string HSP_SP_GETREFERENCECODES = "EE_GETREFERENCECODES_V2";
        public const string HSP_SP_GetEntityReferenceCodeMap = "ee_GetEntityReferenceCodeMap";

        public ReferenceCodesRepository(IDbConnectionString connectionStrings, ILogger<ReferenceCodesRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReferenceCode> results)> GetReferenceCodes(object parameters)
        {
            return await GetAsync<ReferenceCode>(HSP_SP_GETREFERENCECODES, parameters);
        }

        /// <summary>
        /// Get Entity Reference Code Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EntityReferenceCodeMapDto> results)> GetEntityReferenceCodeMap(object parameters)
            => await GetAsync<EntityReferenceCodeMapDto>(HSP_SP_GetEntityReferenceCodeMap, parameters);
   }
}