﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Records;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class RecordsRepository
        : Repository, IRecordsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetDocumentRequestRecords = "ee_GetDocumentRequestRecords";
        public const string HSP_SP_GetRecords = "ee_GetRecords";
        public const string HSP_SP_GetRecordDetails = "ee_GetRecordDetails";

        #endregion Procedure Names

        #region constructors

        public RecordsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public RecordsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion constructors

        /// <summary>
        /// Get Document Request Records
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DocumentRequestRecordDto> results)> GetDocumentRequestRecords(object parameters)
            => await GetAsync<DocumentRequestRecordDto>(HSP_SP_GetDocumentRequestRecords, parameters);

        /// <summary>
        /// Get Records
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RecordDto> results)> GetRecords(object parameters)
            => await GetAsync<RecordDto>(HSP_SP_GetRecords, parameters);

        /// <summary>
        /// Get Record Details
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<RecordDetailDto> results)> GetRecordDetails(object parameters)
            => await GetAsync<RecordDetailDto>(HSP_SP_GetRecordDetails, parameters);
    }
}