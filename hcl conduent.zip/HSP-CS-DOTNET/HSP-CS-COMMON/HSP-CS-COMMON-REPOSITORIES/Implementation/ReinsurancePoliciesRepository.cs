﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.ReinsurancePolicies;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ReinsurancePoliciesRepository : Repository, IReinsurancePoliciesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetReinsurancePolicies = "ee_GetReinsurancePolicies";

        #endregion Procedure Names

        #region Constructors

        public ReinsurancePoliciesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public ReinsurancePoliciesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of ReinsurancePolicies
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReinsurancePolicyDto> results)> GetReinsurancePolicies(object parameters)
            => await GetAsync<ReinsurancePolicyDto>(HSP_SP_GetReinsurancePolicies, parameters);
    }
}
