﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Companies;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class CompaniesRepository : Repository, ICompaniesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetCompanies = "ee_GetCompanies";

        #endregion Procedure Names

        #region Constructors

        public CompaniesRepository(IDbConnectionString connectionStrings, ILogger<CompaniesRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public CompaniesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<CompaniesRepository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get Companies
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>List of Companies</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CompanyDto> results)> GetCompanies(object parameters)
            => await GetAsync<CompanyDto>(HSP_SP_GetCompanies, parameters);
    }
}
