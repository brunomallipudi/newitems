﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class StyleSheetsRepository : Repository, IStyleSheetsRepository
    {
        private ILogger<StyleSheetsRepository> _loggerDocuments;
        #region Constructors

        public StyleSheetsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, ILogger<StyleSheetsRepository> loggerDocuments, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
            _loggerDocuments = loggerDocuments;
        }

        public StyleSheetsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion

        /// <summary>
        /// Get XML Record
        /// </summary>
        /// <param name="storeProcedureName"></param>
        /// <param name="parameters"></param>
        /// <param name="returnStatus"></param>
        /// <returns>Return record in XML based on 'ReturnStatus' param</returns>
        public async Task<(HSPDbResult<HSPStatusRow>, string results)> GetXMLRecord(string storeProcedureName, object parameters, bool returnStatus)
        {
            if (returnStatus)
            {
                return await GetXmlAsync<HSPStatusRow>(storeProcedureName, parameters);
            }
            else
            {
                return await GetXmlAsync(storeProcedureName, parameters);
            }
        }
    }
}
