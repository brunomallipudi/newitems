﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class OfficesRepository : Repository, IOfficesRepository
    {
        public const string HSP_SP_GetOffices = "ee_GetOffices_V2";
        public const string HSP_SP_GetOfficeProfile_XML = "ee_GetOfficeProfile_XML";

        public OfficesRepository(IDbConnectionString connectionStrings, ILogger<OfficesRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Get a list of Offices.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Offices.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetOffices(object parameters)
        {
            return await GetAsync<dynamic>(HSP_SP_GetOffices, parameters);
        }

        /// <summary>
        /// Returns the Office profile xml.
        /// </summary>
        /// <param name="parameters">Request for Office profile xml.</param>
        /// <returns>Office profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetOfficeProfile_XML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetOfficeProfile_XML, parameters);
    }
}