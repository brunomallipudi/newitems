﻿using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// TableIds Repository - dbo.Ids
    ///
    /// Responsible for creating/updating new PrimaryKey values for the
    /// tables, identified by a unique key.
    /// </summary>
    public class TableIdsRepository : ITableIdsRepository
    {
        private readonly HSPDbContext context;

        /// <summary>
        /// We utilize this dictionary to ensure that
        /// only 1 thread will be running for a specific request
        /// </summary>
        private ConcurrentDictionary<object, SemaphoreSlim> _locks
            = new ConcurrentDictionary<object, SemaphoreSlim>();

        public TableIdsRepository(HSPDbContext ctx)
        {
            context = ctx;
        }

        /// <summary>
        /// Creates a new entry or updates an existing entry
        /// to get a new primary key.
        ///
        /// This exists because the tables have Primary Keys, but no identities.
        /// </summary>
        /// <remarks>
        /// Ensure that only 1 thread/request is attempting to generate a new 
        /// Primary Key for a specific IdType.
        /// 
        /// Example:
        /// Assume 3 threads attempt to generate Primary Keys for the exact
        /// same time, and for the same table dbo.Session
        /// 
        ///     1 - 3 => IdType: SESSION
        ///     
        /// All 3 must, at the same time
        /// 
        ///     A.  Select Entry
        ///     B.  If it doesn't exist 
        ///         CREATE, WRITE, RETURN 1
        ///     C.  If it exists 
        ///         SELECT, UPDATE, RETURN CURRVALUE
        ///     
        /// 
        /// This implementation ensures that only 1 thread will be executing
        /// this process at a time, ensuring that no two requests will generate
        /// the same Primary Key, even if they request it at the same millisecond.
        /// 
        /// </remarks>
        /// <param name="IdType"></param>
        /// <returns>Int32 - new PKey</returns>
        public async Task<int> GetNewIdAsync(string IdType)
        {
            var id = 0;

            // Lock threads
            var mylock = _locks.GetOrAdd(IdType, k => new SemaphoreSlim(1, 1));
            await mylock.WaitAsync();

            try
            {
                //  get current entry, if one exists
                var currIdEntry =
                    await context.Ids.Where(x => x.IdType == IdType)
                        .FirstOrDefaultAsync();

                if (currIdEntry == null)
                {
                    await context.Ids.AddAsync(
                         new DbTableId
                         {
                             IdType = IdType,
                             IdValueCurr = 1,
                             IdValueMax = int.MaxValue,
                             IdWrapAllowed = "N",
                             Filler = string.Empty
                         });
                    await context.SaveChangesAsync();
                    id = 1;
                }
                else
                {
                    currIdEntry.IdValueCurr += 1;
                    currIdEntry.LastUpdatedAt = DateTime.Now;
                    await context.SaveChangesAsync();
                    id = currIdEntry.IdValueCurr;
                }
                return id;
            }
            finally
            {
                mylock.Release();
            }
        }
    }
}