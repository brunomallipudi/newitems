﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Claims;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ClaimsRepository 
        : Repository, IClaimsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetClaimsForEntity_V2 = "EE_GetClaimsForEntity_V2";
        public const string HSP_SP_GetClaimsForEntity = "ee_GetClaimsForEntity";
        public const string HSP_SP_GetClaimActionCodeMap = "ee_GetClaimActionCodeMap";
        public const string HSP_SP_GetClaimExplanations = "ee_GetClaimExplanations";
        public const string HSP_SP_GetClaimIdForNumber = "ee_GetClaimIdForNumber";

        #endregion Procedure Names

        #region constructors

        public ClaimsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public ClaimsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion constructors

        /// <summary>
        /// Get list of Claims
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimForEntityV2Dto> results)> GetClaimsForEntityV2(object parameters)
            => await GetAsync<ClaimForEntityV2Dto>(HSP_SP_GetClaimsForEntity_V2, parameters);

        /// <summary>
        /// Get list of Claims for an entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimForEntityDto> results)> GetClaimsForEntity(object parameters)
            => await GetAsync<ClaimForEntityDto>(HSP_SP_GetClaimsForEntity, parameters);

        /// <summary>
        /// Get Claim Action Codes.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Claim Action Codes.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimActionCodeDto> results)> GetClaimActionCodes(object parameters)
            => await GetAsync<ClaimActionCodeDto>(HSP_SP_GetClaimActionCodeMap, parameters);

        /// <summary>
        /// Get Claim Explanations.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Claim Explanations.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimExplanationDto> results)> GetClaimExplanations(object parameters)
            => await GetAsync<ClaimExplanationDto>(HSP_SP_GetClaimExplanations, parameters);

        /// <summary>
        /// Get ClaimId For Number
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ClaimIdForNumberDto> results)> GetClaimIdForNumber(object parameters)
            => await GetAsync<ClaimIdForNumberDto>(HSP_SP_GetClaimIdForNumber, parameters);
    }
}