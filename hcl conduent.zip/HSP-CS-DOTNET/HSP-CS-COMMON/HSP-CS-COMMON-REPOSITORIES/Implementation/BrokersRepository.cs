﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class BrokersRepository : Repository, IBrokersRepository
    {
        public const string HSP_SP_GetBrokers = "ee_GetBrokers";
        public const string HSP_SP_GetBrokerProfile_XML = "ee_GetBrokerProfile_XML";

        public BrokersRepository(IDbConnectionString connectionStrings, ILogger<BrokersRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Get a list of Brokers.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Brokers.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BrokerDto> results)> GetBrokers(object parameters)
        {
            return await GetAsync<BrokerDto>(HSP_SP_GetBrokers, parameters);
        }

        /// <summary>
        /// Returns the Broker's profile xml.
        /// </summary>
        /// <param name="parameters">Request for Broker profile xml.</param>
        /// <returns>Broker's profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetBrokerProfile_XML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetBrokerProfile_XML, parameters);
    }
}