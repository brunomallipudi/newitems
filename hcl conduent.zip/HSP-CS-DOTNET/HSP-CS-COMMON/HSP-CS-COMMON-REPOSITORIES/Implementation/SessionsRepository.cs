﻿using Dapper;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.ErrorHandling;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Implementation;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Sessions;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// SessionsRepository
    /// </summary>
    public class SessionsRepository : Repository, ISessionsRepository
    {
        #region Procedure Names

        public const string HSP_SP_CONNECTUSER = "EE_CONNECTUSER_V3";
        public const string HSP_SP_DISCONNECTUSER = "EE_DISCONNECTUSER";

        #endregion Procedure Names

        #region Constructors

        public SessionsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public SessionsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Connects a logged on user to the database and provides a SessionId
        /// </summary>
        /// <remarks>
        /// We will not be implementing automatic user disconnect here.
        /// The Web UI is responsible for handling the flow.
        ///
        /// Attempting to force disconnection on a non existing or already disconnerted
        /// session will result in Success being false.
        /// </remarks>
        /// <param name="username">Logged on username</param>
        /// <param name="disconnectOldSession">Whether to disconnect an existing session.</param>
        /// <returns></returns>
        public async Task<(HSPDbResult<SessionStatusRow> StatusRow, IEnumerable<ExistingSessionDto> results)> ConnectUserAsync
            (string userName, bool disconnectOldSession, string webSessionId)
        {
            var parameters = new
            {
                userName,
                Password = string.Empty,
                Usage = disconnectOldSession ? "|USAGE3|" : "|USAGE1|",
                ComputerName = webSessionId,

                LicenseMode = Configuration["HSPSessionManagement:LicenceMode"],
                NumberOfLicensedSeats = Configuration["HSPSessionManagement:NumberOfLicensedSeats"],
                RoleName = Configuration["HSPSessionManagement:RoleName"],
                AppName = Configuration["HSPSessionManagement:AppName"],
                Version = Configuration["HSPSessionManagement:AppVersion"],
                DomainName = Configuration["HSPSessionManagement:DomainName"],
                IsSingleSignOn = Configuration["HSPSessionManagement:IsSingleSignOn"],
                Sid = Configuration["HSPSessionManagement:SID"]
            };

            using (SqlConnection connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
            {
                var dbResult = new HSPDbResult<SessionStatusRow>();
                using var dapperResult =
                    await connection.QueryMultipleAsync
                        (
                            HSP_SP_CONNECTUSER,
                            parameters,
                            commandType: CommandType.StoredProcedure
                        );

                // if the status row has been initialized, it means an exception was thrown
                if (dbResult.DbStatus != HSPDbStatus.Uninitialized)
                {
                    using (dapperResult)
                    {
                        throw new HSPRepositoryException(dbResult.DbStatus, dbResult.ErrorMessage);
                    }
                }

                var statusRow = await dapperResult.ReadFirstOrDefaultAsync<SessionStatusRow>();
                dbResult.StatusRow = statusRow ?? new SessionStatusRow() { Status = HSPDbStatus.ServerError };

                var rs = Enumerable.Empty<ExistingSessionDto>();
                Func<SqlMapper.GridReader, Task> readerProcessor = async reader
                    => rs = await reader.ReadAsync<ExistingSessionDto>();

                if (dbResult.DbStatus == HSPDbStatus.BusinessError && !dbResult.StatusRow.Success && readerProcessor != null)
                {
                    dbResult.StatusRow.ErrorMessage = dbResult.ErrorMessage;
                    await readerProcessor(dapperResult);
                }

                return (dbResult, rs);
            }
        }

        /// <summary>
        /// Disconnects/Invalidates an existing session
        /// </summary>
        /// <param name="sessionId">SessionId to disconnect</param>
        /// <returns>bool</returns>
        public async Task<bool> DisconnectUserAsync(int sessionId, string webSessionId, bool isForced = false)
        {
            var dbResult = await ExecuteAsync<SessionStatusRow>
                (HSP_SP_DISCONNECTUSER, new { sessionId });

            return dbResult.DbStatus == HSPDbStatus.Normal;
        }

        /// <summary>
        /// This is relevant to the processes not utilizing the
        /// EE_ConnectUser_V3 stored procedure, as the check is integrated in this procedure.
        /// </summary>
        /// <returns></returns>
        public Task<(string AppVersion, string DbAppVersion, bool IsCompatible)> GetAppVersionCompatibilityAsync() 
            => throw new NotImplementedException();

        /// <summary>
        /// Checks if the session is valid or not.
        /// </summary>
        /// <param name="sessionId">Id of the session</param>
        /// <returns>If session is still valid or not, UserId and ProductName.</returns>
        public Task<(HSPDbResult<HSPStatusRow> StatusRow, int UserId, string ProductName)> CheckSessionAsync(int sessionId)
            => throw new NotImplementedException();

        /// <summary>
        /// Checks if the session is valid or not.
        /// </summary>
        /// <param name="sessionId">Id of the session</param>
        /// <returns>If session is still valid or not, UserId and ProductName.</returns>
        public Task<(HSPDbResult<TStatusRow> StatusRow, int UserId, string ProductName)> CheckSessionAsync<TStatusRow>(int sessionId) where TStatusRow : HSPStatusRow, new()
            => throw new NotImplementedException();
    }
}