﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.BenefitStructures;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class BenefitStructuresRepository
     : Repository, IBenefitStructuresRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetBenefitStructures = "EE_GetBenefitStructures";

        #endregion Procedure Names

        #region Constructors

        public BenefitStructuresRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public BenefitStructuresRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of BenefitStructures
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BenefitStructureDto> results)> GetBenefitStructures(object parameters)
            => await GetAsync<BenefitStructureDto>(HSP_SP_GetBenefitStructures, parameters);
    }
}