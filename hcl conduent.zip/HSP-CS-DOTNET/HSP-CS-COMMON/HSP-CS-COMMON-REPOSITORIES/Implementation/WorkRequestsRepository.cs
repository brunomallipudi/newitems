﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.WorkRequests;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.ResultHandling;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class WorkRequestsRepository : Repository, IWorkRequestsRepository
    {
        private readonly HSPDbContext _dbContext;
        private ILogger<WorkRequestsRepository> _logger;

        #region Procedure Names

        public const string HSP_SP_GetWorkRequest = "ee_PollForWorkRequest";
        public const string HSP_SP_RouteWorkRequest = "ee_RouteWorkRequest";
        public const string HSP_SP_UpdateWorkRequest = "ee_UpdateWorkRequest";
        public const string HSP_SP_GetWorkRequestDetail = "ee_GetWorkRequestDetail";
        public const string HSP_SP_CancelWorkRequest = "ee_CancelWorkRequest";

        #endregion

        #region constructors

        public WorkRequestsRepository(IDbConnectionString connectionStrings, HSPDbContext dbContext, ILogger<WorkRequestsRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        #endregion

        /// <summary>
        /// Detail of Work Request
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return detail of work request</returns>
        public async Task<(HSPDbResult<HSPGetWorkRequestStatusRow> statusRow, WorkRequestDto result)> GetWorkRequest(object parameters)
            =>  await GetOneAsync<HSPGetWorkRequestStatusRow, WorkRequestDto>(HSP_SP_GetWorkRequest, parameters);

        /// <summary>
        /// Route Work Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> RouteWorkRequest(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_RouteWorkRequest,
                    parameters
                );
        }

        /// <summary>
        /// Update Work Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateWorkRequest(object parameters)
        {
            return await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_UpdateWorkRequest,
                    parameters
                );
        }
        
        /// <summary>
        /// Detail of Work Group Request
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return detail of work group request</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<WorkRequestDetailDto> results)> GetWorkRequestDetail(object parameters)
            => await GetAsync<WorkRequestDetailDto>(HSP_SP_GetWorkRequestDetail, parameters);

        /// <summary>
        /// cancel Work Request
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> CancelWorkRequest(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_CancelWorkRequest, parameters);

        /// <summary>
        /// Get the details about the workgroups.
        /// </summary>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CurrentWorkDto> results)> GetCurrentWork(int userId, int? assignedToId = null, DateTime? lastSyncDate = null)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            var now = DateTime.UtcNow;

            try
            {
                var query = from workgroups in _dbContext.WorkGroups
                            join userMap in _dbContext.WorkGroupUserMap
                                on new { workgroups.WorkGroupID, UserID = assignedToId ?? userId } equals new { userMap.WorkGroupID, userMap.UserID }
                            join workRequests in _dbContext.WorkRequests
                                on workgroups.WorkGroupID equals workRequests.WorkGroupID
                            join f in _dbContext.Files
                                on (workRequests.EntityType == "FIL" ? workRequests.EntityID : null) equals (int?)f.FileID
                                    into tempFiles
                            from files in tempFiles.DefaultIfEmpty()
                            join fem in _dbContext.FileEntityMap
                                on new { FileId = files.FileID, EntityType = "COB" } equals new { fem.FileId, fem.EntityType }
                                    into tempFEM
                            from fileEntityMap in tempFEM.DefaultIfEmpty()
                            where (!_dbContext.ReferenceCodes.Where(r => r.Type == "IndividualForEvent"
                                                                            && r.SubType == "MeditracSpecific")
                                                            .Select(r => r.Code)
                                                            .Contains(workRequests.EntityType)
                                   )
                                && (assignedToId == null || assignedToId.Value == workRequests.CheckOutUserId.Value)
                                && (workRequests.WorkDate == null || workRequests.WorkDate < now)
                                && (fileEntityMap.RowId == null 
                                    || fileEntityMap.RowId == _dbContext.FileEntityMap.Where(fem => fem.FileId == files.FileID).Max(fem => fem.RowId))
                                && workgroups.WorkgroupType == "EVT"
                                && workgroups.WorkgroupSubType == "CSR"
                            select new
                            {
                                WorkGroupId = workgroups.WorkGroupID,
                                WorkGroupName = workgroups.WorkGroupName,
                                RequestId = workRequests.RequestID,
                                IsNewRequest = lastSyncDate == null ? true : workRequests.DateRequested > lastSyncDate.Value
                            } into resultSet
                            group resultSet by new { resultSet.WorkGroupId, resultSet.WorkGroupName } into data
                            select new CurrentWorkDto
                            {
                                WorkGroupId = data.Key.WorkGroupId,
                                WorkGroupName = data.Key.WorkGroupName,
                                HasNewRequests = data.Count(d => d.IsNewRequest) > 0,
                                WorkRequestsCount = data.Count()
                            };

                var currentWork = await query.ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = currentWork.Count;
                statusRow.RowCount = currentWork.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, currentWork);
            }
            catch(Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetCurrentWork)}.");
                statusRow.Status = HSPDbStatus.ServerError;
                statusRow.ErrorMessage = "Unable to retrieve the current work data because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;

                return (dbResult, null);
            }
        }

        /// <summary>
        /// Get the current work stats information
        /// </summary>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<GetWorkStatsDto> results)> GetWorkStats(int userId)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            var now = DateTime.UtcNow;

            try
            {
                var query = from workgroups in _dbContext.WorkGroups
                            join userMap in _dbContext.WorkGroupUserMap
                                on new { workgroups.WorkGroupID, UserID = userId } equals new { userMap.WorkGroupID, userMap.UserID }
                            join workRequests in _dbContext.WorkRequests
                                on workgroups.WorkGroupID equals workRequests.WorkGroupID
                            join f in _dbContext.Files
                                on (workRequests.EntityType == "FIL" ? workRequests.EntityID : null) equals (int?)f.FileID
                                    into tempFiles
                            from files in tempFiles.DefaultIfEmpty()
                            join fem in _dbContext.FileEntityMap
                                on new { FileId = files.FileID, EntityType = "COB" } equals new { fem.FileId, fem.EntityType }
                                    into tempFEM
                            from fileEntityMap in tempFEM.DefaultIfEmpty()
                            where (!_dbContext.ReferenceCodes.Where(r => r.Type == "IndividualForEvent"
                                                                            && r.SubType == "MeditracSpecific")
                                                            .Select(r => r.Code)
                                                            .Contains(workRequests.EntityType))
                                && (workRequests.CheckOutUserId == userId) 
                                && (workRequests.WorkDate == null || workRequests.WorkDate < now)
                                && (fileEntityMap.RowId == null
                                    || fileEntityMap.RowId == _dbContext.FileEntityMap.Where(fem => fem.FileId == files.FileID).Max(fem => fem.RowId))
                                && workgroups.WorkgroupType == "EVT" 
                                && workgroups.WorkgroupSubType == "CSR"
                            select new
                            {
                                WorkGroupId = workgroups.WorkGroupID,
                                WorkGroupName = workgroups.WorkGroupName,
                                RequestId = workRequests.RequestID,
                                IsDue = workRequests.DateDue < now
                            } into resultSet
                            group resultSet by new { resultSet.WorkGroupId, resultSet.WorkGroupName } into data
                            select new GetWorkStatsDto
                            {
                                WorkGroupId = data.Key.WorkGroupId,
                                WorkGroupName = data.Key.WorkGroupName,
                                DueWorkRequestCount = data.Count(d => d.IsDue),
                                WorkRequestsCount = data.Count()
                            };

                var currentWork = await query.ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = currentWork.Count;
                statusRow.RowCount = currentWork.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, currentWork);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetWorkStats)}.");
                statusRow.Status = HSPDbStatus.ServerError;
                statusRow.ErrorMessage = "Unable to retrieve the current work stats because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;

                return (dbResult, null);
            }
        }

    }
}
