﻿using Dapper;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Members;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Request.Members;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class MembersRepository : Repository, IMembersRepository
    {
        private ILogger<MembersRepository> _loggerMembers;
        private readonly HSPDbContext _dbContext;
        private readonly ICustomAttributesRepository _customAttributesRepository;

        #region Procedures

        public const string HSP_SP_FindMemberCoverages = "EE_FindMemberCoverages";
        public const string HSP_SP_GetFamily = "ee_GetFamily";
        public const string HSP_SP_GetMemberPCPInfo = "ee_GetMemberPCPInfo";
        public const string HSP_SP_GetMemberProfile_XML = "ee_GetMemberProfile_XML";
        public const string HSP_SP_ChangeMemberProviderMap_Manual = "ee_ChangeMemberProviderMap_Manual";
        public const string HSP_SP_GetResponsiblePartyCoverageMap = "ee_GetResponsiblePartyCoverageMap";
        public const string HSP_SP_GetMemberCarrierMap = "ee_GetMemberCarrierMap";
        public const string HSP_SP_AddMemberCarrierMap = "ee_AddMemberCarrierMap";
        public const string HSP_SP_UpdateMemberCarrierMap = "ee_UpdateMemberCarrierMap";
        public const string HSP_SP_DeleteMemberCarrierMap = "ee_DeleteMemberCarrierMap";
        public const string HSP_SP_GetCOBsHistory = "ee_GetCOBsHistory";

        #endregion

        #region Constructors

        public MembersRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, ILogger<MembersRepository> loggerMembers, IConfiguration config, HSPDbContext dbContext, ICustomAttributesRepository customAttributesRepository)
            : base(connectionStrings, logger, config)
        {
            _loggerMembers = loggerMembers;
            _dbContext = dbContext;
            _customAttributesRepository = customAttributesRepository;
        }

        public MembersRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, ILogger<MembersRepository> loggerMembers, IConfiguration config, HSPDbContext dbContext, ICustomAttributesRepository customAttributesRepository)
            : base(connectionStrings, session, logger, config)
        {
            _loggerMembers = loggerMembers;
            _dbContext = dbContext;
            _customAttributesRepository = customAttributesRepository;
        }

        #endregion Constructors

        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> FindMemberCoverages(object parameters)
            => await GetAsync<dynamic>(HSP_SP_FindMemberCoverages, parameters);

        /// <summary>
        /// Find Members for COB
        /// </summary>
        /// <param name="parameters">Find Members for COB</param>
        /// <returns>Find Members for COB</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindMembersCoveragesV2Dto> results)> FindMemberCoveragesV2(object parameters)
            => await GetAsync<FindMembersCoveragesV2Dto>(HSP_SP_FindMemberCoverages, parameters);

        /// <summary>
        /// Gets the family for a member.
        /// </summary>
        /// <param name="parameters">Get Family request.</param>
        /// <returns>List of family members.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FamilyMemberDto> results)> GetFamily(object parameters)
            => await GetAsync<FamilyMemberDto>(HSP_SP_GetFamily, parameters);

        /// <summary>
        /// Returns the member's profile xml.
        /// </summary>
        /// <param name="parameters">Request for member profile xml.</param>
        /// <returns>Member's profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetMemberProfile_XML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetMemberProfile_XML, parameters);

        /// <summary>
        /// Changes Member Provider Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> ChangeMemberProviderMapManual(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_ChangeMemberProviderMap_Manual, parameters);

        /// <summary>
        /// Gets the member's PCP.
        /// </summary>
        /// <param name="parameters">Get member pcp request.</param>
        /// <returns>List of pcp for the member.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<MemberPCPDto> results)> GetMemberPCPInfo(object parameters)
            => await GetAsync<MemberPCPDto>(HSP_SP_GetMemberPCPInfo, parameters);

        /// <summary>
        /// Gets the member's responsible parties.
        /// </summary>
        /// <param name="parameters">Get member's responsible parties request.</param>
        /// <returns>List of responsible parties for the member.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ResponsiblePartyDto> results)> GetResponsiblePartyCoverageMap(object parameters)
            => await GetAsync<ResponsiblePartyDto>(HSP_SP_GetResponsiblePartyCoverageMap, parameters);

        /// <summary>
        /// Gets the member's carrier map.
        /// </summary>
        /// <param name="parameters">Get member's carrier map request.</param>
        /// <returns>List of carrier map for the member.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<MemberCarrierMapDto> results)> GetMemberCarrierMap(object parameters)
            => await GetAsync<MemberCarrierMapDto>(HSP_SP_GetMemberCarrierMap, parameters);

        /// <summary>
        /// Add Member carrier Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, IEnumerable<AddMemberCarrierMapDto> results)> AddMemberCarrierMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow, AddMemberCarrierMapDto>
                (
                    HSP_SP_AddMemberCarrierMap,
                    parameters
                );
        }

        /// <summary>
        /// Update Member carrier Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateMemberCarrierMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_UpdateMemberCarrierMap,
                    parameters
                );
        }

        /// <summary>
        /// Delete Member carrier Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteMemberCarrierMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_DeleteMemberCarrierMap,
                    parameters
                );
        }

        /// <summary>
        /// Gets COB's History.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<COBsHistoryDto> results)> GetCOBHistory(object parameters)
            => await GetAsync<COBsHistoryDto>(HSP_SP_GetCOBsHistory, parameters);

        /// <summary>
        /// Process COB Changes
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> ProcessCOBChanges(ProcessCOBChangesRequestDto parameters)
        {
            try
            {
                using (var connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
                {
                    var dbResult = new HSPDbResult<HSPStatusRow>();
                    var statusRow = new HSPStatusRow();
                    SetupInfoMessageHandling(connection, dbResult);
                    await connection.OpenAsync();
                    using (var transaction = await connection.BeginTransactionAsync())
                    {
                        try
                        {
                            string AttributeName = "Member Portal Response";
                            var attributeID = (from CA in _dbContext.CustomAttributes
                                               where CA.AttributeName == AttributeName
                                               select CA.AttributeID).Single();

                            string COBAttributeName = "COB on App Portal Response";
                            var COBAttributeID = (from CA in _dbContext.CustomAttributes
                                                  where CA.AttributeName == COBAttributeName
                                                  select CA.AttributeID).Single();

                            string RDAttributeName = "Subscriber Retirement Date";
                            var RDattributeID = (from CA in _dbContext.CustomAttributes
                                                 where CA.AttributeName == RDAttributeName
                                                 select CA.AttributeID).Single();

                            string EStatusAttributeName = "Subscriber Employment Status";
                            var EStatusAttributeID = (from CA in _dbContext.CustomAttributes
                                                      where CA.AttributeName == EStatusAttributeName
                                                      select CA.AttributeID).Single();

                            string ESizeAttributeName = "Subscriber Employer Size";
                            var ESizeAttributeID = (from CA in _dbContext.CustomAttributes
                                                    where CA.AttributeName == ESizeAttributeName
                                                    select CA.AttributeID).Single();

                            if (!parameters.AddMemberCarrierMapRequests.Any()
                                && !parameters.UpdateMemberCarrierMapRequest.Any()
                                    && !parameters.DeleteMemberCarrierMapRequest.Any())
                            {
                                var MCMParam = new { SessionId = parameters.SessionId, MemberID = parameters.MemberId, Usage = "|USAGE1|", COBType = "EXT" };
                                var resultDto = await GetMemberCarrierMap(MCMParam);
                                foreach (var item in resultDto.results)
                                {
                                    var parameters_AddEntityAttributes_Verified = new
                                    {
                                        SessionId = parameters.SessionId,
                                        AttributeID = attributeID,
                                        AttributeValue = "Coverage Verified",
                                        EntityType = "MCM",
                                        EntityID = item.RowId
                                    };
                                    var status_verified = await _customAttributesRepository.AddEntityAttributes(parameters_AddEntityAttributes_Verified);
                                    if (status_verified.DbStatus == HSPDbStatus.BusinessError || status_verified.DbStatus == HSPDbStatus.ServerError)
                                    {
                                        dbResult.ErrorMessage = $"Unexpected error occurred while verifying the Member's COB info" + dbResult.ErrorMessage;
                                        statusRow.ErrorMessage = dbResult.ErrorMessage;
                                        statusRow.IsCached = false;
                                        statusRow.Status = HSPDbStatus.ServerError;
                                        statusRow.Success = false;
                                        dbResult.StatusRow = statusRow;
                                        return (dbResult);
                                    }
                                }
                                var parameters_AddEntityAttributes_Verified2 = new
                                {
                                    SessionId = parameters.SessionId,
                                    AttributeID = COBAttributeID,
                                    AttributeValue = "Verified no OHI",
                                    EntityType = "Members",
                                    EntityID = parameters.MemberId
                                };
                                var status = await _customAttributesRepository.AddEntityAttributes(parameters_AddEntityAttributes_Verified2);
                                if (status.DbStatus == HSPDbStatus.BusinessError || status.DbStatus == HSPDbStatus.ServerError)
                                {
                                    dbResult.ErrorMessage = $"Unexpected error occurred while verifying the Member's COB info" + dbResult.ErrorMessage;
                                    statusRow.ErrorMessage = dbResult.ErrorMessage;
                                    statusRow.IsCached = false;
                                    statusRow.Status = HSPDbStatus.ServerError;
                                    statusRow.Success = false;
                                    dbResult.StatusRow = statusRow;
                                    return (dbResult);
                                }
                                statusRow.ErrorMessage = "";
                                statusRow.IsCached = true;
                                statusRow.Status = HSPDbStatus.Normal;
                                statusRow.Success = true;
                            }

                            foreach (DeleteMemberCarrierMapRequestDto deleteparameters in parameters.DeleteMemberCarrierMapRequest)
                            {
                                deleteparameters.SessionId = parameters.SessionId;
                                using var dapperResult1 =
                                    await connection.QueryMultipleAsync(HSP_SP_DeleteMemberCarrierMap, deleteparameters, transaction, commandType: CommandType.StoredProcedure);

                                var statusRow1 = await dapperResult1.ReadFirstOrDefaultAsync<HSPStatusRow>();
                                if (statusRow1 != null)
                                {
                                    if (statusRow1.Status != HSPDbStatus.Normal)
                                    {
                                        transaction.Rollback();
                                        dbResult.StatusRow = statusRow1;
                                        dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                                        if (statusRow1.Status == HSPDbStatus.BusinessError)
                                        {
                                            dbResult.ErrorMessage = $"In Delete Operation of RowID '{deleteparameters.RowId}': " + dbResult.ErrorMessage;
                                        }
                                        return (dbResult);
                                    }
                                    else
                                    {
                                        var parameters_AddEntityAttributesForDelete = new
                                        {
                                            SessionId = parameters.SessionId,
                                            AttributeID = attributeID,
                                            AttributeValue = "Coverage Deleted",
                                            EntityType = "MCM",
                                            EntityID = deleteparameters.RowId
                                        };

                                        var status = await _customAttributesRepository.AddEntityAttributes(parameters_AddEntityAttributesForDelete);
                                    }
                                    statusRow = statusRow1;
                                }
                                else
                                {
                                    transaction.Rollback();
                                    statusRow.Status = HSPDbStatus.ApiError;
                                    statusRow.Success = false;
                                    dbResult.StatusRow = statusRow;
                                    dbResult.ErrorMessage = "Some error has occured...";
                                    return (dbResult);
                                }

                            }

                            foreach (UpdateMemberCarrierMapRequestDto updateParameters in parameters.UpdateMemberCarrierMapRequest)
                            {
                                updateParameters.SessionId = parameters.SessionId;
                                var updateParameters_dynamic = new
                                {
                                    SessionId = updateParameters.SessionId,
                                    RowID = updateParameters.RowID,
                                    MemberId = updateParameters.MemberId,
                                    SubscriberContractId = updateParameters.SubscriberContractId,
                                    COBType = updateParameters.COBType,
                                    COBPrecedence = updateParameters.COBPrecedence,
                                    COBClass = updateParameters.COBClass,
                                    COBSubClass = updateParameters.COBSubClass,
                                    PayerId = updateParameters.PayerId,
                                    InternalPayerType = updateParameters.InternalPayerType,
                                    PayerEmpName = updateParameters.PayerEmpName,
                                    PayerGroupNumber = updateParameters.PayerGroupNumber,
                                    PayerMemberNumber = updateParameters.PayerMemberNumber,
                                    RelationshipToSubscriber = updateParameters.RelationshipToSubscriber,
                                    Coverage = updateParameters.Coverage,
                                    EffectiveDate = updateParameters.EffectiveDate,
                                    ExpirationDate = updateParameters.ExpirationDate,
                                    PolicyHolderLastName = updateParameters.PolicyHolderLastName,
                                    PolicyHolderFirstName = updateParameters.PolicyHolderFirstName,
                                    PolicyHolderMiddleName = updateParameters.PolicyHolderMiddleName,
                                    PolicyHolderNameSuffix = updateParameters.PolicyHolderNameSuffix,
                                    PolicyHolderSSN = updateParameters.PolicyHolderSSN,
                                    PolicyHolderDOB = updateParameters.PolicyHolderDOB,
                                    PolicyHolderPhone = updateParameters.PolicyHolderPhone,
                                    Address1 = updateParameters.Address1,
                                    Address2 = updateParameters.Address2,
                                    City = updateParameters.City,
                                    State = updateParameters.State,
                                    County = updateParameters.County,
                                    Zip = updateParameters.Zip,
                                    ZipCodeId = updateParameters.ZipCodeId,
                                    CountryCode = updateParameters.CountryCode,
                                    UpdateUsage = updateParameters.UpdateUsage,
                                    InboundJobDetailId = updateParameters.InboundJobDetailId,
                                    Import = updateParameters.Import,
                                    MultiCoverages = updateParameters.MultiCoverages,
                                    MultipleMemberIDs = updateParameters.MultipleMemberIDs,
                                    RowIds = updateParameters.RowIds,
                                    RxBinNumber = updateParameters.RxBinNumber,
                                    RxPcnNumber = updateParameters.RxPcnNumber,
                                    SupplementalType = updateParameters.SupplementalType,
                                    MSPType = updateParameters.MSPType,
                                    PayerOrder = updateParameters.PayerOrder,
                                    PolicyHolderGender = updateParameters.PolicyHolderGender,
                                    SequenceNumber = updateParameters.SequenceNumber,
                                    MACOBEffectiveDate = updateParameters.MACOBEffectiveDate,
                                    RxIDNumber = updateParameters.RxIDNumber,
                                    RxGroupNumber = updateParameters.RxGroupNumber,
                                    RxPhoneNumber = updateParameters.RxPhoneNumber,
                                    PAPNationalDrugCode1 = updateParameters.PAPNationalDrugCode1,
                                    PAPNationalDrugCode2 = updateParameters.PAPNationalDrugCode2,
                                    PAPNationalDrugCode3 = updateParameters.PAPNationalDrugCode3,
                                    PAPNationalDrugCode4 = updateParameters.PAPNationalDrugCode4,
                                    PAPNationalDrugCode5 = updateParameters.PAPNationalDrugCode5,
                                    ExternalIdNumber = updateParameters.ExternalIdNumber
                                };

                                using var dapperResult2 =
                                    await connection.QueryMultipleAsync(HSP_SP_UpdateMemberCarrierMap, updateParameters_dynamic, transaction, commandType: CommandType.StoredProcedure);

                                var statusRow2 = await dapperResult2.ReadFirstOrDefaultAsync<HSPStatusRow>();
                                if (statusRow2 != null)
                                {
                                    if (statusRow2.Status != HSPDbStatus.Normal)
                                    {
                                        transaction.Rollback();
                                        dbResult.StatusRow = statusRow2;
                                        dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                                        if (statusRow2.Status == HSPDbStatus.BusinessError)
                                        {
                                            dbResult.ErrorMessage = $"In Update Operation of RowID '{updateParameters.RowID}': " + dbResult.ErrorMessage;
                                        }
                                        return (dbResult);
                                    }
                                    else
                                    {
                                        var parameters_AddEntityAttributesForUpdate = new
                                        {
                                            SessionId = parameters.SessionId,
                                            AttributeID = attributeID,
                                            AttributeValue = "Coverage Edited",
                                            EntityType = "MCM",
                                            EntityID = updateParameters.RowID
                                        };

                                        var status = await _customAttributesRepository.AddEntityAttributes(parameters_AddEntityAttributesForUpdate);

                                        if (updateParameters.RetirementDate != null)
                                        {
                                            var RDStatus = await AddEntityAttributes(updateParameters.SessionId.ToString(), RDattributeID, updateParameters.RetirementDate, "MCM", updateParameters.RowID);
                                        }
                                        if (!string.IsNullOrEmpty(updateParameters.EmployementStatus))
                                        {
                                            var EStatusStatus = await AddEntityAttributes(updateParameters.SessionId.ToString(), EStatusAttributeID, updateParameters.EmployementStatus, "MCM", updateParameters.RowID);
                                        }
                                        if (!string.IsNullOrEmpty(updateParameters.NoOfEmployees))
                                        {
                                            var ESizeStatus = await AddEntityAttributes(updateParameters.SessionId.ToString(), ESizeAttributeID, updateParameters.NoOfEmployees, "MCM", updateParameters.RowID);
                                        }
                                    }
                                    statusRow = statusRow2;
                                }
                                else
                                {
                                    transaction.Rollback();
                                    statusRow.Status = HSPDbStatus.ApiError;
                                    statusRow.Success = false;
                                    dbResult.StatusRow = statusRow;
                                    dbResult.ErrorMessage = "Some error has occured...";
                                    return (dbResult);
                                }
                            }

                            foreach (AddMemberCarrierMapRequestDto addParameters in parameters.AddMemberCarrierMapRequests)
                            {
                                addParameters.SessionId = parameters.SessionId;

                                var addParameters_dynamic = new
                                {
                                    SessionId = addParameters.SessionId,
                                    MemberId = addParameters.MemberId,
                                    SubscriberContractId = addParameters.SubscriberContractId,
                                    COBType = addParameters.COBType,
                                    COBPrecedence = addParameters.COBPrecedence,
                                    COBClass = addParameters.COBClass,
                                    COBSubClass = addParameters.COBSubClass,
                                    PayerId = addParameters.PayerId,
                                    InternalPayerType = addParameters.InternalPayerType,
                                    PayerEmpName = addParameters.PayerEmpName,
                                    PayerGroupNumber = addParameters.PayerGroupNumber,
                                    PayerMemberNumber = addParameters.PayerMemberNumber,
                                    RelationshipToSubscriber = addParameters.RelationshipToSubscriber,
                                    Coverage = addParameters.Coverage,
                                    EffectiveDate = addParameters.EffectiveDate,
                                    ExpirationDate = addParameters.ExpirationDate,
                                    Address1 = addParameters.Address1,
                                    Address2 = addParameters.Address2,
                                    City = addParameters.City,
                                    State = addParameters.State,
                                    County = addParameters.County,
                                    Zip = addParameters.Zip,
                                    ZipCodeId = addParameters.ZipCodeId,
                                    CountryCode = addParameters.CountryCode,
                                    CountryISOCode2 = addParameters.CountryISOCode2,
                                    CountryISOCode3 = addParameters.CountryISOCode3,
                                    Latitude = addParameters.Latitude,
                                    Longitude = addParameters.Longitude,
                                    InboundJobDetailId = addParameters.InboundJobDetailId,
                                    Import = addParameters.Import,
                                    PolicyHolderLastName = addParameters.PolicyHolderLastName,
                                    PolicyHolderFirstName = addParameters.PolicyHolderFirstName,
                                    PolicyHolderMiddleName = addParameters.PolicyHolderMiddleName,
                                    PolicyHolderNameSuffix = addParameters.PolicyHolderNameSuffix,
                                    PolicyHolderSSN = addParameters.PolicyHolderSSN,
                                    PolicyHolderDOB = addParameters.PolicyHolderDOB,
                                    PolicyHolderPhone = addParameters.PolicyHolderPhone,
                                    MultiCoverages = addParameters.MultiCoverages,
                                    MultipleMemberIDs = addParameters.MultipleMemberIDs,
                                    Usage = addParameters.Usage,
                                    RxBinNumber = addParameters.RxBinNumber,
                                    RxPcnNumber = addParameters.RxPcnNumber,
                                    SupplementalType = addParameters.SupplementalType,
                                    MSPType = addParameters.MSPType,
                                    PayerOrder = addParameters.PayerOrder,
                                    PolicyHolderGender = addParameters.PolicyHolderGender,
                                    SequenceNumber = addParameters.SequenceNumber,
                                    MACOBEffectiveDate = addParameters.MACOBEffectiveDate,
                                    RxIDNumber = addParameters.RxIDNumber,
                                    RxGroupNumber = addParameters.RxGroupNumber,
                                    RxPhoneNumber = addParameters.RxPhoneNumber,
                                    PAPNationalDrugCode1 = addParameters.PAPNationalDrugCode1,
                                    PAPNationalDrugCode2 = addParameters.PAPNationalDrugCode2,
                                    PAPNationalDrugCode3 = addParameters.PAPNationalDrugCode3,
                                    PAPNationalDrugCode4 = addParameters.PAPNationalDrugCode4,
                                    PAPNationalDrugCode5 = addParameters.PAPNationalDrugCode5,
                                    ExternalIdNumber = addParameters.ExternalIdNumber
                                };

                                (var statusRow3, var MCMResult) = await AddMemberCarrierMap(addParameters_dynamic);

                                if (statusRow3 != null)
                                {
                                    if (statusRow3.StatusRow.Status != HSPDbStatus.Normal)
                                    {
                                        transaction.Rollback();
                                        dbResult.StatusRow = statusRow3.StatusRow;
                                        dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                                        if (statusRow3.StatusRow.Status == HSPDbStatus.BusinessError)
                                        {
                                            dbResult.ErrorMessage = $"In Insert Operation of COBType '{addParameters.COBType}', CobPrecedence '{addParameters.COBPrecedence}': " + dbResult.ErrorMessage;
                                        }
                                        return (dbResult);
                                    }
                                    else
                                    {
                                        foreach (var item in MCMResult)
                                        {
                                            var parameters_AddEntityAttributes = new
                                            {
                                                SessionId = parameters.SessionId,
                                                AttributeID = attributeID,
                                                AttributeValue = "Coverage Added",
                                                EntityType = "MCM",
                                                EntityID = item.RowID
                                            };

                                            var status = await _customAttributesRepository.AddEntityAttributes(parameters_AddEntityAttributes);

                                            if (addParameters.RetirementDate != null)
                                            {
                                                var RDStatus = await AddEntityAttributes(addParameters.SessionId.ToString(), RDattributeID, addParameters.RetirementDate, "MCM", item.RowID);
                                            }
                                            if (!string.IsNullOrEmpty(addParameters.EmployementStatus))
                                            {
                                                var EStatusStatus = await AddEntityAttributes(addParameters.SessionId.ToString(), EStatusAttributeID, addParameters.EmployementStatus, "MCM", item.RowID);
                                            }
                                            if (!string.IsNullOrEmpty(addParameters.NoOfEmployees))
                                            {
                                                var ESizeStatus = await AddEntityAttributes(addParameters.SessionId.ToString(), ESizeAttributeID, addParameters.NoOfEmployees, "MCM", item.RowID);
                                            }
                                        }

                                    }
                                    statusRow = statusRow3.StatusRow;
                                }
                                else
                                {
                                    transaction.Rollback();
                                    statusRow.Status = HSPDbStatus.ApiError;
                                    statusRow.Success = false;
                                    dbResult.StatusRow = statusRow;
                                    dbResult.ErrorMessage = "Some error has occured...";
                                    return (dbResult);
                                }
                            }

                            dbResult.StatusRow = statusRow;
                            dbResult.StatusRow.Success = true;
                            transaction.Commit();
                            return dbResult;
                        }
                        catch (Exception exception)
                        {
                            _loggerMembers.LogError(exception, $"Exception in {nameof(ProcessCOBChanges)}.");
                            transaction.Rollback();
                            statusRow.Status = HSPDbStatus.ServerError;
                            statusRow.ErrorMessage = $"Unable to retrieve the process the COB changes because an unexpected error occurred.";
                            dbResult.StatusRow = statusRow;
                            dbResult.StatusRow.Success = false;
                            dbResult.StatusRow.ErrorMessage = dbResult.ErrorMessage;
                            return dbResult;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                _loggerMembers.LogError(exception, $"Exception in {nameof(ProcessCOBChanges)}.");
                throw;
            }
        }

        public async Task<HSPDbResult<HSPAddEntryStatusRow>> AddEntityAttributes(string SessionId, int AttributeID, string AttributeValue, string EntityType, int? EntityID)
        {
            var parameters_AddEntityAttributes = new
            {
                SessionId = SessionId,
                AttributeID = AttributeID,
                AttributeValue = AttributeValue,
                EntityType = EntityType,
                EntityID = EntityID
            };
            var status = await _customAttributesRepository.AddEntityAttributes(parameters_AddEntityAttributes);
            return status;
        }


        /// <summary>
        /// Get Member Search Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<MemberSearchFileDBResult> results)> GetMemberSearchResult(MemberSearchRequest memberSearchRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            try
            {
                var ESResult = from dbGroupResult in (from CSI in _dbContext.ContactSteps
                                                      join CRI in _dbContext.ContactReasons on CSI.ReasonID equals CRI.ReasonID
                                                      join CRCI in _dbContext.ContactReasonCategories on CRI.CategoryID equals CRCI.CategoryID
                                                      join WGI in _dbContext.WorkGroups on CSI.WorkGroupID equals WGI.WorkGroupID
                                                      join FI in _dbContext.Files on CSI.ReasonID equals FI.ReasonID
                                                      where CRCI.CategoryName == "RX OHI Verification"
                                                      group new { FI.TrackingNumber, CSI.StepID } by new { FI.TrackingNumber } into grpResult
                                                      select new
                                                      {
                                                          TrackingNumber = grpResult.Key.TrackingNumber,
                                                          MaxStepID = grpResult.Max(x => x.StepID)
                                                      })
                               join CS in _dbContext.ContactSteps on dbGroupResult.MaxStepID equals CS.StepID
                               join CR in _dbContext.ContactReasons on CS.ReasonID equals CR.ReasonID
                               join CRC in _dbContext.ContactReasonCategories on CR.CategoryID equals CRC.CategoryID
                               join WG in _dbContext.WorkGroups on CS.WorkGroupID equals WG.WorkGroupID
                               join F in _dbContext.Files on new { CS.ReasonID, dbGroupResult.TrackingNumber } equals new { F.ReasonID, F.TrackingNumber }
                               //join MC in _dbContext.MemberCoverages on F.IndividualNumber equals MC.MemberNumber
                               join MC in _dbContext.MemberCoverages on F.IndividualID equals MC.MemberId
                               join M in _dbContext.Members on MC.MemberId equals M.MemberId
                               join MCM in _dbContext.MemberCarrierMap on new { MemberId = M.MemberId }
                                                                   equals new
                                                                   {
                                                                       MemberId = MCM.MemberId,
                                                                   } into tmpMCM
                               from tmpMCMFinal in tmpMCM.DefaultIfEmpty()
                               join P in _dbContext.Payers on tmpMCMFinal.PayerId equals P.PayerId into tmpPayers
                               from tmpPayersFinal in tmpPayers.DefaultIfEmpty()
                               join SC in _dbContext.SubscriberContracts on MC.SubscriberContractId equals SC.SubscriberContractID
                               join G in _dbContext.Groups on SC.GroupId equals G.GroupId
                               join GP in _dbContext.Groups on G.ParentId equals GP.GroupId
                               join GPNew in _dbContext.Groups on GP.ParentId equals GPNew.GroupId
                               //join BC in _dbContext.BenefitCoverages on M.MemberId equals BC.EntityId
                               join BC in _dbContext.BenefitCoverages on MC.MemberCoverageID equals BC.EntityId
                               join RC in _dbContext.ReferenceCodes on new { Code = G.LOB, Type = "LineofBusiness", SubType = "LineofBusiness" }
                                                                                 equals new { RC.Code, RC.Type, RC.SubType } into tmpRC
                               from tmpRCFinal in tmpRC.DefaultIfEmpty()
                               join RCS in _dbContext.ReferenceCodes on new { Code = tmpMCMFinal.RelationshipToSubscriber, Type = "RELATIONSHIPCODE", SubType = "MEMBER" }
                                                                                 equals new { RCS.Code, RCS.Type, RCS.SubType } into tmpRCS
                               from tmpRCSFinal in tmpRCS.DefaultIfEmpty()
                               join Ge in _dbContext.ReferenceCodes on new { Code = M.Gender, Type = "Gender" }
                                                                    equals new { Ge.Code, Ge.Type } into tmpGe
                               from tmpGeFinal in tmpGe.DefaultIfEmpty()
                               join MCMGe in _dbContext.ReferenceCodes on new { Code = tmpMCMFinal.PolicyHolderGender, Type = "Gender" }
                                                                    equals new { MCMGe.Code, MCMGe.Type } into tmpMCMGe
                               from tmpMCMGeFinal in tmpMCMGe.DefaultIfEmpty()
                               join DEM in _dbContext.DocumentEntityMap on M.MemberId equals DEM.EntityId into tmpDEM
                               from tmpDEMFinal in tmpDEM.DefaultIfEmpty()
                               join D in _dbContext.Documents on tmpDEMFinal.DocumentId equals D.DocumentId into tmpD
                               from tmpDFinal in tmpD.DefaultIfEmpty()
                               join LEM in _dbContext.LanguageEntityMap on M.MemberId equals LEM.EntityID
                               where F.IndividualCode == "MEM"
                                   && GP.GroupLevel == 2
                                   && GPNew.GroupLevel == 1
                                   && BC.CoverageEntityType == "BAS"
                                   && BC.EntityTypeId == 3
                                   && LEM.EntityType == "MEM"
                                   && LEM.LanguageUse == "Primary"
                                   && CRC.CategoryName == "RX OHI Verification"
                                   //&& M.MemberId == memberSearchRequest.MemberId
                                   && MC.MemberNumber == memberSearchRequest.MemberNumber
                                   && GPNew.GroupName == memberSearchRequest.GroupName
                                   && tmpRCFinal.Name == memberSearchRequest.LOB
                                   && (new[] { "COBAL", "OHIVL" }.Contains(CR.ReasonShortcut)
                                        || CR.ReasonShortcut == (tmpMCMFinal.SupplementalType == "P" ? "MPSPV"
                                        : tmpMCMFinal.SupplementalType == "1" ? "MSP1V"
                                        : tmpMCMFinal.SupplementalType == "2" ? "MSP2V"
                                        : tmpMCMFinal.SupplementalType == "L" || tmpMCMFinal.SupplementalType == "M" || tmpMCMFinal.SupplementalType == "N" || tmpMCMFinal.SupplementalType == "O" || tmpMCMFinal.SupplementalType == "R" || tmpMCMFinal.SupplementalType == "T" || tmpMCMFinal.SupplementalType == "3" ? "MSPSV"
                                        : tmpMCMFinal.MSPType == "A" ? "MPSAV"
                                        : tmpMCMFinal.MSPType == "B" ? "MSPBV"
                                        : tmpMCMFinal.MSPType == "G" ? "MSPGV"
                                        : tmpMCMFinal.MSPType == "C" || tmpMCMFinal.MSPType == "F" || tmpMCMFinal.MSPType == "H" ? "MSPPV"
                                        : "CNCL")
                                      )

                               select new MemberSearchFileDBResult
                               {
                                   MemberID = M.MemberId,
                                   FirstName = M.FirstName,
                                   LastName = M.LastName,
                                   Gender = tmpGeFinal.Name,
                                   MiddleName = M.MiddleName,
                                   Address1 = M.Address1,
                                   Address2 = M.Address2,
                                   City = M.City,
                                   State = M.State,
                                   Zip = M.Zip,
                                   DateOfBirth = M.DateOfBirth,
                                   MaritalStatus = M.MaritalStatus,
                                   SocialSecurityNumber = M.SocialSecurityNumber,
                                   MBI = M.MBI,
                                   HomePhone = M.HomePhone,
                                   WorkPhone = M.WorkPhone,
                                   CellPhone = M.CellPhone,
                                   PayerName = tmpPayersFinal.PayerName,
                                   PayerAddress1 = tmpPayersFinal.Address1,
                                   PayerAddress2 = tmpPayersFinal.Address2,
                                   PayerCity = tmpPayersFinal.City,
                                   PayerState = tmpPayersFinal.State,
                                   PayerZip = tmpPayersFinal.Zip,
                                   PayerCellPhone = tmpPayersFinal.CellPhone,
                                   PayerFaxPhone = tmpPayersFinal.FaxPhone,
                                   PayerHomePhone = tmpPayersFinal.HomePhone,
                                   PayerWorkPhone = tmpPayersFinal.WorkPhone,
                                   PayerWorkPhoneExt = tmpPayersFinal.WorkPhoneExt,
                                   OHIEffectiveDate = tmpMCMFinal.EffectiveDate,
                                   OHIExpirationDate = tmpMCMFinal.ExpirationDate,
                                   OHICoverageCode = tmpMCMFinal.Coverage,
                                   RowId = tmpMCMFinal.RowId,
                                   RelationshipToSubscriber = tmpRCSFinal.Name,
                                   RelationshipCode = MC.RelationshipCode,
                                   PayerMemberNumber = tmpMCMFinal.PayerMemberNumber,
                                   GroupName = GPNew.GroupName,
                                   LOB = tmpRCFinal.Name,
                                   GroupNumber = G.GroupNumber,
                                   GroupLevel = GPNew.GroupLevel,
                                   TrackingNumber = F.TrackingNumber,
                                   DateOpened = F.DateOpened,
                                   DateClosed = F.DateClosed,
                                   FileName = tmpDFinal.OriginalDocumentName,
                                   FileID = F.FileID,
                                   FileDescription = F.Subject,
                                   DocumentLocation = tmpDFinal.Location,
                                   OriginalDocumentName = tmpDFinal.OriginalDocumentName,
                                   Language = LEM.Language,
                                   DocumentID = tmpDFinal.DocumentId,
                                   WorkGroupName = WG.WorkGroupName,
                                   Subscriber = tmpMCMFinal.PayerMemberNumber,
                                   SubscriberLname = tmpMCMFinal.PolicyHolderLastName,
                                   SubscriberFname = tmpMCMFinal.PolicyHolderFirstName,
                                   SubscriberMname = tmpMCMFinal.PolicyHolderMiddleName,
                                   SubscriberSSN = tmpMCMFinal.PolicyHolderSSN,
                                   SubscriberGender = tmpMCMFinal.PolicyHolderGender,
                                   SubscriberDOB = tmpMCMFinal.PolicyHolderDOB,
                                   //SubscriberMedicareNumber = "",
                                   SubscriberMaritalStatus = M.MaritalStatus,
                                   SubscriberLanguage = LEM.Language,
                                   SubscriberAddress1 = tmpMCMFinal.Address1,
                                   SubscriberAddress2 = tmpMCMFinal.Address2,
                                   SubscriberCity = tmpMCMFinal.City,
                                   SubscriberState = tmpMCMFinal.State,
                                   SubscriberZip = tmpMCMFinal.Zip,
                                   SubscriberPhone = tmpMCMFinal.PolicyHolderPhone,
                                   MemberNumber = MC.MemberNumber,
                               };
                ESResult = ESResult.Distinct();

                if (memberSearchRequest.RowId != 0 && memberSearchRequest.RowId != null)
                {
                    ESResult = ESResult.Where(x => x.RowId == memberSearchRequest.RowId);
                }

                var FinalResult = await ESResult.ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = FinalResult.Count;
                statusRow.RowCount = FinalResult.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, ESResult);
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }


        /// <summary>
        /// OHI Approval Status Post Finish Verification in COB Portal
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<OHIApprovalStatusDto> results)> GetOHIApprovalStatus(OHIApprovalStatusRequest oHIApprovalStatusRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            try
            {
                var OHIResult = (from F in _dbContext.Files
                                 join MC in _dbContext.MemberCoverages on F.IndividualNumber equals MC.MemberNumber
                                 join MCM in _dbContext.MemberCarrierMap
                                     on new { MCMemberId = MC.MemberId } equals new { MCMemberId = MCM.MemberId }
                                 join T in _dbContext.Transactions on F.FileID equals T.FileID
                                 join D in _dbContext.Documents on T.DocumentId equals D.DocumentId into tmpD
                                 from tmpDFinal in tmpD.DefaultIfEmpty()
                                 join CR in _dbContext.ContactReasons on F.ReasonID equals CR.ReasonID
                                 join CS in _dbContext.ContactSteps on CR.ReasonID equals CS.ReasonID
                                 join EA in _dbContext.EntityAttributes on MCM.RowId equals EA.EntityId
                                 join CA in _dbContext.CustomAttributes on EA.AttributeId equals CA.AttributeID

                                 where EA.EntityType == "MCM"
                                     && CA.AttributeName == "Member Portal Response"
                                     && (EA.AttributeValue == "Coverage Added"
                                     || EA.AttributeValue == "Coverage Deleted"
                                     || EA.AttributeValue == "Coverage Edited"
                                     || EA.AttributeValue == "Coverage Verified")
                                     && MCM.MemberId == oHIApprovalStatusRequest.MemberId
                                     && F.TrackingNumber == oHIApprovalStatusRequest.TrackingNumber
                                 select new OHIApprovalStatusDto
                                 {
                                     MemberID = MCM.MemberId,
                                     AttributeId = EA.AttributeId,
                                     AttributeValue = EA.AttributeValue,
                                     EntityType = EA.EntityType,
                                     AttributeName = CA.AttributeName,
                                     TrackingNumber = F.TrackingNumber,
                                 }).Union(from F in _dbContext.Files
                                          join MC in _dbContext.MemberCoverages on F.IndividualNumber equals MC.MemberNumber
                                          join T in _dbContext.Transactions on F.FileID equals T.FileID
                                          join D in _dbContext.Documents on T.DocumentId equals D.DocumentId into tmpD
                                          from tmpDFinal in tmpD.DefaultIfEmpty()
                                          join CR in _dbContext.ContactReasons on F.ReasonID equals CR.ReasonID
                                          join CS in _dbContext.ContactSteps on CR.ReasonID equals CS.ReasonID
                                          join EA in _dbContext.EntityAttributes on MC.MemberId equals EA.EntityId
                                          join CA in _dbContext.CustomAttributes on EA.AttributeId equals CA.AttributeID

                                          where EA.EntityType == "Members"
                                          && CA.AttributeName == "COB on APP Portal Response"
                                          && (EA.AttributeValue == "Verified no OHI"
                                          || EA.AttributeValue == "Coverage Added")
                                          && MC.MemberId == oHIApprovalStatusRequest.MemberId
                                          && F.TrackingNumber == oHIApprovalStatusRequest.TrackingNumber
                                          select new OHIApprovalStatusDto
                                          {
                                              MemberID = MC.MemberId,
                                              AttributeId = EA.AttributeId,
                                              AttributeValue = EA.AttributeValue,
                                              EntityType = EA.EntityType,
                                              AttributeName = CA.AttributeName,
                                              TrackingNumber = F.TrackingNumber,
                                          });

                OHIResult = OHIResult.Distinct();

                var OHSFinalResult = await OHIResult.ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = OHSFinalResult.Count;
                statusRow.RowCount = OHSFinalResult.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, OHIResult);
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }


        /// <summary>
        /// COB Login Request with LetterID and MemberNumber
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<COBLoginDto> results)> COBLogin(COBLoginRequest cOBLoginRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            try
            {
                var COBLoginResult = from M in _dbContext.Members
                                     join MC in _dbContext.MemberCoverages on M.MemberId equals MC.MemberId
                                     join F in _dbContext.Files on MC.MemberNumber equals F.IndividualNumber
                                     join T in _dbContext.Transactions on F.FileID equals T.FileID
                                     join D in _dbContext.Documents on T.DocumentId equals D.DocumentId
                                     join CR in _dbContext.ContactReasons on F.ReasonID equals CR.ReasonID
                                     join CS in _dbContext.ContactSteps on CR.ReasonID equals CS.ReasonID
                                     join CRC in _dbContext.ContactReasonCategories on CR.CategoryID equals CRC.CategoryID
                                     join Ge in _dbContext.ReferenceCodes on new { Code = M.Gender, Type = "Gender" } equals new { Ge.Code, Ge.Type }
                                     join SC in _dbContext.SubscriberContracts on MC.SubscriberContractId equals SC.SubscriberContractID
                                     join G in _dbContext.Groups on SC.GroupId equals G.GroupId
                                     join GP in _dbContext.Groups on G.ParentId equals GP.GroupId
                                     join GPNew in _dbContext.Groups on GP.ParentId equals GPNew.GroupId

                                     where CRC.CategoryName == "RX OHI Verification"
                                         && T.DocumentId != null
                                         && F.IndividualCode == "MEM"
                                         && GP.GroupLevel == 2
                                         && GPNew.GroupLevel == 1
                                     orderby F.TrackingNumber descending

                                     select new COBSearchFilter
                                     {
                                         TrackingNumber = F.TrackingNumber,
                                         MemberNumber = MC.MemberNumber,
                                         DateOfBirth = M.DateOfBirth,
                                         MemberID = M.MemberId,
                                         FirstName = M.FirstName,
                                         MiddleName = M.MiddleName,
                                         LastName = M.LastName,
                                         Gender = Ge.Name,
                                         GroupName = GPNew.GroupName,
                                     };

                COBLoginResult = COBLoginResult.Distinct();

                if (!(string.IsNullOrEmpty(cOBLoginRequest.TrackingNumber)))
                {
                    COBLoginResult = COBLoginResult.Where(x => x.TrackingNumber == cOBLoginRequest.TrackingNumber);
                }
                if (!(string.IsNullOrEmpty(cOBLoginRequest.MemberNumber)))
                {
                    COBLoginResult = COBLoginResult.Where(x => x.MemberNumber == cOBLoginRequest.MemberNumber);
                }

                var FinalResult = await COBLoginResult.ToListAsync();

                List<COBLoginDto> COBLoginDtos = new List<COBLoginDto>();
                var cob = (from a in FinalResult
                           select new COBLoginDto
                           {
                               TrackingNumber = a.TrackingNumber,
                               MemberNumber = a.MemberNumber,
                               DateOfBirth = a.DateOfBirth,
                               MemberID = a.MemberID,
                               FirstName = a.FirstName,
                               MiddleName = a.MiddleName,
                               LastName = a.LastName,
                               Gender = a.Gender,
                               GroupName = a.GroupName,
                           });

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = FinalResult.Count;
                statusRow.RowCount = FinalResult.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, cob);
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }


        /// <summary>
        /// Member Search for COB
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<COBMemberSearchDto> results)> COBMemberSearch(COBMemberSearchRequest cOBMemberSearchRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            try
            {
                var COBMemberSearchResult = from dbGroupResult in (from CSI in _dbContext.ContactSteps
                                                                   join CRI in _dbContext.ContactReasons on CSI.ReasonID equals CRI.ReasonID
                                                                   join CRCI in _dbContext.ContactReasonCategories on CRI.CategoryID equals CRCI.CategoryID
                                                                   join WGI in _dbContext.WorkGroups on CSI.WorkGroupID equals WGI.WorkGroupID
                                                                   join FI in _dbContext.Files on CSI.ReasonID equals FI.ReasonID
                                                                   where CRCI.CategoryName == "RX OHI Verification"
                                                                   group new { FI.TrackingNumber, CSI.StepID } by new { FI.TrackingNumber } into grpResult
                                                                   select new
                                                                   {
                                                                       TrackingNumber = grpResult.Key.TrackingNumber,
                                                                       MaxStepID = grpResult.Max(x => x.StepID)
                                                                   })
                                            join CS in _dbContext.ContactSteps on dbGroupResult.MaxStepID equals CS.StepID
                                            join CR in _dbContext.ContactReasons on CS.ReasonID equals CR.ReasonID
                                            join CRC in _dbContext.ContactReasonCategories on CR.CategoryID equals CRC.CategoryID
                                            join WG in _dbContext.WorkGroups on CS.WorkGroupID equals WG.WorkGroupID
                                            join F in _dbContext.Files on new { CS.ReasonID, dbGroupResult.TrackingNumber } equals new { F.ReasonID, F.TrackingNumber }
                                            //join MC in _dbContext.MemberCoverages on F.IndividualNumber equals MC.MemberNumber
                                            join MC in _dbContext.MemberCoverages on F.IndividualID equals MC.MemberId
                                            join M in _dbContext.Members on MC.MemberId equals M.MemberId
                                            join MCM in _dbContext.MemberCarrierMap on new { MemberId = M.MemberId, CR.ReasonShortcut }
                                                                                equals new
                                                                                {
                                                                                    MemberId = MCM.MemberId,
                                                                                    ReasonShortcut = MCM.SupplementalType == "P" ? "MPSPV"
                                                                                                                                 : MCM.SupplementalType == "1" ? "MSP1V"
                                                                                                                                 : MCM.SupplementalType == "2" ? "MSP2V"
                                                                                                                                 : MCM.SupplementalType == "L" || MCM.SupplementalType == "M" || MCM.SupplementalType == "N" || MCM.SupplementalType == "O" || MCM.SupplementalType == "R" || MCM.SupplementalType == "T" || MCM.SupplementalType == "3" ? "MSPSV"
                                                                                                                                 : MCM.MSPType == "A" ? "MPSAV"
                                                                                                                                 : MCM.MSPType == "B" ? "MSPBV"
                                                                                                                                 : MCM.MSPType == "G" ? "MSPGV"
                                                                                                                                 : MCM.MSPType == "C" || MCM.MSPType == "F" || MCM.MSPType == "H" ? "MSPPV"
                                                                                                                                 : "CNCL"
                                                                                } into tmpMCM
                                            from tmpMCMFinal in tmpMCM.DefaultIfEmpty()
                                            join P in _dbContext.Payers on tmpMCMFinal.PayerId equals P.PayerId into tmpPayers
                                            from tmpPayersFinal in tmpPayers.DefaultIfEmpty()
                                            join SC in _dbContext.SubscriberContracts on MC.SubscriberContractId equals SC.SubscriberContractID
                                            join G in _dbContext.Groups on SC.GroupId equals G.GroupId
                                            join GP in _dbContext.Groups on G.ParentId equals GP.GroupId
                                            join GPNew in _dbContext.Groups on GP.ParentId equals GPNew.GroupId
                                            //join BC in _dbContext.BenefitCoverages on M.MemberId equals BC.EntityId
                                            join BC in _dbContext.BenefitCoverages on MC.MemberCoverageID equals BC.EntityId
                                            join RC in _dbContext.ReferenceCodes on new { Code = G.LOB, Type = "LineofBusiness", SubType = "LineofBusiness" }
                                                                                 equals new { RC.Code, RC.Type, RC.SubType } into tmpRC
                                            from tmpRCFinal in tmpRC.DefaultIfEmpty()
                                            join Ge in _dbContext.ReferenceCodes on new { Code = M.Gender, Type = "Gender" }
                                                                                 equals new { Ge.Code, Ge.Type } into tmpGe
                                            from tmpGeFinal in tmpGe.DefaultIfEmpty()
                                            join DEM in _dbContext.DocumentEntityMap on M.MemberId equals DEM.EntityId into tmpDEM
                                            from tmpDEMFinal in tmpDEM.DefaultIfEmpty()
                                            join D in _dbContext.Documents on tmpDEMFinal.DocumentId equals D.DocumentId into tmpD
                                            from tmpDFinal in tmpD.DefaultIfEmpty()
                                            join LEM in _dbContext.LanguageEntityMap on M.MemberId equals LEM.EntityID

                                            where F.IndividualCode == "MEM"
                                            && LEM.LanguageUse == "Primary"
                                            && GP.GroupLevel == 2
                                            && GPNew.GroupLevel == 1
                                            && BC.CoverageEntityType == "BAS"
                                            && LEM.EntityType == "MEM"
                                            && LEM.LanguageUse == "Primary"
                                            && BC.EntityTypeId == 3
                                            && CRC.CategoryName == "RX OHI Verification"

                                            select new COBMemberSearchFilter
                                            {
                                                LOB = tmpRCFinal.Name,
                                                ClientName = GPNew.GroupName,
                                                MemberId = M.MemberId,
                                                SocialSecurityNumber = M.SocialSecurityNumber,
                                                MemberFirstName = M.FirstName,
                                                MemberMiddleInitial = M.MiddleName,
                                                MemberLastName = M.LastName,
                                                DateOfBirth = M.DateOfBirth,
                                                Gender = tmpGeFinal.Name,
                                                Subscriber = tmpMCMFinal.PayerMemberNumber,
                                                SubscriberDateOfBirth = tmpMCMFinal.PolicyHolderDOB,
                                                SubscriberGender = tmpGeFinal.Name,
                                                OHIName = tmpPayersFinal.PayerName,
                                                OHINumber = tmpMCMFinal.PayerMemberNumber,
                                                OHIEffectiveDate = tmpMCMFinal.EffectiveDate,
                                                OHIExpirationDate = tmpMCMFinal.ExpirationDate,
                                                EffectiveDate = BC.EffectiveDate,
                                                ExpirationDate = BC.ExpirationDate,
                                                RowId = tmpMCMFinal.RowId,
                                                MemberNumber = MC.MemberNumber
                                            };

                COBMemberSearchResult = COBMemberSearchResult.Distinct();

                if (cOBMemberSearchRequest.MemberId != 0 && cOBMemberSearchRequest.MemberId != null)
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.MemberId == cOBMemberSearchRequest.MemberId);
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.SocialSecurityNumber)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.SocialSecurityNumber.StartsWith(cOBMemberSearchRequest.SocialSecurityNumber));
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.MemberFirstName)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.MemberFirstName.StartsWith(cOBMemberSearchRequest.MemberFirstName));
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.MemberMiddleInitial)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.MemberMiddleInitial.StartsWith(cOBMemberSearchRequest.MemberMiddleInitial));
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.MemberLastName)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.MemberLastName.StartsWith(cOBMemberSearchRequest.MemberLastName));
                }
                if (cOBMemberSearchRequest.DateOfBirth != null)
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.DateOfBirth == cOBMemberSearchRequest.DateOfBirth);
                }
                if (!string.IsNullOrEmpty(cOBMemberSearchRequest.Gender))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.Gender == cOBMemberSearchRequest.Gender);
                }
                if (!string.IsNullOrEmpty(cOBMemberSearchRequest.Subscriber))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.Subscriber == cOBMemberSearchRequest.Subscriber);
                }
                if (cOBMemberSearchRequest.SubscriberDateOfBirth != null)
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.SubscriberDateOfBirth == cOBMemberSearchRequest.SubscriberDateOfBirth);
                }
                if (!string.IsNullOrEmpty(cOBMemberSearchRequest.SubscriberGender))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.SubscriberGender == cOBMemberSearchRequest.SubscriberGender);
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.OHIName)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.OHIName.StartsWith(cOBMemberSearchRequest.OHIName));
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.OHINumber)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.OHINumber.StartsWith(cOBMemberSearchRequest.OHINumber));
                }
                if (cOBMemberSearchRequest.OHIEffectiveDate != null)
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.OHIEffectiveDate == cOBMemberSearchRequest.OHIEffectiveDate);
                }
                if (cOBMemberSearchRequest.OHIExpirationDate != null)
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.OHIExpirationDate == cOBMemberSearchRequest.OHIExpirationDate);
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.ClientName)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.ClientName.StartsWith(cOBMemberSearchRequest.ClientName));
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.LOB)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.LOB == cOBMemberSearchRequest.LOB);
                }
                if (!(string.IsNullOrEmpty(cOBMemberSearchRequest.MemberNumber)))
                {
                    COBMemberSearchResult = COBMemberSearchResult.Where(x => x.MemberNumber == cOBMemberSearchRequest.MemberNumber);
                }

                if (cOBMemberSearchRequest.ResultPageNumber != null && cOBMemberSearchRequest.ResultCount != null)
                {
                    COBMemberSearchResult = COBMemberSearchResult.Skip((cOBMemberSearchRequest.ResultPageNumber.Value - 1) * cOBMemberSearchRequest.ResultCount.Value)
                                     .Take(cOBMemberSearchRequest.ResultCount.Value);
                }

                var FinalResult = await COBMemberSearchResult.ToListAsync();

                List<COBMemberSearchDto> COBMemberSearchDtos = new List<COBMemberSearchDto>();
                foreach (var item in FinalResult)
                {
                    COBMemberSearchDto cOBMemberSearchDto = new COBMemberSearchDto();
                    cOBMemberSearchDto.MemberId = item.MemberId;
                    cOBMemberSearchDto.MemberFirstName = item.MemberFirstName;
                    cOBMemberSearchDto.MemberMiddleInitial = item.MemberMiddleInitial;
                    cOBMemberSearchDto.MemberLastName = item.MemberLastName;
                    cOBMemberSearchDto.Subscriber = item.Subscriber;
                    cOBMemberSearchDto.SocialSecurityNumber = item.SocialSecurityNumber;
                    cOBMemberSearchDto.DateOfBirth = item.DateOfBirth;
                    cOBMemberSearchDto.Gender = item.Gender;
                    cOBMemberSearchDto.EffectiveDate = item.EffectiveDate;
                    cOBMemberSearchDto.ExpirationDate = item.ExpirationDate;
                    cOBMemberSearchDto.ClientName = item.ClientName;
                    cOBMemberSearchDto.LOB = item.LOB;
                    cOBMemberSearchDto.SubscriberDateOfBirth = item.SubscriberDateOfBirth;
                    cOBMemberSearchDto.OHIName = item.OHIName;
                    cOBMemberSearchDto.OHINumber = item.OHINumber;
                    cOBMemberSearchDto.OHIEffectiveDate = item.OHIEffectiveDate;
                    cOBMemberSearchDto.OHIExpirationDate = item.OHIExpirationDate;
                    cOBMemberSearchDto.RowId = item.RowId;
                    cOBMemberSearchDto.MemberNumber = item.MemberNumber;

                    COBMemberSearchDtos.Add(cOBMemberSearchDto);
                }

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = FinalResult.Count;
                statusRow.RowCount = FinalResult.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, COBMemberSearchDtos);
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }
    }
}