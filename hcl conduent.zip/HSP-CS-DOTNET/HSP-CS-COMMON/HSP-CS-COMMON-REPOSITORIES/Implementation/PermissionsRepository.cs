﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Permissions;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Request.Permissions;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class PermissionsRepository
        : IPermissionsRepository
    {
        private readonly HSPDbContext context;

        public PermissionsRepository(HSPDbContext ctx)
            => context = ctx;

        /// <summary>
        /// Gets the list of permissions for a user via
        ///  - UserId
        ///     If a UserId is present, the SessionId is ignored
        ///  - SessionId
        ///  - Usage
        ///         Defaults to USAGE1
        ///         Options
        ///             - USAGE1 => Allowed permissions
        ///             - USAGE2 => Not Allowed permissions
        ///             - USAGE3 => USAGE1 + USAGE 2
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> status, IEnumerable<UserPermission> results)> GetPermissionsAsync(GetPermissionsRequest req)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var searchStatusRow = new HSPSearchStatusRow();
            
            var userId = 0;
            var result = new List<UserPermission>();

            if (req.UserId != null && req.UserId > 0 && req.SessionId == 0)
                userId = (int)req.UserId;

            if (userId == 0)
            {
                var session =
                    await context.Sessions
                        .Where(x => x.SessionId == req.SessionId)
                        .FirstOrDefaultAsync();

                if (session != null)
                    userId = session.UserId;
            }

            if (userId != 0)
            {
                var allowedPermissions =
                    (
                        // Permissions W/O Role
                        from perm in context.Permissions
                        join rba in context.RoleBasedAccess
                            on perm.PermissionId equals rba.PermissionId
                            into lj1
                        from ljp in lj1.DefaultIfEmpty()
                        where perm.ProductName == req.ProductName
                        where ljp.PermissionId == null
                        select perm
                    )
                    .Union
                    (
                        // Permissions For Product
                        // Permissions Without Any Product
                        from perm in context.Permissions
                        where
                        (
                            perm.ProductName == req.ProductName
                            || string.IsNullOrEmpty(perm.ProductName)
                        )
                        select perm
                    ).Distinct();

                var restrictedPermissions =
                    (
                        // Current Setup
                        // Gets the permissions to remove
                        from u in context.Users
                        join ur in context.UserRoles
                            on u.UserId equals ur.UserId
                        join r in context.Roles
                            on ur.RoleId equals r.RoleId
                        join rba in context.RoleBasedAccess
                            on ur.RoleId equals rba.RoleId
                        join ap in context.Permissions
                            on rba.PermissionId equals ap.PermissionId
                        // it doesn't matter whether you do multiple where clauses
                        // or one with &&, the same code gets generated.
                        where u.UserId == userId
                        where r.RoleStatus == "2"
                        where r.RoleType == "FBA"
                        where r.RoleSubType == "PRM"
                        where rba.EntityId == null
                        select new
                        {
                            RoleId = r.RoleId,
                            RoleName = r.RoleName,
                            RoleDescription = r.RoleDescription,
                            PermissionId = (int?)ap.PermissionId, // nullable for the HasPermission Check
                            PermissionName = ap.PermissionName,
                            ProductName = ap.ProductName
                        }
                    );

                var reversedPermissions =
                    from ap in allowedPermissions
                    join rp in restrictedPermissions
                        on ap.PermissionId equals rp.PermissionId
                        into lj1
                    from ljp in lj1.DefaultIfEmpty()
                    select new UserPermission
                    {
                        UserId = userId,
                        PermissionId = ap.PermissionId,
                        ProductName = ap.ProductName,
                        EntityType = ap.EntityType,
                        PermissionName = ap.PermissionName,
                        HasPermission = ljp.PermissionId == null
                    };

                IQueryable<UserPermission> resultQuery;

                switch (req.Usage)
                {
                    case "USAGE1":
                        resultQuery = reversedPermissions.Where(x => x.HasPermission == true);
                        break;

                    case "USAGE2":
                        resultQuery = reversedPermissions.Where(x => x.HasPermission == false);
                        break;

                    case "USAGE3":
                    default:
                        resultQuery = reversedPermissions;
                        break;
                }

                result = await resultQuery.ToListAsync();
            }

            searchStatusRow.TotalCount = result.Count();
            searchStatusRow.Status = HSPDbStatus.Normal;
            searchStatusRow.Success = true;
            dbResult.StatusRow = searchStatusRow;

            return (dbResult, result);
        }

        /// <summary>
        /// Get the list of permissions
        /// </summary>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> status, IEnumerable<Permission> results)> GetPermissionsAsync()
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var searchStatusRow = new HSPSearchStatusRow();

            var result =
                await context.Permissions.ToListAsync();

            searchStatusRow.TotalCount = result.Count();
            searchStatusRow.Status = HSPDbStatus.Normal;
            searchStatusRow.Success = true;
            dbResult.StatusRow = searchStatusRow;

            return (dbResult, result);


        }
    }
}