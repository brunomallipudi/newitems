﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_ENTITIES.DTO.Individuals;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class IndividualsRepository : Repository, IIndividualsRepository
    {

        public const string HSP_SP_FindIndividualExtended_V2 = "ee_FindIndividualExtended_V2";
        public const string HSP_SP_UpdateIndividual = "ee_UpdateIndividual";
        public const string HSP_SP_AddIndividuals = "ee_AddIndividual";
        public const string HSP_SP_GetIndividualProfile_XML = "ee_GetIndividualProfile_XML";
        public const string HSP_SP_FindIndividualInfo_XML = "ee_FindIndividual_XML";

        public IndividualsRepository(IDbConnectionString connectionStrings, ILogger<IndividualsRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Find Individuals.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Individuals.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<IndividualDto> results)>FindIndividuals(object parameters)
        {
            return await GetAsync<IndividualDto>(HSP_SP_FindIndividualExtended_V2, parameters);
        }

        /// <summary>
        /// Update Individual
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateIndividual(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateIndividual, parameters);

        /// <summary>
        /// Add Individual
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, AddIndividualDto result)> AddIndividual(object parameters)
        {
            return
                await AddOneAsync<HSPStatusRow, AddIndividualDto>
                (
                    HSP_SP_AddIndividuals,
                    parameters
                );
        }

        /// <summary>
        /// Returns the Individual profile xml.
        /// </summary>
        /// <param name="parameters">Request for Individual profile xml.</param>
        /// <returns>Individual profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetIndividualProfile_XML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetIndividualProfile_XML, parameters);

        /// <summary>
        /// Returns the Find Individual Info xml.
        /// </summary>
        /// <param name="parameters">Request for Find Individual Info xml.</param>
        /// <returns>Find Individual Info in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> FindIndividualInfo(object parameters)
           => await GetXmlAsync<HSPStatusRow>(HSP_SP_FindIndividualInfo_XML, parameters);
    }
}
