﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ProcedureCodesRepository : Repository, IProcedureCodesRepository
    {
        public const string HSP_SP_GetProcedureCodes = "ee_GetProcedureCodes";

        public ProcedureCodesRepository(IDbConnectionString connectionStrings, ILogger<ProcedureCodesRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Get a list of Procedure Codes.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Procedure Codes.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ProcedureCodeDto> results)> GetProcedureCodes(object parameters)
        {
            return await GetAsync<ProcedureCodeDto>(HSP_SP_GetProcedureCodes, parameters);
        }
    }
}