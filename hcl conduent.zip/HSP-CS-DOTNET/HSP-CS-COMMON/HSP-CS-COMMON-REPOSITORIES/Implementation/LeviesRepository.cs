﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.Levies;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class LeviesRepository : Repository, ILeviesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetLevies = "ee_GetLevies";

        #endregion Procedure Names

        #region Constructors

        public LeviesRepository(IDbConnectionString connectionStrings, ILogger<LeviesRepository> logger, IConfiguration config)
          : base(connectionStrings, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get Levies.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<LevyDto> results)> GetLevies(object parameters)
        {
            return await GetAsync<LevyDto>(HSP_SP_GetLevies, parameters);
        }
    }
}
