﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.ContactSteps;
using HSP_CS_COMMON_ENTITIES.DTO.ContactStepFulfillments;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ContactStepsRepository
        : Repository, IContactStepsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetContactSteps = "ee_GetContactSteps";
        public const string HSP_SP_GetFulfillmentForContactStep = "ee_GetFulfillmentForContactStep";
 
        #endregion Procedure Names

        #region Constructors

        public ContactStepsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public ContactStepsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of contact steps
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactStepDto> results)> GetContactSteps(object parameters)
            => await GetAsync<ContactStepDto>(HSP_SP_GetContactSteps, parameters);

        /// <summary>
        /// Get a list of fullfillment for contact step
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactStepFulfillmentDto> results)> GetFulfillmentforContactStep(object parameters)
            => await GetAsync<ContactStepFulfillmentDto>(HSP_SP_GetFulfillmentForContactStep, parameters);
    }
}