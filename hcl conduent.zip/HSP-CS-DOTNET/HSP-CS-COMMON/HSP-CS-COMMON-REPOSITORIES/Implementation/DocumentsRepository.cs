﻿using Dapper;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.ErrorHandling;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Documents;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Request.Documents;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class DocumentsRepository : Repository, IDocumentsRepository
    {
        private ILogger<DocumentsRepository> _loggerDocuments;

        #region Procedures Names

        public const string HSP_SP_GetDocumentEntityMap = "ee_GetDocumentEntityMap";
        public const string HSP_SP_GetDocuments = "ee_GetDocuments";
        public const string HSP_SP_AddDocumentEntityMap = "ee_AddDocumentEntityMap";
        public const string HSP_SP_AddDocumentForEntity = "ee_AddDocumentForEntity";
        public const string HSP_SP_AddFileEntityMap = "ee_AddFileEntityMap";
        public const string HSP_SP_GetDonePath = "ee_GetPath"; 
        public const string HSP_SP_DeleteDocumentEntityMap = "ee_DeleteDocumentEntityMap";
        public const string HSP_SP_UpdateDocumentEntityMap = "ee_UpdateDocumentEntityMap";
        public const string HSP_SP_UpdateDocument = "ee_UpdateDocument";
        public const string HSP_SP_AddDocument = "ee_AddDocument";

        #endregion

        #region Constructors

        public DocumentsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, ILogger<DocumentsRepository> loggerDocuments, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
            _loggerDocuments = loggerDocuments;
        }

        public DocumentsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion

        /// <summary>
        /// Get Entity Documents
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DocumentEntityMapDto> results)> GetEntityDocuments(object parameters)
          => await GetAsync<DocumentEntityMapDto>(HSP_SP_GetDocumentEntityMap, parameters);

        /// <summary>
        /// Get Documents
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DocumentDto> results)> GetDocuments(object parameters)
            => await GetAsync<DocumentDto>(HSP_SP_GetDocuments, parameters);

        /// <summary>
        /// Get Document by Id.
        /// </summary>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, DocumentFullDto result)> GetDocumentById(int sessionId, int documentId)
            => await GetOneAsync<HSPSearchStatusRow, DocumentFullDto>(HSP_SP_GetDocuments, new { SessionId = sessionId, DocumentId = documentId, Usage = "|ByDocumentId|" });

        /// <summary>
        /// Add Document Entity Map entry
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> AddDocumentEntityMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_AddDocumentEntityMap,
                    parameters
                );
        }

        /// <summary>
        /// Add Document For Entity
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Add document and return created documentID</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, AddDocumentForEntityDto result)> AddDocumentForEntity(AddDocumentForEntityRequestDto parameters)
        {
            try
            {
                using (var connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
                {
                    var dbResult = new HSPDbResult<HSPStatusRow>();
                    var addDocumentForEntityDto = new AddDocumentForEntityDto();

                    SetupInfoMessageHandling(connection, dbResult);

                    await connection.OpenAsync();

                    using (var transaction = await connection.BeginTransactionAsync())
                    {
                        var parameters1 = new
                        {
                            SessionId = parameters.SessionId,
                            DocumentNumber = parameters.DocumentNumber,
                            DocumentTypeCode = parameters.DocumentTypeCode,
                            Subject = parameters.Subject,
                            Description = parameters.Description,
                            IndividualNumber = parameters.IndividualNumber,
                            IndividualCode = parameters.IndividualCode,
                            ReferenceNumber = parameters.ReferenceNumber,
                            ReferenceDate = parameters.ReferenceDate,
                            ContentType = parameters.ContentType,
                            ContentSubType = parameters.ContentSubType,
                            TransactionId = parameters.TransactionId,
                            OriginalDocumentName = parameters.OriginalDocumentName,
                            ImageType = parameters.ImageType,
                            Location = parameters.Location,
                            TimeStamp = parameters.TimeStamp,
                            FromWeb = parameters.FromWeb,
                            ReferralDocumentID = parameters.ReferralDocumentID,
                            Usage = parameters.Usage
                        };

                        using var dapperResult1 =
                            await connection.QueryMultipleAsync(HSP_SP_AddDocumentForEntity, parameters1, transaction, commandType: CommandType.StoredProcedure);

                        var statusRow1 = await dapperResult1.ReadFirstOrDefaultAsync<HSPStatusRow>();
                        if (statusRow1.Status != HSPDbStatus.Normal)
                        {
                            transaction.Rollback();
                            dbResult.StatusRow = statusRow1;
                            dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                            return (dbResult, null);
                        }

                        addDocumentForEntityDto = await dapperResult1.ReadFirstAsync<AddDocumentForEntityDto>();
                        if (parameters.EntityType == "FIL") 
                          {
                            var parameters2 = new
                            {
                                SessionId = parameters.SessionId,
                                entityType = "WIN",
                                entityId = addDocumentForEntityDto.DocumentId,
                                fileId = parameters.EntityId
                            };

                            using var dapperResult2 =
                            await connection.QueryMultipleAsync(HSP_SP_AddFileEntityMap, parameters2, transaction, commandType: CommandType.StoredProcedure);
                            var statusRow2 = await dapperResult2.ReadFirstOrDefaultAsync<HSPStatusRow>();
                            if (statusRow2.Status != HSPDbStatus.Normal)
                            {
                                transaction.Rollback();
                                dbResult.StatusRow = statusRow2;
                                dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                                return (dbResult, null);
                            }

                            dbResult.StatusRow = statusRow2;
                            dbResult.StatusRow.Success = true;

                            transaction.Commit();
                        }
                       else
                        {
                            var parameters2 = new
                            {
                                parameters.SessionId,
                                parameters.EntityType,
                                parameters.EntityId,
                                DocumentId = addDocumentForEntityDto.DocumentId
                            };
                            using var dapperResult2 =
                            await connection.QueryMultipleAsync(HSP_SP_AddDocumentEntityMap, parameters2, transaction, commandType: CommandType.StoredProcedure);
                            var statusRow2 = await dapperResult2.ReadFirstOrDefaultAsync<HSPStatusRow>();
                            if (statusRow2.Status != HSPDbStatus.Normal)
                            {
                                transaction.Rollback();
                                dbResult.StatusRow = statusRow2;
                                dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                                return (dbResult, null);
                            }
                            dbResult.StatusRow = statusRow2;
                            dbResult.StatusRow.Success = true;
                            transaction.Commit();
             
                        }
                        return (dbResult, addDocumentForEntityDto);
                    }
                }
            }
            catch (Exception exception)
            {
                _loggerDocuments.LogError(exception, $"Exception in {nameof(AddDocumentForEntity)}.");
                throw;
            }
        }       

        /// <summary>
        /// Get Done Path
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, DonePathDto results)> GetDonePath(object parameters)
        {
            return await GetOneAsync<HSPStatusRow, DonePathDto>(HSP_SP_GetDonePath, parameters);            
        }

        /// <summary>
        /// Delete Document Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteDocumentEntityMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_DeleteDocumentEntityMap,
                    parameters
                );
        }

        /// <summary>
        /// Update Document Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateDocumentEntityMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_UpdateDocumentEntityMap,
                    parameters
                );
        }
        /// <summary>
        /// Update Document
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateDocument(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_UpdateDocument,
                    parameters
                );
        }

        /// <summary>
        /// Adds Document
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow>, AddDocumentDto result)> AddDocument(object parameters)
        {
            return
                await AddOneAsync<HSPStatusRow, AddDocumentDto>
                (
                    HSP_SP_AddDocument,
                    parameters
                );
        }
    }
}
