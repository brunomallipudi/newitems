﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// Member Coverages repository.
    /// </summary>
    public class MemberCoveragesRepository : Repository, IMemberCoveragesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GETMEMBERCOVERAGES = "EE_GETMEMBERCOVERAGES";

        #endregion Procedure Names

        #region Constructors

        public MemberCoveragesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public MemberCoveragesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get Member Coverages .
        /// </summary>
        /// <param name="parameters">Member Coverages request.</param>
        /// <returns>List of Member Coverages.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetMemberCoveragesAsync(object parameters)
            => await GetAsync<dynamic>(HSP_SP_GETMEMBERCOVERAGES, parameters);
    }
}
