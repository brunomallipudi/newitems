﻿using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ListviewSettingsRepository : IListviewSettingsRepository
    {
        private readonly HSPDbContext _dbContext;

        public ListviewSettingsRepository(HSPDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// Get the listview settings for a particular listview.
        /// </summary>
        /// <param name="listviewName">Name of the listview.</param>
        /// <returns>The listview column settings.</returns>
        public async Task<ListviewSetting> GetListviewSettings(string listviewName)
            => await _dbContext.ListviewSettings
                               .FirstOrDefaultAsync(listviewSetting => listviewSetting.ListviewName == listviewName);
    }
}
