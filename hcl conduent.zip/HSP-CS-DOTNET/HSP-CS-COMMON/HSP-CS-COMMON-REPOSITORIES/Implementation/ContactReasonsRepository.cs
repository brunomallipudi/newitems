﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.ContactReasons;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ContactReasonsRepository
        : Repository, IContactReasonsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetContactReasons_V4 = "EE_GetContactReasons_V4";
        public const string HSP_SP_GetContactReasonsForStep = "ee_GetContactReasonsForStep";
        public const string HSP_SP_GetContactStepsToSkipTo = "ee_GetContactStepsToSkipTo";

        #endregion Procedure Names

        #region Constructors

        public ContactReasonsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public ContactReasonsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of contact reasons
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactReasonDto> results)> GetContactReasons(object parameters)
            => await GetAsync<ContactReasonDto>(HSP_SP_GetContactReasons_V4, parameters);

        /// <summary>
        /// Get a list of contact reason for step
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactReasonForStepDto> results)> GetContactReasonsForStep(object parameters)
            => await GetAsync<ContactReasonForStepDto>(HSP_SP_GetContactReasonsForStep, parameters);

        /// <summary>
        /// Get a list of contact steps to skip to
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactStepToSkipToDto> results)> GetContactStepsToSkipTo(object parameters)
            => await GetAsync<ContactStepToSkipToDto>(HSP_SP_GetContactStepsToSkipTo, parameters);
    }
}