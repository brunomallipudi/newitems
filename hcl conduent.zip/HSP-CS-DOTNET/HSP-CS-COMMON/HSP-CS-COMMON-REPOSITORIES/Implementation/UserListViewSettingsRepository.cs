﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.UserListViewSettings;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// UserListViewSettings Repository
    /// </summary>
    public class UserListViewSettingsRepository
        : Repository, IUserListViewSettingsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GETUSERLISTVIEWSETTINGS = "EE_GETUSERLISTVIEWSETTINGS";
        public const string HSP_SP_ADDUSERLISTVIEWSETTINGS = "EE_ADDUSERLISTVIEWSETTING";
        public const string HSP_SP_UPDATEUSERLISTVIEWSETTINGS = "EE_UPDATEUSERLISTVIEWSETTING";

        #endregion Procedure Names

        #region Constructors

        public UserListViewSettingsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public UserListViewSettingsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Gets any stored user settings for list views
        /// </summary>
        /// <param name="parameters">search parameters</param>
        /// <returns>(dbstatus, dbresult)</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, UserListViewSettingDto result)> GetUserListViewSettingsAsync(object parameters)
                => await GetOneAsync<HSPStatusRow, UserListViewSettingDto>(HSP_SP_GETUSERLISTVIEWSETTINGS, parameters);

        /// <summary>
        /// Adds a new entry for a list view
        /// </summary>
        /// <param name="parameters">settings</param>
        /// <returns>dbstatus</returns>
        public async Task<HSPDbResult<HSPAddEntryStatusRow>> AddUserListViewSettingsAsync(object parameters)
            => await AddOneAsync(HSP_SP_ADDUSERLISTVIEWSETTINGS, parameters);

        /// <summary>
        /// Update an entry for a list view
        /// </summary>
        /// <param name="parameters">settings</param>
        /// <returns>dbstatus</returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateUserListViewSettingsAsync(object parameters)
            => await ExecuteAsync<HSPStatusRow> (HSP_SP_UPDATEUSERLISTVIEWSETTINGS, parameters);
    }
}