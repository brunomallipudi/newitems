﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class UsersRepository : Repository, IUsersRepository
    {
        public const string HSP_SP_GetUsers = "ee_GetUsers_V3";
        public const string HSP_SP_FindUser = "ee_Finduser";

        public UsersRepository(IDbConnectionString connectionStrings, ILogger<UsersRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        /// <summary>
        /// Get a list of Users.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of Users.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserDto> results)> GetUsers(object parameters)
        {
            return await GetAsync<UserDto>(HSP_SP_GetUsers, parameters);
        }
        /// <summary>
        /// Find an User.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns> Find User.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindUserDto> results)> FindUser(object parameters)
        {
            return await GetAsync<FindUserDto>(HSP_SP_FindUser, parameters);
        }
    }
}