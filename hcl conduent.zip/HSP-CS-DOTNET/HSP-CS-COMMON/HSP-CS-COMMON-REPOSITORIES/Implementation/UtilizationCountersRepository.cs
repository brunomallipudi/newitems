﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.UtilizationCounters;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// Utilization Counters repository.
    /// </summary>
    public class UtilizationCountersRepository : Repository, IUtilizationCountersRepository
    {
        #region Procedure Name

        public const string HSP_SP_GETUTILIZATIONCOUNTERS = "EE_GETUTILIZATIONCOUNTERS";
        public const string HSP_SP_GetUtilizationCounters_Xml = "ee_GetUtilizationCounters_XML";

        #endregion Procedure Name

        #region Constructors

        public UtilizationCountersRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public UtilizationCountersRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Gets the Utilization Counters.
        /// </summary>
        /// <param name="parameters"> Utilization Counters request.</param>
        /// <returns>List of Utilization Counters.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UtilizationCounterDto> results)> GetUtilizationCountersAsync(object parameters)
            => await GetAsync<UtilizationCounterDto>(HSP_SP_GETUTILIZATIONCOUNTERS, parameters);

        /// <summary>
        /// Gets the Utilization Counters Xml.
        /// </summary>
        /// <param name="parameters"> Utilization Counters Xml request.</param>
        /// <returns>Utilization Counters Xml as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetUtilizationCountersXml(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetUtilizationCounters_Xml, parameters);
    }
}
