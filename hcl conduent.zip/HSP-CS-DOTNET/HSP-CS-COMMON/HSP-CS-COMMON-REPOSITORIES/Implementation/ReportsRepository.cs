﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Reports;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Request.Reports;
using HSP_CS_COMMON_REPOSITORIES.ResultHandling.Reports;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ReportsRepository : Repository, IReportsRepository
    {
        private readonly HSPDbContext _dbContext;
        private readonly ILogger<ReportsRepository> _logger;

        #region Procedure Names

        public const string HSP_SP_GetUserReportMaps = "ee_GetUserReportMaps";
        public const string HSP_SP_AddUserReportMap = "ee_AddUserReportMap";
        public const string HSP_SP_DeleteUserReportMap = "ee_DeleteUserReportMap";
        public const string HSP_SP_UpdateUserReportMap = "ee_UpdateUserReportMap";
        public const string HSP_SP_GetOnlineReports = "ee_GetOnlineReports";
        public const string HSP_SP_GetUserReportDefaultColumns = "ee_GetUserReportDefaultColumns";
        public const string HSP_SP_GetReports = "ee_GetReports";
        public const string HSP_SP_GetParameters = "ee_GetParameters";
        public const string HSP_SP_GetReportUsage = "rr_GetReportUsage";
        public const string HSP_SP_UpdateReportUsage = "ee_UpdateReportUsage";
        public const string HSP_SP_AddReportUsage = "ee_AddReportUsage";

        #endregion Procedure Names

        #region Constructors

        public ReportsRepository(IDbConnectionString connectionStrings, ILogger<ReportsRepository> logger, IConfiguration config, HSPDbContext dbContext) : base(connectionStrings, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public ReportsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<ReportsRepository> logger, IConfiguration config, HSPDbContext dbContext) : base(connectionStrings, session, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        #endregion Constructors

        /// <summary>
        /// Get User Report Maps
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserReportMapDto> results)> GetUserReportMaps(object parameters)
            => await GetAsync<UserReportMapDto>(HSP_SP_GetUserReportMaps, parameters);

        /// <summary>
        /// Add an User Report Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPAddEntryStatusRow>> AddUserReportMap(object parameters)
        {
            return
                await ExecuteAsync<HSPAddEntryStatusRow>
                (
                    HSP_SP_AddUserReportMap,
                    parameters
                );
        }

        /// <summary>
        /// Delete User Report Map.
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteUserReportMap(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_DeleteUserReportMap, parameters);

        /// <summary>
        /// Update User Report Map
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateUserReportMap(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateUserReportMap, parameters);

        /// <summary>
        /// Get User Report Default Columns
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserReportDefaultColumnDto> results)> UserReportDefaultColumns(object parameters)
            => await GetAsync<UserReportDefaultColumnDto>(HSP_SP_GetUserReportDefaultColumns, parameters);

        /// <summary>
        /// Get Reports Category
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportCategoryDto> results)> GetReportCategories(int sessionId, string productName)
            => await GetAsync<ReportCategoryDto>(HSP_SP_GetReports, new { sessionId, productName, usage = "|CATEGORYNAMES|" });

        /// <summary>
        /// Get Reports Sub Category
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportSubCategoryDto> results)> GetReportSubCategories(int sessionId, string productName, string categoryName)
            => await GetAsync<ReportSubCategoryDto>(HSP_SP_GetReports, new { sessionId, productName, categoryName, usage = "|SUBCATEGORYNAMES|" });

        /// <summary>
        /// Get Online Reports
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<OnlineReportDto> results)> GetOnlineReports(object parameters)
            => await GetAsync<OnlineReportDto>(HSP_SP_GetOnlineReports, parameters);

        /// <summary>
        /// Get Reports
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportDto> results)> GetReports(object parameters)
            => await GetAsync<ReportDto>(HSP_SP_GetReports, parameters);

        /// <summary>
        /// Get Parameters
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportParameterDto> results)> GetReportParameters(object parameters)
            => await GetAsync<ReportParameterDto>(HSP_SP_GetParameters, parameters);

        /// <summary>
        /// Find Reports
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindReportDto> results)> FindReports(FindReportsRequest findReportsRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();

            string productName = findReportsRequest.ProductName switch
            {
                "E-Uniflow" => "Uniflow",
                _ => findReportsRequest.ProductName
            };

            var excludedReportTypes = new [] { "Template", "StyleSheet" };

            try
            {
                var query1 = from oReports in _dbContext.OnlineReports
                             join catRC in _dbContext.ReferenceCodes
                                 on new { oReports.CategoryCode, Type = "ReportCategory" } equals new { CategoryCode = catRC.Code, catRC.Type }
                             into categories
                             from category in categories.DefaultIfEmpty()
                             join subCatRC in _dbContext.ReferenceCodes
                                 on new { oReports.SubCategoryCode, Type = "ReportSubCategory" } equals new { SubCategoryCode = subCatRC.Code, subCatRC.Type }
                             into subCategories
                             from subCategory in subCategories.DefaultIfEmpty()
                             where (
                                 (string.IsNullOrEmpty(findReportsRequest.CategoryName) || category.Name.ToLower().StartsWith(findReportsRequest.CategoryName.ToLower()))
                                 && (string.IsNullOrEmpty(findReportsRequest.SubCategoryName) || subCategory.Name.ToLower().StartsWith(findReportsRequest.SubCategoryName.ToLower()))
                                 && (string.IsNullOrEmpty(findReportsRequest.ReportName) || oReports.ReportName.ToLower().StartsWith(findReportsRequest.ReportName.ToLower()))
                                 && oReports.ProductName == productName
                                 && !excludedReportTypes.Contains(oReports.ReportType)
                             )
                             select new FindReportDto
                             {
                                 ReportId = oReports.ReportId,
                                 ReportTypeCode = "OLN",
                                 ReportType = "Online Report",
                                 ReportName = oReports.ReportName,
                                 CategoryName = category.Name,
                                 SubCategoryName = subCategory.Name
                             };

                var query2 = from uReports in _dbContext.UserReports
                             join oReports in _dbContext.OnlineReports
                                on uReports.OperationalReportId equals oReports.ReportId
                             join catRC in _dbContext.ReferenceCodes
                                 on new { oReports.CategoryCode, Type = "ReportCategory" } equals new { CategoryCode = catRC.Code, catRC.Type }
                             into categories
                             from category in categories.DefaultIfEmpty()
                             join subCatRC in _dbContext.ReferenceCodes
                                 on new { oReports.SubCategoryCode, Type = "ReportSubCategory" } equals new { SubCategoryCode = subCatRC.Code, subCatRC.Type }
                             into subCategories
                             from subCategory in subCategories.DefaultIfEmpty()
                             where (
                                 (string.IsNullOrEmpty(findReportsRequest.CategoryName) || category.Name.ToLower().StartsWith(findReportsRequest.CategoryName.ToLower()))
                                 && (string.IsNullOrEmpty(findReportsRequest.SubCategoryName) || subCategory.Name.ToLower().StartsWith(findReportsRequest.SubCategoryName.ToLower()))
                                 && (string.IsNullOrEmpty(findReportsRequest.ReportName) || uReports.ReportName.ToLower().StartsWith(findReportsRequest.ReportName.ToLower()))
                                 && oReports.ProductName == productName
                                 && !excludedReportTypes.Contains(oReports.ReportType)
                             )
                             select new FindReportDto
                             {
                                 ReportId = uReports.UserReportId,
                                 ReportTypeCode = "USR",
                                 ReportType = "User Report",
                                 ReportName = uReports.ReportName,
                                 CategoryName = category.Name,
                                 SubCategoryName = subCategory.Name
                             };

                var reports = await query1.Union(query2).ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = reports.Count;
                statusRow.RowCount = reports.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, reports);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Exception in {nameof(FindReports)}.", exception);
                statusRow.Status = HSPDbStatus.ApiError;
                statusRow.ErrorMessage = "Unable to retrieve the reports because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;

                return (dbResult, null);
            }
        }

        /// <summary>
        /// Get Report Usage
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportUsageDto> results)> GetReportUsage(object parameters)
            => await GetAsync<ReportUsageDto>(HSP_SP_GetReportUsage, parameters);

        /// <summary>
        /// Update Report Usage
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateReportUsage(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateReportUsage, parameters);

        /// <summary>
        /// Add Report Usage
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        public async Task<HSPDbResult<HSPAddReportRequestStatusRow>> AddReportUsage(object parameters)
        {
            return
                await ExecuteAsync<HSPAddReportRequestStatusRow>
                (
                    HSP_SP_AddReportUsage,
                    parameters
                );
        }

        /// <summary>
        /// Get Report ExportsStatus
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ReportExportStatusDto> results)> GetReportExportsStatus(GetReportExportsStatusRequest getReportExportsStatusReposRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();

            try
            {
                var query1 = (from oReportUsage in _dbContext.ReportUsage.Where(x => getReportExportsStatusReposRequest.ReportUsageIds.Contains(x.ReportUsageID))
                              join oUsers in _dbContext.Users on oReportUsage.UserID equals oUsers.UserId
                              where oReportUsage.UserID == getReportExportsStatusReposRequest.Userid
                              select new ReportExportStatusDto
                              {
                                  ReportUsageId = oReportUsage.ReportUsageID,
                                  Completed = oReportUsage.EndTime != null,
                                  ErrorMessage = oReportUsage.ErrorMessage
                              });

                var reports = await query1.ToListAsync();
                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                dbResult.StatusRow = statusRow;

                return (dbResult, reports);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetReportExportsStatus)}.");
                statusRow.Status = HSPDbStatus.ApiError;
                statusRow.ErrorMessage = "Unable to retrieve the reports because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }

        /// <summary>
        /// Get Report Status For 
        /// One Report UsageID
        /// </summary>
        /// <param name="ReportUsageID"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, ReportExportStatusDto result)> GetReportStatus(int reportUsageID)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            ReportExportStatusDto result = new ReportExportStatusDto();
            try
            {
                var data = await _dbContext.ReportUsage.Where(x => x.ReportUsageID == reportUsageID).FirstOrDefaultAsync();
                result.ReportUsageId = data.ReportUsageID;
                result.Status = data.Status;
                
                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                dbResult.StatusRow = statusRow;
                dbResult.StatusRow = statusRow;
            }
            catch(Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetReportStatus)}.");
                statusRow.Status = HSPDbStatus.ApiError;
                statusRow.ErrorMessage = exception.Message;
                statusRow.Success = false;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
            return (dbResult, result);
        }
        
    }
}
