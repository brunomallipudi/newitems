﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.BenefitPlans;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class BenefitPlansRepository : Repository, IBenefitPlansRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetBenefitsForPlan_Levels = "rt_GetBenefitsForPlan_Levels";
        
        #endregion Procedure Names

        #region Constructors

        public BenefitPlansRepository(IDbConnectionString connectionStrings, ILogger<BenefitPlansRepository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public BenefitPlansRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<BenefitPlansRepository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get Benefits for plans
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BenefitForPlanDto> results)> GetBenefitsForPlan_Levels(object parameters)
            => await GetAsync<BenefitForPlanDto>(HSP_SP_GetBenefitsForPlan_Levels, parameters);
    }
}
