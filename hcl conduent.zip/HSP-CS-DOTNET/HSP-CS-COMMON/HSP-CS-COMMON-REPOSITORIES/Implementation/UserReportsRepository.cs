﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.UserReports;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class UserReportsRepository : Repository, IUserReportsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetUserReports = "ee_GetUserReports";

        #endregion Procedure Names

        #region Constructors

        public UserReportsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public UserReportsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Gets User Reports.
        /// </summary>
        /// <param name="parameters">
        ///     SessionId   => HSP SessionId
        ///     Usage       => Usage
        ///     OperationalReportId => If pulling by operational report Id
        ///     UserReportId => Filter by User Report Id
        ///     GetFavoriteDefaultParameters => If it should return the favorite default parameters
        ///     GetUserReportDefaultColumns => If it should return the default columns
        ///     UserReportMapId => User Report Map Id
        ///     CategoryCode => Category Code
        ///     SubCategoryCode => Sub category code
        ///     ReportName  => Filter by report
        ///     Product     => Filter by product
        /// </param>
        /// <returns>
        /// Returns 1 or multiple User Reports
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserReportDto> results)> GetUserReports(object parameters)
            => await GetAsync<UserReportDto>(HSP_SP_GetUserReports, parameters);

        /// <summary>
        /// Get User Report
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Return only 1 report</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, UserReportDto results)> GetUserReport(object parameters)
            => await GetOneAsync<HSPSearchStatusRow, UserReportDto>(HSP_SP_GetUserReports, parameters);
    }
}
