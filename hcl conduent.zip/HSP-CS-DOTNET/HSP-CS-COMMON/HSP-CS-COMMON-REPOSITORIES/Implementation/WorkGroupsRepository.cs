﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO;
using HSP_CS_COMMON_ENTITIES.DTO.WorkGroups;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class WorkGroupsRepository : Repository, IWorkGroupsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetWorkGroups = "ee_GetWorkGroups";
        public const string HSP_SP_GetWorkGroupRequests = "ee_GetWorkGroupRequests";

        #endregion
        
        #region constructors

        public WorkGroupsRepository(IDbConnectionString connectionStrings, ILogger<WorkGroupsRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        #endregion

        /// <summary>
        /// Get a list of WorkGroups.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>A list of WorkGroups.</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<WorkGroupDto> results)> GetWorkGroups(object parameters)
        {
            return await GetAsync<WorkGroupDto>(HSP_SP_GetWorkGroups, parameters);
        }

        /// <summary>
        /// Work Group Request
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Return work group request</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<WorkGroupRequestDto> results)> GetWorkGroupRequests(object parameters)
            => await GetAsync<WorkGroupRequestDto>(HSP_SP_GetWorkGroupRequests, parameters);

    }
}