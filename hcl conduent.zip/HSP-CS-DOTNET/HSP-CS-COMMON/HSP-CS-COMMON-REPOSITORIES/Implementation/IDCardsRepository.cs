﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.IDCards;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class IDCardsRepository
        : Repository, IIDCardsRepository
    {
        #region Procedure Names

        public const string HSP_SP_AddIDCardRequest = "ee_AddIDCardRequest";
        public const string HSP_SP_GetIDCardRequests = "ee_GetIDCardRequests";
        public const string HSP_SP_UpdateIDCardRequest = "ee_UpdateIDCardRequest";
        public const string HSP_SP_GetIDCardPackages = "ee_GetIDCardPackages";

        #endregion Procedure Names

        #region Constructors

        public IDCardsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public IDCardsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of id cards
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<IDCardRequestDto> results)> GetIDCardRequests(object parameters)
            => await GetAsync<IDCardRequestDto>(HSP_SP_GetIDCardRequests, parameters);

        /// <summary>
        /// Add an ID Card Request
        /// </summary>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, AddIDCardRequestDto result)> AddIDCardRequest(object parameters)
            => await AddOneAsync<HSPStatusRow, AddIDCardRequestDto>(HSP_SP_AddIDCardRequest, parameters);

        /// <summary>
        /// Update ID Card Request
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateIDCardRequest(object parameters)
           => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateIDCardRequest, parameters);

        /// <summary>
        /// Get a list of id card packages
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<IDCardPackageDto> results)> GetIDCardPackages(object parameters)
         => await GetAsync<IDCardPackageDto>(HSP_SP_GetIDCardPackages, parameters);
    }
}