﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.UserOptions;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class UserOptionsRepository
        : Repository, IUserOptionsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GETUSEROPTION = "EE_GETUSEROPTION";
        public const string HSP_SP_SETUSEROPTION = "EE_SETUSEROPTION";

        #endregion Procedure Names

        #region Constructors

        public UserOptionsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public UserOptionsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Gets a User Option - or options - depending on the parameters.
        /// </summary>
        /// <param name="parameters">
        ///     SessionId   => HSP SessionId
        ///     ItemType    => Can be a value, or null
        ///                    If null, it returns all user options
        /// </param>
        /// <returns>
        /// Returns 1 or multiple User Options
        /// </returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<UserOptionDto> results)> GetUserOption(object parameters)
        {
            (var status, var result) =
                await GetAsync<UserOptionDto>
                (
                    HSP_SP_GETUSEROPTION,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Set User Option
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> SetUserOption(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_SETUSEROPTION,
                    parameters
                );
        }
    }
}