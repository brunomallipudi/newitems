﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.CapitationRates;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class CapitationRatesRepository
        : Repository, ICapitationRatesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetCapitationRates = "EE_GetCapitationRates";

        #endregion Procedure Names

        #region constructors

        public CapitationRatesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public CapitationRatesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion constructors

        /// <summary>
        /// Get list of CapitationRates
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<CapitationRateDto> results)> GetCapitationRates(object parameters)
            => await GetAsync<CapitationRateDto>(HSP_SP_GetCapitationRates, parameters);
    }
}