﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Find;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class FindRepository : Repository, IFindRepository
    {
        public const string HSP_SP_GETFINDCOMMANDS = "EE_GETFINDCOMMANDS";

        public const string HSP_SP_GETFINDCONTROLS = "EE_GETFINDCONTROLS";

        #region Constructors

        public FindRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public FindRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindCommandDto> results)> GetFindCommandsAsync(object parameters)
            => await GetAsync<FindCommandDto>(HSP_SP_GETFINDCOMMANDS, parameters);

        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindControlDto> results)> GetFindControlsAsync(object parameters)
                => await GetAsync<FindControlDto>(HSP_SP_GETFINDCONTROLS, parameters);
    }
}