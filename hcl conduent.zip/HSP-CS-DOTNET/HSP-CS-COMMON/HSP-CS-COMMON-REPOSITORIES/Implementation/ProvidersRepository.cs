﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Providers;
using HSP_CS_COMMON_REPOSITORIES.Implementation;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    /// <summary>
    /// Providers Repository
    /// </summary>
    public class ProvidersRepository
        : Repository,
        IProvidersRepository
    {
        #region Procedure Names

        public const string HSP_SP_FINDPROVIDERS_ONLY = "EE_FINDPROVIDERS_ONLY";
        public const string HSP_SP_FINDPROVIDERS_WITHOFFICES = "EE_FINDPROVIDERS_WITHOFFICES";
        public const string HSP_SP_FINDPROVIDERS_WITHOFFICESANDCONTRACTS = "EE_FINDPROVIDERS_WITHOFFICESANDCONTRACTS";
        public const string HSP_SP_GetProviderCredentials = "ee_GetProviderCredentials";
        public const string HSP_SP_GetProviderCredentials_XML = "ee_GetProviderCredentials_XML";

        #endregion Procedure Names

        #region Constructors

        public ProvidersRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public ProvidersRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Returns providers only
        /// Provides are unique here.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetProviders(object parameters)
        {
            (var status, var result) =
                await GetAsync<dynamic>
                (
                    HSP_SP_FINDPROVIDERS_ONLY,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Returns providers with offices
        /// Providers returned are not unique
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetProvidersWithOffices(object parameters)
        {
            (var status, var result) =
                await GetAsync<dynamic>
                (
                    HSP_SP_FINDPROVIDERS_WITHOFFICES,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Returns providers with offices and contracts
        /// Providers returned are not unique
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetProvidersWithOfficesAndContracts(object parameters)
        {
            (var status, var result) =
                await GetAsync<dynamic>
                (
                    HSP_SP_FINDPROVIDERS_WITHOFFICESANDCONTRACTS,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Return Provider Credentials
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ProviderCredentialDto> results)> GetProviderCredentials(object parameters)
            => await GetAsync<ProviderCredentialDto>(HSP_SP_GetProviderCredentials, parameters);

        /// <summary>
        /// Returns the provider's profile xml.
        /// </summary>
        /// <param name="parameters">Request for provider profile xml.</param>
        /// <returns>Provider's profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetProviderCredentialsXML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetProviderCredentials_XML, parameters);
    }
}