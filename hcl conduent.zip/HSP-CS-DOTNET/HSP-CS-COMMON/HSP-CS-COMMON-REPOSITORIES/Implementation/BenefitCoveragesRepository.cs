﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.BenefitCoverages;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class BenefitCoveragesRepository : Repository, IBenefitCoveragesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetBenefitCoverages = "ee_GetBenefitCoverages";       

        #endregion Procedure Names

        #region constructors

        public BenefitCoveragesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public BenefitCoveragesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion constructors

        /// <summary>
        /// Get BenefitCoverages
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BenefitCoverageDto> results)> GetBenefitCoverages(object parameters)
            => await GetAsync<BenefitCoverageDto>(HSP_SP_GetBenefitCoverages, parameters);
    }
}
