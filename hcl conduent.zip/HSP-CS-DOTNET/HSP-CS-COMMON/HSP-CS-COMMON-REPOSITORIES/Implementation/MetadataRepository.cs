﻿using Dapper;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Metadata;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Linq;
using HSP_CS_COMMON_CORE.Enums;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class MetadataRepository : Repository, IMetadataRepository
    {
        #region Constructors

        public MetadataRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public MetadataRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get Metadata from the SP.
        /// </summary>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, IEnumerable<MetadataDto> results)> GetMetadata(int sessionId, string interfaceName, bool shortName)
        {
            using (SqlConnection connection = new SqlConnection(DbConnectionString.DefaultConnectionString))
            {
                var dbResult = new HSPDbResult<HSPStatusRow>();
                SetupInfoMessageHandling(connection, dbResult);

                var spName = shortName ? $"ee_{interfaceName}" : interfaceName;
                var reader = await connection.ExecuteReaderAsync(spName, new { sessionId, Usage = "|INIT|" }, commandType: CommandType.StoredProcedure);

                // if status is not uninitialized, then there was a SQL exception
                if(dbResult.DbStatus != HSPDbStatus.Uninitialized)
                {
                    dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.ServerError }; 
                    dbResult.StatusRow.ErrorMessage = dbResult.ErrorMessage;
                    return (dbResult, Enumerable.Empty<MetadataDto>());
                }

                // try to read the status row
                if (reader.HasRows && await reader.ReadAsync() && reader.FieldCount > 0)
                {
                    int status = (int)reader.GetValue(0);
                    dbResult.StatusRow = new HSPStatusRow { Status = (HSPDbStatus)status };
                    dbResult.StatusRow.Success = dbResult.StatusRow.Status == HSPDbStatus.Normal;
                    dbResult.StatusRow.ErrorMessage = dbResult.ErrorMessage;
                }
                else
                {
                    dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.ServerError };
                    dbResult.StatusRow.ErrorMessage = dbResult.ErrorMessage;
                }

                // if not successful or no further results, nothing to read
                if (!dbResult.StatusRow.Success || !reader.NextResult())
                {
                    return (dbResult, Enumerable.Empty<MetadataDto>());
                }

                var schemaTable = reader.GetSchemaTable();

                var list = new List<MetadataDto>();
                foreach (DataRow row in schemaTable.Rows)
                {
                    var dto = new MetadataDto
                    {
                        Name = row.Field<string>("ColumnName"),
                        DataType = row.Field<Type>("DataType").FullName.Replace("System.", ""),
                        Required = !row.Field<bool>("AllowDBNull"),
                        MaxLength = row.Field<int>("ColumnSize")
                    };

                    list.Add(dto);
                }

                return (dbResult, list);
            }
        }
    }
}
