﻿using Dapper;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Find;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class FindProfilesRepository : Repository, IFindProfilesRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetFindProfileMap = "ee_GetFindProfileMap";
        public const string HSP_SP_GetFindProfilesCustomAttribute = "ee_GetFindProfilesCustomAttribute";
        public const string HSP_SP_CopyFindProfileMap = "ee_CopyFindProfileMap";
        public const string HSP_SP_GetFindProfiles = "ee_GetFindProfiles";
        public const string HSP_SP_GetFindProfileRoles = "ee_GetFindProfileRoles";
        public const string HSP_SP_SaveFindProfileRole = "ee_SaveFindProfileRole";

        #endregion Procedure Names

        #region Constructors

        public FindProfilesRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
        }

        public FindProfilesRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config)
            : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Find Profile Map.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Profile Map</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindProfileMapDto> results)> GetFindProfileMap(object parameters)
            => await GetAsync<FindProfileMapDto>(HSP_SP_GetFindProfileMap, parameters);

        /// <summary>
        /// Find Profile Custom Attribute.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Custom Attribute</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindProfileCustomAttributeDto> results)> GetFindProfilesCustomAttribute(object parameters)
            => await GetAsync<FindProfileCustomAttributeDto>(HSP_SP_GetFindProfilesCustomAttribute, parameters);

        /// <summary>
        /// Copy Profile.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Profile Copy Status</returns>
        public async Task<HSPDbResult<HSPStatusRow>> CopyFindProfileMap(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_CopyFindProfileMap,
                    parameters
                );
        }

        /// <summary>
        /// Find Profiles.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Admin and User Profiles</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, IEnumerable<FindProfileDto> userProfiles, IEnumerable<FindProfileDto> adminProfiles)> GetFindProfiles(object parameters)
        {
            var userProfiles = Enumerable.Empty<FindProfileDto>();
            var adminProfiles = Enumerable.Empty<FindProfileDto>();

            Func<SqlMapper.GridReader, Task> processor = async reader =>
            {
                userProfiles = await reader.ReadAsync<FindProfileDto>();
                adminProfiles = await reader.ReadAsync<FindProfileDto>();
            };

            var dbResult = await ExecuteAsync<HSPStatusRow>(HSP_SP_GetFindProfiles, parameters, processor);

            return (dbResult, userProfiles, adminProfiles);
        }

        /// <summary>
        /// Get Find Profile Roles
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Prifile's Roles</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FindProfileRoleDto> results)> GetFindProfileRoles(object parameters)
            => await GetAsync<FindProfileRoleDto>(HSP_SP_GetFindProfileRoles, parameters);

        /// <summary>
        /// Save Find Profile Roles
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Status of Save Profile Roles</returns>
        public async Task<HSPDbResult<HSPStatusRow>> SaveFindProfileRole(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_SaveFindProfileRole,
                    parameters
                );
        }
    }
}
