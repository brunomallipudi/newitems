﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class ManageWorkRepository: Repository, IManageWorkRepository
    {
        private readonly HSPDbContext _dbContext;
        private ILogger<ManageWorkRepository> _logger;

        #region constructors

        public ManageWorkRepository(IDbConnectionString connectionStrings,HSPDbContext dbContext, ILogger<ManageWorkRepository> logger, IConfiguration config)
            : base(connectionStrings, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        #endregion

        /// <summary>
        /// Update a work request
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateWorkRequests(int[] requestIds, DateTime? dueDate, DateTime? workDate, int? checkOutUserId, Single? Priority)
        {
            var dbResult = new HSPDbResult<HSPStatusRow>();

            try
            {
                foreach (var workRequest in _dbContext.WorkRequests.Where(x => requestIds.Contains(x.RequestID)))
                {
                    workRequest.CheckOutUserId = checkOutUserId;
                    workRequest.DateAssigned = checkOutUserId != null ? DateTime.Now : null;
                    workRequest.DateDue = dueDate != null ? dueDate.Value : workRequest.DateDue;
                    workRequest.WorkDate = workDate != null ? workDate : workRequest.WorkDate;
                    workRequest.Priority = Priority != null ? Priority : workRequest.Priority;
                }

                await _dbContext.SaveChangesAsync();

                dbResult= new HSPDbResult<HSPStatusRow>()
                {
                    ErrorMessage = "",
                    StatusRow = new HSPStatusRow
                    {
                        Status = 0,
                        Success = true,
                        ErrorMessage = "",
                        IsCached = false
                    }
                };

                return dbResult;
            }
            catch(DbUpdateException dbUpdateException)
            {
                _logger.LogError(dbUpdateException, $"Exception in {nameof(UpdateWorkRequests)}.");
                var statusRow = new HSPStatusRow();
                statusRow.Status = HSPDbStatus.ApiError;
                statusRow.ErrorMessage = "Unable to update the WorkRequest because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
            }

            return (dbResult);
        }
    }
}
