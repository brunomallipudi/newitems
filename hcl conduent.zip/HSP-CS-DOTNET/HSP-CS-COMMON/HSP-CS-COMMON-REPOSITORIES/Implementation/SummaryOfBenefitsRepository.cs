﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.SummaryOfBenefits;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class SummaryOfBenefitsRepository : Repository, ISummaryOfBenefitsRepository
    {
        #region Procedure Names

        public const string HSP_SP_TopLevelSummaryOfBenefitMap = "ee_GetTopLevelSummaryOfBenefitMap";

        #endregion Procedure Names

        #region Constructors

        public SummaryOfBenefitsRepository(IDbConnectionString connectionStrings, ILogger<SummaryOfBenefitsRepository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public SummaryOfBenefitsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<SummaryOfBenefitsRepository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        ///Get Top Level Summary Of Benefit Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, TopLevelSummaryOfBenefitMapDto results)> GetTopLevelSummaryOfBenefitMap(object parameters)
            => await GetOneAsync<HSPStatusRow, TopLevelSummaryOfBenefitMapDto>(HSP_SP_TopLevelSummaryOfBenefitMap, parameters);
    }
}
