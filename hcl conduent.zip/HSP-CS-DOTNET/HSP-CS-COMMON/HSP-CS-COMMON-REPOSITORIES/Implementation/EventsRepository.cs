﻿using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.Domain;
using HSP_CS_COMMON_ENTITIES.DTO.Events;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Request.Events;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class EventsRepository
        : Repository, IEventsRepository
    {
        private readonly HSPDbContext _dbContext;
        private readonly ILogger<EventsRepository> _logger;

        #region Procedure Names

        public const string HSP_SP_AddFileEntityMap = "ee_AddFileEntityMap";
        public const string HSP_SP_AddTransactionToFile = "ee_AddTransactionToFile";
        public const string HSP_SP_GetFileEntityMap = "ee_GetFileEntityMap";
        public const string HSP_SP_GetTimeItemsMap = "ee_GetTimeItems";
        public const string HSP_SP_AddTimeItem = "ee_AddTimeItem";
        public const string HSP_SP_UpdateTimeItem = "ee_UpdateTimeItem";
        public const string HSP_SP_MakeFileXML = "ee_MakeFile_XML";
        public const string HSP_SP_GetEventTransactions = "ee_GetFileTransactions_V2";
        public const string HSP_SP_FindContactFiles = "ee_FindContactFiles";
        public const string HSP_SP_FindContactFiles_V3 = "ee_FindContactFiles_V3";
        public const string HSP_SP_ReclassifyEvent = "ee_ReclassifyFile";
        public const string HSP_SP_VoidFile = "ee_VoidFile";
        public const string HSP_SP_UpdateEvent = "ee_UpdateFile";
        public const string HSP_SP_GetSmartRoutingInfo = "ee_GetSmartRoutingResultsXML";
        public const string HSP_SP_GetRoutingInfoForUniflow = "ee_GetRoutingInfoForUniflow";
        public const string HSP_SP_DeleteFileEntityMap = "ee_DeleteFileEntityMap";

        #endregion Procedure Names

        #region Constructors

        public EventsRepository(IDbConnectionString connectionStrings, ILogger<EventsRepository> logger, IConfiguration config, HSPDbContext dbContext) : base(connectionStrings, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public EventsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<EventsRepository> logger, IConfiguration config, HSPDbContext dbContext) : base(connectionStrings, session, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        #endregion Constructors

        /// <summary>
        /// Adds a new File Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        public async Task<HSPDbResult<HSPAddEntryStatusRow>> AddFileEntityMap(object parameters)
        {
            return
                await ExecuteAsync<HSPAddEntryStatusRow>
                (
                    HSP_SP_AddFileEntityMap,
                    parameters
                );
        }

        /// <summary>
        /// Adds a new Transaction To File
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        public async Task<(HSPDbResult<HSPStatusRow>, AddTransactionToFileDto results)> AddTransactionToFile(object parameters)
        {
            return
                await AddOneAsync<HSPStatusRow, AddTransactionToFileDto>
                (
                    HSP_SP_AddTransactionToFile,
                    parameters
                );
        }

        /// <summary>
        /// Get File Entity Map
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<FileEntityMapDto> results)> GetFileEntityMap(object parameters)
            => await GetAsync<FileEntityMapDto>(HSP_SP_GetFileEntityMap, parameters);

        /// <summary>
        /// Get Time Items
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<TimeItemDto> results)> GetTimeItems(object parameters)
            => await GetAsync<TimeItemDto>(HSP_SP_GetTimeItemsMap, parameters);

        /// <summary>
        /// Add Time Item
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>HSPDbResult<HSPAddEntryStatusRow></returns>
        public async Task<(HSPDbResult<HSPStatusRow>, AddTimeItemDto result)> AddTimeItem(object parameters)
        {
            return
                await AddOneAsync<HSPStatusRow, AddTimeItemDto>
                (
                    HSP_SP_AddTimeItem,
                    parameters
                );
        }

        /// <summary>
        /// Update Time Item
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateTimeItem(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateTimeItem, parameters);

        /// <summary>
        /// Get Event Information in XML
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>XML String</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string result)> GetEventInfo(object parameters)
           => await GetXmlAsync(HSP_SP_MakeFileXML, parameters);

        /// <summary>
        /// Get Event Transactions
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventTransactionDto> results)> GetEventTransactions(object parameters)
          => await GetAsync<EventTransactionDto>(HSP_SP_GetEventTransactions, parameters);

        /// <summary>
        /// Find Events
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventDto> results)> FindEvents(object parameters)
            => await GetAsync<EventDto>(HSP_SP_FindContactFiles, parameters);

        /// <summary>
        /// Find Contact Files.
        /// </summary>
        /// <param name="parameters">Request parameters.</param>
        /// <returns>Conatct Files</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> FindContactFilesV3(object parameters)
            => await GetAsync<dynamic>(HSP_SP_FindContactFiles_V3, parameters);

        /// <summary>
        /// Reclassify an Event
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> ReclassifyEvent(object parameters)
         => await ExecuteAsync<HSPStatusRow>(HSP_SP_ReclassifyEvent, parameters);

        /// <summary>
        /// Void Event.
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> VoidEvent(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_VoidFile,
                    parameters
                );
        }

        /// <summary>
        /// Update an Event
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateEvent(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateEvent, parameters);

        /// <summary>
        /// Get Smart Routing Info
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, SmartRoutingInfoDto result)> GetSmartRoutingInfo(object parameters)
            => await GetOneAsync<HSPStatusRow, SmartRoutingInfoDto>(HSP_SP_GetSmartRoutingInfo, parameters);

        /// <summary>
        /// Get Routing Info for Uniflow
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, RoutingInfoDto result)> GetRoutingInfoForuniflow(object parameters)
            => await GetOneAsync<HSPStatusRow, RoutingInfoDto>(HSP_SP_GetRoutingInfoForUniflow, parameters);

        /// <summary>
        /// Delete File Entity Map.
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteFileEntityMap(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_DeleteFileEntityMap, parameters);

        /// <summary>
        /// Delete Time Item.
        /// </summary>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteTimeItem(int timeItemId, int userId)
        {
            var dbResult = new HSPDbResult<HSPStatusRow>();
            var statusRow = new HSPStatusRow();

            try
            {
                var timeItem = await _dbContext.TimeItems.FirstOrDefaultAsync(ti => ti.TimeItemId == timeItemId);

                if (timeItem == null)
                {
                    statusRow.Status = HSPDbStatus.ApplicationError;
                    statusRow.ErrorMessage = "Time Item not found.";
                    dbResult.StatusRow = statusRow;
                    dbResult.ErrorMessage = statusRow.ErrorMessage;
                    return dbResult;
                }

                if (timeItem.TimeItemUserId != userId)
                {
                    statusRow.Status = HSPDbStatus.BusinessError;
                    statusRow.ErrorMessage = "You do not have permission to delete Time Items for other Users.";
                    dbResult.StatusRow = statusRow;
                    dbResult.ErrorMessage = statusRow.ErrorMessage;
                    return dbResult;
                }

                var timeItemHistory = new TimeItemHistory
                {
                    ChangedBy = userId,
                    ChangeType = "DEL",
                    ProcedureName = "DeleteTimeItem",
                    TimeItemId = timeItem.TimeItemId,
                    FileId = timeItem.FileId,
                    TimeItemUserId = timeItem.TimeItemUserId,
                    ItemDate = timeItem.ItemDate,
                    Hours = timeItem.Hours,
                    DescriptionCode = timeItem.DescriptionCode,
                    Description = timeItem.Description,
                    BillingCode = timeItem.BillingCode,
                    BillingRole = timeItem.BillingRole,
                    Reviewed = timeItem.Reviewed,
                    Billed = timeItem.Billed,
                    LastUpdatedAt = timeItem.LastUpdatedAt,
                    LastUpdatedBy = timeItem.LastUpdatedBy,
                    LocationCode = timeItem.LocationCode,
                    ContactReasonStepId = timeItem.ContactReasonStepId,
                    ItemDateStartTime = timeItem.ItemDateStartTime,
                    ItemDateEndTime = timeItem.ItemDateEndTime
                };

                await _dbContext.TimeItemsHistory.AddAsync(timeItemHistory);

                _dbContext.TimeItems.Remove(timeItem);
                await _dbContext.SaveChangesAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                dbResult.StatusRow = statusRow;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(DeleteTimeItem)}.");
                statusRow.Status = HSPDbStatus.ServerError;
                statusRow.ErrorMessage = "Unable to delete the Time Item because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
            }

            return dbResult;
        }

        /// <summary>
        /// Get the time items for a list of events.
        /// </summary>     
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<TimeItemDto> results)> GetEventsTimeItems(
            DateTime? fromDate, DateTime? toDate, int[] events, int? resultPageNumber = 1, int? resultCount = null)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();

            try
            {
                var query = from timeItem in _dbContext.TimeItems
                            join file in _dbContext.Files on timeItem.FileId equals file.FileID
                            join contactReason in _dbContext.ContactReasons on file.ReasonID equals contactReason.ReasonID
                            join category in _dbContext.ContactReasonCategories on contactReason.CategoryID equals category.CategoryID
                            join timeItemUser in _dbContext.Users on timeItem.TimeItemUserId equals timeItemUser.UserId
                            join lastUpdatedByUser in _dbContext.Users on timeItem.LastUpdatedBy equals lastUpdatedByUser.UserId
                            join individualReferenceCodes in _dbContext.ReferenceCodes
                                on new { Code = file.IndividualCode, Type = "Individual" } equals new { individualReferenceCodes.Code, individualReferenceCodes.Type }
                            join cs in _dbContext.ContactSteps on timeItem.ContactReasonStepId equals cs.ContactReasonStepID
                                into contactSteps
                            from contactStep in contactSteps.DefaultIfEmpty()
                            join bcReferenceCodes in _dbContext.ReferenceCodes
                                on new { Code = timeItem.BillingCode, Type = "BillingCode" } equals new { bcReferenceCodes.Code, bcReferenceCodes.Type }
                                into billingCodeReferenceCodes
                            from billingCodeReferenceCode in billingCodeReferenceCodes.DefaultIfEmpty()
                            join brReferenceCodes in _dbContext.ReferenceCodes
                                on new { Code = timeItem.BillingRole, Type = "BillingRole" } equals new { brReferenceCodes.Code, brReferenceCodes.Type }
                                into billingRoleReferenceCodes
                            from billingRoleReferenceCode in billingRoleReferenceCodes.DefaultIfEmpty()
                            join dcReferenceCodes in _dbContext.ReferenceCodes
                                on new { Code = timeItem.DescriptionCode, Type = "TimeItemDescriptions" } equals new { dcReferenceCodes.Code, dcReferenceCodes.Type }
                                into descriptionCodeReferenceCodes
                            from descriptionCodeReferenceCode in descriptionCodeReferenceCodes.DefaultIfEmpty()
                            join locReferenceCodes in _dbContext.ReferenceCodes
                                on new { Code = timeItem.LocationCode, Type = "TimeItemLocations" } equals new { locReferenceCodes.Code, locReferenceCodes.Type }
                                into locationReferenceCodes
                            from locationReferenceCode in locationReferenceCodes.DefaultIfEmpty()
                            join m in _dbContext.Members
                                on new { MemberId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { MemberId = m.MemberId, IndividualCode = "MEM" }
                                    into members
                            from member in members.DefaultIfEmpty()
                            join p in _dbContext.Providers
                                on new { ProviderId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { p.ProviderId, IndividualCode = "PRV" }
                                    into providers
                            from provider in providers.DefaultIfEmpty()
                            join o in _dbContext.Offices
                                on new { OfficeId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { o.OfficeId, IndividualCode = "OFF" }
                                    into offices
                            from office in offices.DefaultIfEmpty()
                            join v in _dbContext.Vendors
                                on new { VendorId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { v.VendorId, IndividualCode = "VEN" }
                                    into vendors
                            from vendor in vendors.DefaultIfEmpty()
                            join b in _dbContext.Brokers
                                on new { BrokerId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { b.BrokerId, IndividualCode = "BRK" }
                                    into brokers
                            from broker in brokers.DefaultIfEmpty()
                            join g in _dbContext.Groups
                                on new { GroupId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { g.GroupId, IndividualCode = "GRP" }
                                    into groups
                            from grp in groups.DefaultIfEmpty()
                            join i in _dbContext.Individuals
                                on new { IndividualId = file.IndividualID.Value, IndividualCode = file.IndividualCode } equals new { i.IndividualId, i.IndividualCode }
                                    into individuals
                            from individual in individuals.DefaultIfEmpty()
                            where events.Contains(file.FileID)
                                && timeItem.ItemDate >= (fromDate ?? new DateTime(2000, 1, 1))
                                && timeItem.ItemDate <= (toDate ?? new DateTime(9999, 12, 31))
                            select new TimeItemDto
                            {
                                TimeItemId = timeItem.TimeItemId,
                                TimeItemUserId = timeItem.TimeItemUserId,
                                TimeItemUserName = timeItemUser.UserName,
                                ItemDate = timeItem.ItemDate,
                                Hours = timeItem.Hours,
                                Description = timeItem.Description,
                                ItemDateStartTime = timeItem.ItemDateStartTime,
                                ItemDateEndTime = timeItem.ItemDateEndTime,
                                Reviewed = timeItem.Reviewed,
                                Billed = timeItem.Billed,
                                BillingRole = timeItem.BillingRole,
                                BillingRoleName = billingRoleReferenceCode.Name,
                                BillingCode = timeItem.BillingCode,
                                BillingCodeName = billingCodeReferenceCode.Name,
                                LocationCode = timeItem.LocationCode,
                                Location = locationReferenceCode.Name,
                                DescriptionCode = timeItem.DescriptionCode,
                                DescriptionCodeName = descriptionCodeReferenceCode.Name,
                                DescriptionCodeDescription = descriptionCodeReferenceCode.Description,
                                FileId = file.FileID,
                                FileTrackingNumber = file.TrackingNumber,
                                FileSubject = file.Subject,
                                FileIndividualId = file.IndividualID,
                                FileIndividualType = file.IndividualCode,
                                FileIndividualTypeName = individualReferenceCodes.Name,
                                FileIndividualNumber = file.IndividualNumber,
                                FileIndividualName = member != null ? $"{member.FirstName} {member.LastName}" :
                                                    broker != null ? $"{broker.FirstName} {broker.LastName}" :
                                                    provider != null ? $"{provider.FirstName} {provider.LastName}" :
                                                    office != null ? $"{office.OfficeName}" :
                                                    vendor != null ? vendor.VendorName :
                                                    grp != null ? grp.GroupName :
                                                    individual != null ? $"{individual.FirstName} {individual.LastName}" : string.Empty,
                                ContactCategoryName = category.CategoryName,
                                ReasonId = file.ReasonID,
                                ContactReasonName = contactReason.ReasonName,
                                ContactReasonStepId = timeItem.ContactReasonStepId,
                                ContactReasonStepName = contactStep.StepName,
                                LastUpdatedAt = timeItem.LastUpdatedAt,
                                LastUpdatedById = timeItem.LastUpdatedBy,
                                LastUpdatedBy = lastUpdatedByUser.FullName
                            };

                if (resultPageNumber != null && resultCount != null)
                {
                    query = query.Skip((resultPageNumber.Value - 1) * resultCount.Value)
                                 .Take(resultCount.Value);
                }

                var timeItems = await query.ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = timeItems.Count;
                statusRow.RowCount = timeItems.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, timeItems);
            }
            catch (Exception exception)
            {
                _logger.LogError($"Exception in {nameof(GetEventsTimeItems)}.", exception);
                statusRow.Status = HSPDbStatus.ServerError;
                statusRow.ErrorMessage = "Unable to retrieve the time items because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;

                return (dbResult, null);
            }
        }

        /// <summary>
        /// Get Event Search Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventSearchDto> results)> GetEventSearchResult(EventSearchRequest eventSearchRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            try
            {
                var ESResult = from dbGroupResult in (from CSI in _dbContext.ContactSteps
                                                      join CRI in _dbContext.ContactReasons on CSI.ReasonID equals CRI.ReasonID
                                                      join CRCI in _dbContext.ContactReasonCategories on CRI.CategoryID equals CRCI.CategoryID
                                                      join WGI in _dbContext.WorkGroups on CSI.WorkGroupID equals WGI.WorkGroupID
                                                      join FI in _dbContext.Files on CSI.ReasonID equals FI.ReasonID
                                                      where CRCI.CategoryName == "RX OHI Verification"
                                                      group new { FI.TrackingNumber, CSI.StepID } by new { FI.TrackingNumber } into grpResult
                                                      select new
                                                      {
                                                          TrackingNumber = grpResult.Key.TrackingNumber,
                                                          MaxStepID = grpResult.Max(x => x.StepID)
                                                      })
                               join CS in _dbContext.ContactSteps on dbGroupResult.MaxStepID equals CS.StepID
                               join CR in _dbContext.ContactReasons on CS.ReasonID equals CR.ReasonID
                               join CRC in _dbContext.ContactReasonCategories on CR.CategoryID equals CRC.CategoryID
                               join WG in _dbContext.WorkGroups on CS.WorkGroupID equals WG.WorkGroupID
                               join F in _dbContext.Files on new { CS.ReasonID, dbGroupResult.TrackingNumber } equals new { F.ReasonID, F.TrackingNumber }
                               //join MC in _dbContext.MemberCoverages on F.IndividualNumber equals MC.MemberNumber
                               join MC in _dbContext.MemberCoverages on F.IndividualID equals MC.MemberId
                               join SC in _dbContext.SubscriberContracts on MC.SubscriberContractId equals SC.SubscriberContractID
                               join M in _dbContext.Members on MC.MemberId equals M.MemberId
                               join G in _dbContext.Groups on SC.GroupId equals G.GroupId
                               join GP in _dbContext.Groups on G.ParentId equals GP.GroupId
                               join GPNew in _dbContext.Groups on GP.ParentId equals GPNew.GroupId
                               join Fb in _dbContext.Files on M.MemberId equals Fb.IndividualID
                               join R in _dbContext.ReferenceCodes on new { Code = G.LOB, Type = "LineofBusiness", SubType = "LineofBusiness" } equals new { R.Code, R.Type, R.SubType }
                               join Ge in _dbContext.ReferenceCodes on new { Code = M.Gender, Type = "Gender" } equals new { Ge.Code, Ge.Type }
                               join RC in _dbContext.ReferenceCodes on new { Code = F.StatusCode, Type = "FileStatus", SubType = "FileStatus" } equals new { RC.Code, RC.Type, RC.SubType }
                               where F.IndividualCode == "MEM"
                               select new EventSearchFilter
                               {
                                   FileID = F.FileID,
                                   FileStatus = ((F.StepID == 0 && F.StatusCode == "0") ? "Hold" : RC.Name),
                                   DateOpened = F.DateOpened,
                                   IndividualId = M.MemberId,
                                   IndividualName = M.LastName + ',' + M.FirstName,
                                   IndividualDOB = M.DateOfBirth,
                                   Gender = Ge.Name,
                                   LOB = R.Name,
                                   ClientName = GPNew.GroupName,
                                   LastName = M.LastName,
                                   FirstName = M.FirstName,
                                   TrackingNumber = F.TrackingNumber,
                                   WorkGroupName = WG.WorkGroupName,
                                   GroupName = GPNew.GroupName,
                                   MemberNumber = MC.MemberNumber
                               };
                ESResult = ESResult.Distinct();

                if (!(string.IsNullOrEmpty(eventSearchRequest.LOB)))
                {
                    ESResult = ESResult.Where(x => x.LOB.StartsWith(eventSearchRequest.LOB));
                }
                if (!(string.IsNullOrEmpty(eventSearchRequest.GroupName)))
                {
                    ESResult = ESResult.Where(x => x.GroupName == eventSearchRequest.GroupName);
                }
                if (!(string.IsNullOrEmpty(eventSearchRequest.ClientName)))
                {
                    ESResult = ESResult.Where(x => x.ClientName == eventSearchRequest.ClientName);
                }
                if (eventSearchRequest.EventID != 0 && eventSearchRequest.EventID != null)
                {
                    ESResult = ESResult.Where(x => x.FileID == eventSearchRequest.EventID);
                }
                if (!(string.IsNullOrEmpty(eventSearchRequest.TrackingNumber)))
                {
                    ESResult = ESResult.Where(x => x.TrackingNumber == eventSearchRequest.TrackingNumber);
                }
                if (eventSearchRequest.MemberId != 0 && eventSearchRequest.MemberId != null)
                {
                    ESResult = ESResult.Where(x => x.IndividualId == eventSearchRequest.MemberId);
                }
                if (!(string.IsNullOrEmpty(eventSearchRequest.LastName)))
                {
                    ESResult = ESResult.Where(x => x.LastName.Contains(eventSearchRequest.LastName));
                }
                if (!(string.IsNullOrEmpty(eventSearchRequest.FirstName)))
                {
                    ESResult = ESResult.Where(x => x.FirstName.Contains(eventSearchRequest.FirstName));
                }
                if (eventSearchRequest.DOB != null)
                {
                    ESResult = ESResult.Where(x => x.IndividualDOB == eventSearchRequest.DOB);
                }
                if (!(string.IsNullOrEmpty(eventSearchRequest.MemberNumber)))
                {
                    ESResult = ESResult.Where(x => x.MemberNumber == eventSearchRequest.MemberNumber);
                }

                if (eventSearchRequest.ResultPageNumber != null && eventSearchRequest.ResultCount != null)
                {
                    ESResult = ESResult.Skip((eventSearchRequest.ResultPageNumber.Value - 1) * eventSearchRequest.ResultCount.Value)
                                     .Take(eventSearchRequest.ResultCount.Value);
                }

                var FinalResult = await ESResult.ToListAsync();

                List<EventSearchDto> EventSearchDtos = new List<EventSearchDto>();
                foreach (var item in FinalResult)
                {
                    EventSearchDto eventSearchDto = new EventSearchDto();
                    eventSearchDto.FileID = item.FileID;
                    eventSearchDto.FileStatus = item.FileStatus;
                    eventSearchDto.DateOpened = item.DateOpened;
                    eventSearchDto.IndividualId = item.IndividualId;
                    eventSearchDto.IndividualName = item.IndividualName;
                    eventSearchDto.IndividualDOB = item.IndividualDOB;
                    eventSearchDto.Gender = item.Gender;
                    eventSearchDto.TrackingNumber = item.TrackingNumber;
                    eventSearchDto.WorkGroupName = item.WorkGroupName;
                    eventSearchDto.GroupName = item.GroupName;
                    eventSearchDto.MemberNumber = item.MemberNumber;
                    EventSearchDtos.Add(eventSearchDto);
                }

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = FinalResult.Count;
                statusRow.RowCount = FinalResult.Count;
                dbResult.StatusRow = statusRow;

                return (dbResult, EventSearchDtos);
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }

        /// <summary>
        /// Get Event Search Result
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EventSearchDBResult> results)> GetEventSearchDetailsResult(EventSearchDetailsRequest eventSearchDetailsRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();
            try
            {
                var ESResult = from dbGroupResult in (from CSI in _dbContext.ContactSteps
                                                      join CRI in _dbContext.ContactReasons on CSI.ReasonID equals CRI.ReasonID
                                                      join CRCI in _dbContext.ContactReasonCategories on CRI.CategoryID equals CRCI.CategoryID
                                                      join WGI in _dbContext.WorkGroups on CSI.WorkGroupID equals WGI.WorkGroupID
                                                      join FI in _dbContext.Files on CSI.ReasonID equals FI.ReasonID
                                                      where CRCI.CategoryName == "RX OHI Verification"
                                                      group new { FI.TrackingNumber, CSI.StepID } by new { FI.TrackingNumber } into grpResult
                                                      select new
                                                      {
                                                          TrackingNumber = grpResult.Key.TrackingNumber,
                                                          MaxStepID = grpResult.Max(x => x.StepID)
                                                      })
                               join CS in _dbContext.ContactSteps on dbGroupResult.MaxStepID equals CS.StepID
                               join CR in _dbContext.ContactReasons on CS.ReasonID equals CR.ReasonID
                               join CRC in _dbContext.ContactReasonCategories on CR.CategoryID equals CRC.CategoryID
                               join WG in _dbContext.WorkGroups on CS.WorkGroupID equals WG.WorkGroupID
                               join F in _dbContext.Files on new { CS.ReasonID, dbGroupResult.TrackingNumber } equals new { F.ReasonID, F.TrackingNumber }
                               join MC in _dbContext.MemberCoverages on F.IndividualNumber equals MC.MemberNumber
                               //join MC in _dbContext.MemberCoverages on F.IndividualID equals MC.MemberId
                               join M in _dbContext.Members on MC.MemberId equals M.MemberId
                               join MCM in _dbContext.MemberCarrierMap on new { MemberId = M.MemberId, CR.ReasonShortcut }
                                                                equals new
                                                                {
                                                                    MemberId = MCM.MemberId,
                                                                    ReasonShortcut = MCM.SupplementalType == "P" ? "MPSPV"
                                                                                                                 : MCM.SupplementalType == "1" ? "MSP1V"
                                                                                                                 : MCM.SupplementalType == "2" ? "MSP2V"
                                                                                                                 : MCM.SupplementalType == "L" || MCM.SupplementalType == "M" || MCM.SupplementalType == "N" || MCM.SupplementalType == "O" || MCM.SupplementalType == "R" || MCM.SupplementalType == "T" || MCM.SupplementalType == "3" ? "MSPSV"
                                                                                                                 : MCM.MSPType == "A" ? "MPSAV"
                                                                                                                 : MCM.MSPType == "B" ? "MSPBV"
                                                                                                                 : MCM.MSPType == "G" ? "MSPGV"
                                                                                                                 : MCM.MSPType == "C" || MCM.MSPType == "F" || MCM.MSPType == "H" ? "MSPPV"
                                                                                                                 : "CNCL"
                                                                } into tmpMCM
                               from tmpMCMFinal in tmpMCM.DefaultIfEmpty()
                               join P in _dbContext.Payers on tmpMCMFinal.PayerId equals P.PayerId into tmpPayers
                               from tmpPayersFinal in tmpPayers.DefaultIfEmpty()
                               join SC in _dbContext.SubscriberContracts on MC.SubscriberContractId equals SC.SubscriberContractID
                               join G in _dbContext.Groups on SC.GroupId equals G.GroupId
                               join GP in _dbContext.Groups on G.ParentId equals GP.GroupId
                               join GPNew in _dbContext.Groups on GP.ParentId equals GPNew.GroupId
                               //join BC in _dbContext.BenefitCoverages on M.MemberId equals BC.EntityId
                               join BC in _dbContext.BenefitCoverages on MC.MemberCoverageID equals BC.EntityId
                               join RC in _dbContext.ReferenceCodes on new { Code = G.LOB, Type = "LineofBusiness", SubType = "LineofBusiness" }
                                                                                 equals new { RC.Code, RC.Type, RC.SubType } into tmpRC
                               from tmpRCFinal in tmpRC.DefaultIfEmpty()
                               join DEM in _dbContext.DocumentEntityMap on M.MemberId equals DEM.EntityId into tmpDEM
                               from tmpDEMFinal in tmpDEM.DefaultIfEmpty()
                               join D in _dbContext.Documents on tmpDEMFinal.DocumentId equals D.DocumentId into tmpD
                               from tmpDFinal in tmpD.DefaultIfEmpty()
                               where F.FileID == eventSearchDetailsRequest.EventId
                                  && F.IndividualCode == "MEM"
                                  //&& tmpDEMFinal.EntityType == "MEM"
                                  && GP.GroupLevel == 2
                                  && GPNew.GroupLevel == 1
                                  && CRC.CategoryName == "RX OHI Verification"
                               select new EventSearchDBResult
                               {
                                   FileID = F.FileID,
                                   TrackingNumber = F.TrackingNumber,
                                   StatusCode = F.StatusCode,
                                   FileLocation = tmpDFinal.Location,
                                   DateOpened = F.DateOpened,
                                   DateClosed = F.DateClosed,
                                   LOB = tmpRCFinal.Name,
                                   ClientName = GPNew.GroupName,
                                   MemberID = M.MemberId,
                                   RowId = tmpMCMFinal.RowId,
                                   MemberName = M.LastName + "," + M.FirstName,
                                   Subscriber = tmpMCMFinal.PayerMemberNumber,
                                   SubscriberName = M.LastName + "," + M.FirstName,
                                   EffectiveDate = BC.EffectiveDate,
                                   TerminationDate = BC.ExpirationDate,
                                   OHINumber = tmpMCMFinal.PayerMemberNumber,
                                   OHIBeginDate = tmpMCMFinal.EffectiveDate,
                                   OHIEndDate = tmpMCMFinal.ExpirationDate,
                                   OHIName = tmpPayersFinal.PayerName,
                                   FileName = tmpDFinal.OriginalDocumentName,
                                   FileDescription = F.Subject,
                                   DocumentID = tmpDFinal.DocumentId.ToString(),
                                   WorkGroupName = WG.WorkGroupName,
                                   MemberNumber = MC.MemberNumber
                               };

                ESResult = ESResult.Distinct();
                var FinalResult = await ESResult.ToListAsync();

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                statusRow.TotalCount = 1;
                statusRow.RowCount = 1;
                dbResult.StatusRow = statusRow;

                return (dbResult, ESResult);
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }
    }
}
