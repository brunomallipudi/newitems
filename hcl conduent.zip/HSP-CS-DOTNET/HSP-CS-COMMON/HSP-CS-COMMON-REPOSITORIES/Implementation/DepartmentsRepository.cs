﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Departments;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class DepartmentsRepository : Repository, IDepartmentsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetDepartments = "ee_GetDepartments";

        #endregion Procedure Names

        #region Constructors

        public DepartmentsRepository(IDbConnectionString connectionStrings, ILogger<DepartmentsRepository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public DepartmentsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<DepartmentsRepository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get a list of Departments
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<DepartmentDto> results)> GetDepartments(object parameters)
            => await GetAsync<DepartmentDto>(HSP_SP_GetDepartments, parameters);
    }
}
