﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Groups;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class GroupsRepository
        : Repository, IGroupsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetGroups = "EE_GetGroups";
        public const string HSP_SP_GetGroupProfile_XML = "ee_GetGroupProfile_XML";

        #endregion Procedure Names

        #region constructors

        public GroupsRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public GroupsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion constructors

        /// <summary>
        /// Get list of groups
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<GroupDto> results)> GetGroups(object parameters)
            => await GetAsync<GroupDto>(HSP_SP_GetGroups, parameters);

        /// <summary>
        /// Returns the Group profile xml.
        /// </summary>
        /// <param name="parameters">Request for Group profile xml.</param>
        /// <returns>Group profile in Xml format as a string.</returns>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, string results)> GetGroupProfile_XML(object parameters)
            => await GetXmlAsync<HSPStatusRow>(HSP_SP_GetGroupProfile_XML, parameters);
    }
}