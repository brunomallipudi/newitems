﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.Attachments;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class AttachmentsRepository : Repository, IAttachmentsRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetAttachmentCategories = "ee_GetAttachmentCategories";        

        #endregion Procedure Names

        #region constructors

        public AttachmentsRepository(IDbConnectionString connectionStrings, ILogger<AttachmentsRepository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public AttachmentsRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<AttachmentsRepository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion constructors

        /// <summary>
        /// Get Attachment Categories
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<AttachmentDto> results)> GetAttachmentCategories(object parameters)
           => await GetAsync<AttachmentDto>(HSP_SP_GetAttachmentCategories, parameters);
    }
}
