﻿using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.FormLetters;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_REPOSITORIES.Request.FormLetters;
using System;
using Microsoft.EntityFrameworkCore;
using HSP_CS_COMMON_ENTITIES.Domain;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class FormLettersRepository : Repository, IFormLettersRepository
    {
        private readonly HSPDbContext _dbContext;
        private readonly ILogger<FormLettersRepository> _logger;

        #region Procedures

        public const string HSP_SP_GetExtractedDataDetails = "ee_GetExtractedDataDetails";
        public const string HSP_SP_GetExtractedDataDetails_ForSelection = "ee_GetExtractedDataDetails_ForSelection";
        public const string HSP_SP_GetExtractedDataBatches = "ee_GetExtractedDataBatches";
        public const string HSP_SP_GetContactStepFormLetters = "ee_GetContactStepFormLetters";
        public const string HSP_SP_UpdateFormLetter = "ee_UpdateFormLetter";
        public const string HSP_SP_UpdateExtractedDataBatch = "ee_UpdateExtractedDataBatch";
        public const string HSP_SP_DeleteFormLetter = "ee_DeleteFormLetter";
        public const string HSP_SP_AddExtractedDataMaster = "ee_AddExtractedDataMaster";
        public const string HSP_SP_AddExtractedDataDetailsToBatch = "ee_AddExtractedDataDetailToBatch";
        public const string HSP_SP_GetExtractedFormLetterBatches = "ee_GetExtractedDataBatches";

        #endregion

        #region Constructors

        public FormLettersRepository(IDbConnectionString connectionStrings, ILogger<FormLettersRepository> logger, IConfiguration config, HSPDbContext dbContext)
            : base(connectionStrings, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public FormLettersRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<FormLettersRepository> logger, IConfiguration config, HSPDbContext dbContext)
            : base(connectionStrings, session, logger, config)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        #endregion Constructors

        /// <summary>
        /// Get Letter Details.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Details</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<dynamic> results)> GetLetterDetails(object parameters)
            => await GetAsync<dynamic>(HSP_SP_GetExtractedDataDetails, parameters);

        /// <summary>
        /// Get Letter Categories.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Categories</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<LetterCategoryDto> results)> GetLetterCategories(object parameters)
            => await GetAsync<LetterCategoryDto>(HSP_SP_GetExtractedDataDetails_ForSelection, parameters);

        /// <summary>
        /// Get Letter Batches.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Batches</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<LetterBatchDto> results)> GetLetterBatches(object parameters)
            => await GetAsync<LetterBatchDto>(HSP_SP_GetExtractedDataBatches, parameters);

        /// <summary>
        /// Get Letter Contact Step Forms.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Letter Contact Step Forms</returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<ContactStepFormLetterDto> results)> GetContactStepFormLetters(object parameters)
            => await GetAsync<ContactStepFormLetterDto>(HSP_SP_GetContactStepFormLetters, parameters);

        /// <summary>
        /// Update Form Letter.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Update Form Letter</returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateFormLetter(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateFormLetter, parameters);

        /// <summary>
        /// Confirm Form Letter.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Confirm Form Letter</returns>
        public async Task<HSPDbResult<HSPStatusRow>> ConfirmFormLetterBatch(ConfirmFormLetterBatchRequest confirmFormLetterBatchRequest)
        {
            var dbResult = new HSPDbResult<HSPStatusRow>();
            var statusRow = new HSPStatusRow();
            try
            {
                var query1 = (from oExtractedDataDetails in _dbContext.ExtractedDataDetails
                              where oExtractedDataDetails.BatchId == confirmFormLetterBatchRequest.BatchId
                              select new ConfirmFormLetterBatchDto
                              {
                                  RowId = oExtractedDataDetails.RowID,
                                  OutputStatus = oExtractedDataDetails.OutputStatus
                              });
                var rowids = query1.Select(s => new { s.RowId, s.OutputStatus }).ToList();
                if (rowids != null)
                {
                    for (int i = 0; i < rowids.Count; i++)
                    {
                        var rowid = rowids[i].RowId;
                        var UpdateFormLetterRequest = new
                        {
                            SessionId = confirmFormLetterBatchRequest.SessionId,
                            RowId = rowid,
                            OutputStatus = rowids[i].OutputStatus,
                            Usage = "|ConfirmLetter|",
                            SetMailDateToConfirmDate = confirmFormLetterBatchRequest.SetMailDateToConfirmDate
                        };
                        var result3 = await UpdateFormLetter(UpdateFormLetterRequest);
                    }
                    statusRow.Status = HSPDbStatus.Normal;
                    statusRow.Success = true;
                    dbResult.StatusRow = statusRow;
                    dbResult.ErrorMessage = statusRow.ErrorMessage;
                    return dbResult;
                }
            }
            catch (Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.Success = false;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
            }
            return dbResult;
        }

        /// <summary>
        /// Update Extracted Data Batch.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Extracted Data Batch</returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateExtractedDataBatch(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_UpdateExtractedDataBatch, parameters);

        /// <summary>
        /// Delete Form Letter.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>Delete Form Letter</returns>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteFormLetter(object parameters)
            => await ExecuteAsync<HSPStatusRow>(HSP_SP_DeleteFormLetter, parameters);

        /// <summary>
        /// Add Extracted Data Master
        /// </summary>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, AddExtractedDataMasterDto result)> AddExtractedDataMaster(object parameters)
           => await AddOneAsync<HSPStatusRow, AddExtractedDataMasterDto>(HSP_SP_AddExtractedDataMaster, parameters);

        /// <summary>
        /// Add Extracted Data Details to batch
        /// </summary>
        /// <param name="parameters"></param>
        public async Task<(HSPDbResult<HSPStatusRow> statusRow, AddExtractedDataDetailToBatchDto result)> AddExtractedDataDetailToBatch(object parameters)
            => await AddOneAsync<HSPStatusRow, AddExtractedDataDetailToBatchDto>(HSP_SP_AddExtractedDataDetailsToBatch, parameters);

        /// <summary>
        /// Get Extracted FormLetter.
        /// </summary>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<GetExtractedFormLetterBatchDto> results)> GetExtractedFormLetterBatches(object parameters)
            => await GetAsync<GetExtractedFormLetterBatchDto>(HSP_SP_GetExtractedFormLetterBatches, parameters);

        /// <summary>
        /// Get Batches Status
        /// </summary>
        /// <param name="batchStatusRequest"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<BatchStatusDto> results)> GetBatchesStatus(BatchStatusRequest batchStatusRequest)
        {
            var dbResult = new HSPDbResult<HSPSearchStatusRow>();
            var statusRow = new HSPSearchStatusRow();

            try
            {
                var query = await (from oBatchUsage in _dbContext.ExtractedDataDetails
                                   join extractedatamaster in _dbContext.ExtractedDataMaster on oBatchUsage.BatchId equals extractedatamaster.BatchId

                                   where batchStatusRequest.BatchIds.Contains(oBatchUsage.BatchId.Value)
                                   group new { oBatchUsage, extractedatamaster } by new { oBatchUsage.BatchId, extractedatamaster.ErrorMessage } into resultset


                                   select new
                                   {
                                       BatchId = resultset.Key.BatchId,
                                       AmountUnfinished = resultset.Sum(d => d.oBatchUsage.OutputStatus == null && d.oBatchUsage.OutputStatus == "FLD" ? 1 : 0),
                                       ErrorMessage = resultset.Key.ErrorMessage

                                   }
                           ).ToListAsync();
                var formLetterBatchesStatuses = query.Select(b => new BatchStatusDto
                {
                    BatchId = b.BatchId.Value,
                    Completed = b.AmountUnfinished == 0,
                    ErrorMessage = b.ErrorMessage
                });

                statusRow.Status = HSPDbStatus.Normal;
                statusRow.Success = true;
                dbResult.StatusRow = statusRow;

                return (dbResult, formLetterBatchesStatuses);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetBatchesStatus)}.");
                statusRow.Status = HSPDbStatus.ApiError;
                statusRow.ErrorMessage = "Unable to retrieve the batches because an unexpected error occurred.";
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return (dbResult, null);
            }
        }

        /// <summary>
        /// Clear Confirm Date
        /// </summary>
        /// <param name="RowIds"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> ClearConfirmDate(int[] RowIds)
        {
            ExtractedDataDetails extractedDataDetails = new ExtractedDataDetails();
            var dbResult = new HSPDbResult<HSPStatusRow>();
            var statusRow = new HSPStatusRow();
            try
            {
                foreach (int row in RowIds)
                {
                  extractedDataDetails = _dbContext.ExtractedDataDetails.Where(x => x.RowID == row).FirstOrDefault();                   
                    extractedDataDetails.ConfirmDate = null;
                  
                    await _dbContext.SaveChangesAsync();
                }

               
            }
            catch(Exception ex)
            {
                statusRow.Status = HSPDbStatus.ApplicationError;
                statusRow.Success = false;
                statusRow.ErrorMessage = ex.Message;
                dbResult.StatusRow = statusRow;
                dbResult.ErrorMessage = statusRow.ErrorMessage;
                return dbResult;
            }
            statusRow.Status = HSPDbStatus.Normal;
            statusRow.Success = true;
            statusRow.ErrorMessage = "";
            dbResult.StatusRow = statusRow;
            dbResult.ErrorMessage = "";
            return dbResult;

        }
    }
}
