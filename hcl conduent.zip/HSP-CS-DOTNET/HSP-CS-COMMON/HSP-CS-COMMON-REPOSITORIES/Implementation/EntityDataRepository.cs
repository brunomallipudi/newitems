﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;
using HSP_CS_COMMON_ENTITIES.DTO.EntityData;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_REPOSITORIES.Implementation
{
    public class EntityDataRepository
        : Repository, IEntityDataRepository
    {
        #region Procedure Names

        public const string HSP_SP_GetEntityData = "EE_GetEntityData";
        public const string HSP_SP_AddEntityData = "EE_AddEntityData";
        public const string HSP_SP_DeleteEntityData = "ee_DeleteEntityData";
        public const string HSP_SP_UpdateEntityData = "ee_UpdateEntityData";

        #endregion Procedure Names

        #region Constructors

        public EntityDataRepository(IDbConnectionString connectionStrings, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, logger, config)
        {
        }

        public EntityDataRepository(IDbConnectionString connectionStrings, IHSPSession session, ILogger<Repository> logger, IConfiguration config) : base(connectionStrings, session, logger, config)
        {
        }

        #endregion Constructors

        /// <summary>
        /// Get list of Entity Data
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<(HSPDbResult<HSPSearchStatusRow> statusRow, IEnumerable<EntityDataDto> results)> GetEntityData(object parameters)
        {
            (var status, var result) =
                await GetAsync<EntityDataDto>
                (
                    HSP_SP_GetEntityData,
                    parameters
                );

            return (status, result);
        }

        /// <summary>
        /// Add Entity Data
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> AddEntityData(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_AddEntityData,
                    parameters
                );
        }

        /// <summary>
        /// Delete Entity Data
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> DeleteEntityData(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_DeleteEntityData,
                    parameters
                );
        }

        /// <summary>
        /// Update Entity Data
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> UpdateEntityData(object parameters)
        {
            return
                await ExecuteAsync<HSPStatusRow>
                (
                    HSP_SP_UpdateEntityData,
                    parameters
                );
        }
    }
}