﻿namespace HSP_CS_COMMON_CORE.Enums
{
    /// <summary>
    /// Indicates a database error, as provided by the database 
    /// when executing a stored procedure.
    /// </summary>
    /// <remarks>
    /// Found in FHIR API code.
    /// </remarks>
    public enum HSPDbStatus
    {
        /// <summary>
        /// <summary>
        /// Indicates status value was could not be retrieved. There are many reasons for this value.
        /// Please make sure the stored procedure returns a status row with status column.
        /// </summary>
        StatusValueInaccessible = -2,

        /// Indicates status value has not been retrieved from reader yet.
        /// This is the default value for DbStatus
        /// </summary>
        Uninitialized = -1,

        /// <summary>
        /// Normal
        /// </summary>
        Normal = 0,

        /// <summary>
        /// Business Error
        /// </summary>
        BusinessError = 1,

        /// <summary>
        /// Server Error
        /// </summary>
        ServerError = 2,

        /// <summary>
        /// Application Error
        /// </summary>
        ApplicationError = 3,

        /// <summary>
        /// Api Bad Request Error
        /// </summary>
        ApiBadRequestError = 4,

        /// <summary>
        /// Api Error
        /// </summary>
        ApiError = 5
    }
}