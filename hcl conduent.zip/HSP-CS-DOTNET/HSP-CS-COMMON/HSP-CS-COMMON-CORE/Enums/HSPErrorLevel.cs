﻿namespace HSP_CS_COMMON_CORE.Enums
{
    public enum HSPErrorLevel
    {
        Business = 1,
        Server,
        Application,
        Security
    }
}