﻿namespace HSP_CS_COMMON_CORE.SessionHandling.Interfaces
{
    public interface IHSPSession
    {
        int SessionId { get; }
        int UserId { get; }
    }
}