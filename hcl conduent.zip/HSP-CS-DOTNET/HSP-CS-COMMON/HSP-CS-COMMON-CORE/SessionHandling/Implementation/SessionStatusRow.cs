﻿using HSP_CS_COMMON_CORE.ResultHandling;

namespace HSP_CS_COMMON_CORE.SessionHandling.Implementation
{
    public class SessionStatusRow : HSPStatusRow
    {
        public int SessionId { get; set; }
        public int UserId { get; set; }

        public string HasOpenSessions { get; set; } = "N";

        public new bool Success
            => SessionId != 0
                ? true
                : false;
    }
}