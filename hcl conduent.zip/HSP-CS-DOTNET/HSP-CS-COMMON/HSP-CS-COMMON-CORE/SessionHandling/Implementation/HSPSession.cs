﻿using HSP_CS_COMMON_CORE.SessionHandling.Interfaces;

namespace HSP_CS_COMMON_CORE.SessionHandling.Implementation
{
    public class HSPSession : IHSPSession
    {
        public HSPSession(int sessionId, int userId)
        {
            SessionId = sessionId;
            UserId = userId;
        }

        public int SessionId { get; }
        public int UserId { get; set; }
    }
}