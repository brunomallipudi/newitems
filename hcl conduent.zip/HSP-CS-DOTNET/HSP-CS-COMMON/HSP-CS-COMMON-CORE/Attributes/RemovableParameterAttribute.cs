﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_CORE.Attributes
{
    /// <summary>
    /// Attribute used to mark a property as Removable
    /// when serializing
    /// 
    /// Used in the Repository class
    /// </summary>
    public class RemovableParameterAttribute  : Attribute
    {
    }
}
