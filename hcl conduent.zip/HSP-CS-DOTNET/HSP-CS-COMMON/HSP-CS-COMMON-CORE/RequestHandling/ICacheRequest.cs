﻿namespace HSP_CS_COMMON_CORE.RequestHandling
{
    /// <summary>
    /// CacheRequest
    ///
    /// Minimum implementation for any requests
    /// going to the Cache Service
    /// </summary>
    public interface ICacheRequest
    {
        public string KeyTag(string uniqueIdentifier);
    }
}
