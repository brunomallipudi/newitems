﻿using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;

namespace HSP_CS_COMMON_CORE.Infrastructure.Implementation
{
    public class DbConnectionString : IDbConnectionString
    {
        public string DefaultConnectionString { get; }

        public DbConnectionString(string defaultConnectionString)
        {
            DefaultConnectionString = defaultConnectionString;
        }
    }
}