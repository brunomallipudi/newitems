﻿using HSP_CS_COMMON_ENTITIES.Domain;
using Microsoft.EntityFrameworkCore;

namespace HSP_CS_COMMON_CORE.Infrastructure.Implementation
{
    public class HSPDbContext : DbContext
    {

        public HSPDbContext(DbContextOptions<HSPDbContext> options)
            : base(options)
        { }

        public DbSet<EntityData> EntityData { get; set; }
        public DbSet<FileEntityMap> FileEntityMap { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Session> Sessions { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<Permission> Permissions { get; set; }
        public DbSet<ReferenceCode> ReferenceCodes { get; set; }
        public DbSet<RoleBasedAccess> RoleBasedAccess { get; set; }
        public DbSet<DbTableId> Ids { get; set; }
        public DbSet<VersionCompatibilityMap> VersionCompatibilityMap { get; set; }
        public DbSet<ListviewSetting> ListviewSettings { get; set; }
        public DbSet<TimeItem> TimeItems { get; set; }
        public DbSet<TimeItemHistory> TimeItemsHistory { get; set; }
        public DbSet<WorkGroup> WorkGroups { get; set; }
        public DbSet<WorkGroupUserMap> WorkGroupUserMap { get; set; }
        public DbSet<WorkRequest> WorkRequests { get; set; }
        public DbSet<Broker> Brokers { get; set; }
        public DbSet<ContactReasonCategory> ContactReasonCategories { get; set; }
        public DbSet<ContactReason> ContactReasons { get; set; }
        public DbSet<ContactStep> ContactSteps { get; set; }
        public DbSet<File> Files { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Individual> Individuals { get; set; }
        public DbSet<Member> Members { get; set; }
        public DbSet<Office> Offices { get; set; }
        public DbSet<Provider> Providers { get; set; }
        public DbSet<Vendor> Vendors { get; set; }
        public DbSet<OnlineReport> OnlineReports { get; set; }
        public DbSet<UserReport> UserReports { get; set; }
        public DbSet<ReportUsage> ReportUsage { get; set; }
        public DbSet<ExtractedDataDetails> ExtractedDataDetails { get; set; }
        public DbSet<ExtractedDataMaster> ExtractedDataMaster { get; set; }
        public DbSet<MemberCoverage> MemberCoverages { get; set; }
        public DbSet<SubscriberContract> SubscriberContracts { get; set; }
        public DbSet<MemberCarrierMap> MemberCarrierMap { get; set; }
        public DbSet<Payer> Payers { get; set; }
        public DbSet<DocumentEntityMap> DocumentEntityMap { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<LanguageEntityMap> LanguageEntityMap { get; set; }
        public DbSet<BenefitCoverage> BenefitCoverages { get; set; }
        public DbSet<CustomAttribute> CustomAttributes { get; set; }
        public DbSet<EntityAttribute> EntityAttributes { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Broker>()
                        .HasKey(b => b.BrokerId);

            modelBuilder.Entity<CustomAttribute>()
                      .HasKey(ca => ca.AttributeID);

            modelBuilder.Entity<EntityData>()
                        .HasKey(ed => new { ed.EntityId, ed.EntityType, ed.SchemaType, ed.SequenceNumber });

            modelBuilder.Entity<FileEntityMap>()
                        .HasKey(fem => fem.RowId);

            modelBuilder.Entity<TimeItemHistory>()
                        .HasKey(tih => tih.HistoryTimeItemId);

            modelBuilder.Entity<TimeItemHistory>()
                        .Property(tih => tih.Hours)
                        .HasColumnType("money_t");

            modelBuilder.Entity<TimeItem>()
                        .Property(ti => ti.Hours)
                        .HasColumnType("money_t");

            modelBuilder.Entity<ContactReason>()
                        .HasKey(cr => cr.ReasonID);

            modelBuilder.Entity<ContactReasonCategory>()
                        .HasKey(crc => crc.CategoryID);

            modelBuilder.Entity<ContactStep>()
                        .HasKey(cs => cs.ContactReasonStepID);

            modelBuilder.Entity<Group>()
                        .HasKey(g => g.GroupId);

            modelBuilder.Entity<ExtractedDataDetails>()
                       .HasKey(e => e.RowID);

            modelBuilder.Entity<Individual>()
                        .HasKey(i => i.IndividualId);

            modelBuilder.Entity<Member>()
                        .HasKey(m => m.MemberId);

            modelBuilder.Entity<Office>()
                        .HasKey(o => o.OfficeId);

            modelBuilder.Entity<Provider>()
                        .HasKey(p => p.ProviderId);

            modelBuilder.Entity<ReferenceCode>()
                        .HasKey(rc => rc.ReferenceCodeID);

            modelBuilder.Entity<OnlineReport>()
                        .HasKey(or => or.ReportId);

            modelBuilder.Entity<UserReport>()
                        .HasKey(ur => ur.UserReportId);

            modelBuilder.Entity<Vendor>()
                        .HasKey(v => v.VendorId);

            modelBuilder.Entity<WorkGroup>()
                        .HasKey(wg => wg.WorkGroupID);

            modelBuilder.Entity<ReferenceCode>()
                        .HasKey(r => r.ReferenceCodeID);

            modelBuilder.Entity<WorkRequest>()
                        .HasKey(wr => wr.RequestID);

            modelBuilder.Entity<WorkGroupUserMap>()
                        .HasKey(wgum => new { wgum.WorkGroupID, wgum.UserID });

            modelBuilder.Entity<ExtractedDataMaster>()
                       .HasKey(e => e.BatchId);

            modelBuilder.Entity<MemberCarrierMap>()
                      .HasKey(mcp => mcp.RowId);

            modelBuilder.Entity<Payer>()
                      .HasKey(p => p.PayerId);

            modelBuilder.Entity<DocumentEntityMap>()
                      .HasKey(r => r.RowId);

            modelBuilder.Entity<Document>()
                      .HasKey(d => d.DocumentId);

            modelBuilder.Entity<LanguageEntityMap>()
                      .HasKey(lem => lem.LanguageEntityID);

            modelBuilder.Entity<BenefitCoverage>()
                      .HasKey(bc => bc.BenefitCoverageId);

            modelBuilder.Entity<MemberCoverage>()
                       .HasKey(mc => mc.MemberCoverageID);

            modelBuilder.Entity<SubscriberContract>()
                      .HasKey(sc => sc.SubscriberContractID);

            modelBuilder.Entity<EntityAttribute>()
            .HasKey(ea => ea.AttributeId);

            modelBuilder.Entity<CustomAttribute>()
                        .HasKey(ca => ca.AttributeID);

            modelBuilder.Entity<Transaction>()
                        .HasKey(t => t.TransactionId);
        }
    }
}
