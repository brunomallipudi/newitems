﻿using System;

namespace HSP_CS_COMMON_CORE.Infrastructure.Interfaces
{
    public interface IDbConnectionString
    {
        String DefaultConnectionString { get; }
    }
}