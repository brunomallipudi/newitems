﻿namespace HSP_CS_COMMON_CORE.ResultHandling
{
    /// <summary>
    /// AddEntry Status Row
    /// 
    /// To be used when we are creating a new entry in the database.
    /// </summary>
    public class HSPAddEntryStatusRow : HSPStatusRow
    {

        /// <summary>
        /// Holds the newly created EntityId.
        /// </summary>
        public int? EntityId { get; set; }        
    }
}