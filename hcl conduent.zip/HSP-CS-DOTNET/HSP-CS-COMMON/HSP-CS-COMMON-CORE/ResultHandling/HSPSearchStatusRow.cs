﻿namespace HSP_CS_COMMON_CORE.ResultHandling
{
    public class HSPSearchStatusRow : HSPStatusRow
    {
        public int? RowCount { get; set; }

        public int? TotalCount { get; set; }

        public int? RestrictedCount { get; set; }
    }
}