﻿using HSP_CS_COMMON_CORE.Enums;

namespace HSP_CS_COMMON_CORE.ResultHandling
{
    public class HSPResult<TStatusRow> where TStatusRow : HSPStatusRow
    {
        public HSPResult(HSPDbResult<TStatusRow> dbResult)
        {
            StatusRow = dbResult.StatusRow;
            ErrorMessage = dbResult.ErrorMessage;
        }

        public bool Success
            => DbStatus == HSPDbStatus.Normal;

        public HSPDbStatus DbStatus
            => StatusRow?.Status ?? HSPDbStatus.Uninitialized;

        public TStatusRow StatusRow { get; }

        public string ErrorMessage { get; }
            = string.Empty;
    }
}