﻿using HSP_CS_COMMON_CORE.Enums;

namespace HSP_CS_COMMON_CORE.ResultHandling
{
    public class HSPStatusRow
    {
        public HSPDbStatus Status { get; set; }
            = HSPDbStatus.Uninitialized;

        public string ErrorMessage { get; set; }
            = string.Empty;

        public bool Success { get; set; }
           = false;

        public bool IsCached { get; set; }
    }
}