﻿using HSP_CS_COMMON_CORE.Enums;

namespace HSP_CS_COMMON_CORE.ResultHandling
{
    public class HSPDbResult<TStatusRow> where TStatusRow : HSPStatusRow
    {
        public HSPDbStatus DbStatus
            => StatusRow?.Status ?? HSPDbStatus.Uninitialized;

        public TStatusRow StatusRow { get; set; }

        public string ErrorMessage { get; set; }
            = string.Empty;
    }
}