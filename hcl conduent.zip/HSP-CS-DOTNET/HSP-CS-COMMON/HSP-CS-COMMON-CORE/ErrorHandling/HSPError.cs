﻿using HSP_CS_COMMON_CORE.Enums;

namespace HSP_CS_COMMON_CORE.ErrorHandling
{
    public class HSPError
    {
        public int? Id { get; set; }
        public HSPErrorLevel Level { get; set; }
        public string Message { get; set; }
    }
}