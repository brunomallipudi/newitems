﻿using HSP_CS_COMMON_CORE.Enums;
using System;

namespace HSP_CS_COMMON_CORE.ErrorHandling
{
    public class HSPRepositoryException : Exception
    {
        public HSPDbStatus DbStatus { get; set; }

        public HSPRepositoryException(HSPDbStatus dbStatus, string message) : base(message)
        {
            DbStatus = dbStatus;
        }
    }
}