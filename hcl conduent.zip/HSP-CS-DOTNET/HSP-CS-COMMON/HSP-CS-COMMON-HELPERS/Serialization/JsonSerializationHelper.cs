﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;
using System.Xml;

namespace HSP_CS_COMMON_HELPERS.Serialization
{
    /// <summary>
    /// Helps with the conversion of objects to JSON.
    /// </summary>
    public static class JsonSerializationHelper
    {
        /// <summary>
        /// Matches and removes starting @ characters
        /// from the provided text
        /// </summary>
        /// <param name="txt"></param>
        /// <returns>
        ///     string
        /// </returns>
        private static string RemoteAtCharacter(string txt)
        {
            string pattern = @"(?<=\B)\@\w+";
            var regex = new Regex(pattern);
            Match match = regex.Match(txt);

            while (match.Success)
            {
                txt = txt.Replace(match.Value.Trim(), match.Value.Trim().Substring(1));
                match = regex.Match(txt);
            }

            return txt;
        }

        /// <summary>
        /// Gets an XML text document and converts it into JSON Object.
        /// </summary>
        /// <param name="xml">Text</param>
        /// <param name="remoteAtCharacter">
        ///     Optional parameter. If TRUE it will match and remove all starting
        ///     @ signs from the XML node attributes.
        /// </param>
        /// <returns>Object</returns>
        public static object Xml2Json(string xml, bool remoteAtCharacter = false)
        {
            if (!string.IsNullOrEmpty(xml))
            {
                var doc = new XmlDocument();
                doc.LoadXml(xml);

                var json =
                    JsonConvert.SerializeXmlNode
                    (
                        doc,
                        Newtonsoft.Json.Formatting.None,
                        true
                    );

                if (remoteAtCharacter)
                    json = RemoteAtCharacter(json);

                return JObject.Parse(json);
            }

            return null;
        }
    }
}