﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace HSP_CS_COMMON_HELPERS.Serialization
{
    /// <summary>
    /// Helps with the conversion of objects to XML
    /// </summary>
    public static class XmlSerializationHelper
    {
        /// <summary>
        /// Serialized an object to XML
        /// </summary>
        /// <param name="obj">The object to serialize</param>
        /// <returns>XML string</returns>
        public static string Json2Xml(object obj)
        {
            XmlSerializer x = new XmlSerializer(obj.GetType());
            using (StringWriter textWriter = new StringWriter())
            {
                try
                {
                    // Ensure that the root XML node does not
                    // contain any namespaces etc.
                    XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
                    ns.Add("", "");

                    x.Serialize(textWriter, obj, ns);
                    return textWriter.ToString();
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }
    }
}