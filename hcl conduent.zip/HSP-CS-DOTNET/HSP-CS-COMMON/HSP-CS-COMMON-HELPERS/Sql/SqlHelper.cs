﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace HSP_CS_COMMON_HELPERS.Sql
{
    /// <summary>
    /// Helper for parsing SQL strings.
    /// </summary>
    public static class SqlHelper
    {
        /// <summary>
        /// Parse the stored procedure name and the parameteres from a
        /// sql string.
        /// </summary>
        /// <param name="spSql">exec SP call</param>
        /// <returns>Tuple with stored procedure and parameters</returns>
        public static (string storedProcedure, IDictionary<string, string> parameters) Parse(string sql)
        {
            var parameters = new Dictionary<string, string>();

            // regex to extract the stored procedure name
            var regex = new Regex(@"(exec)?(\s)?(?<StoredProcedure>[a-z_A-Z0-9]+)");
            var match = regex.Match(sql);

            // were we able to retrive the sp name?
            if(!match.Success)
            {
                return (string.Empty, parameters);
            }

            string storedProcedure = match.Groups["StoredProcedure"].Value;

            // now we need to extrac the parameters
            // +1 to skip the space after the sp name
            string parametersSql = sql.Substring(sql.IndexOf(storedProcedure) + storedProcedure.Length + 1);

            // regex to retrieve parameters
            regex = new Regex(@"@(?<parametername>[a-zA-Z_0-9]+)\s?=\s?['{]?(?<parametervalue>[a-zA-Z_0-9|#]+)?['}]?");

            var matches = regex.Matches(parametersSql);
            foreach (Match m in matches)
            {
                parameters.Add(m.Groups["parametername"].Value, m.Groups["parametervalue"].Value);
            }

            return (storedProcedure, parameters);
        }
    }
}
