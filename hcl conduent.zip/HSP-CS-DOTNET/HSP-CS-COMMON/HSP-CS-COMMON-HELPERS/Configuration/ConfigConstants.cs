﻿namespace HSP_CS_COMMON_HELPERS.Configuration
{
    public static class ConfigProvider
    {
        public static readonly string AzureKeyVault = "AZURE_KEY_VAULT";
        public static readonly string GCPSecretManager = "GCP_SECRET_MANAGER";
        public static readonly string AWSSecretManager = "AWS_SECRET_MANAGER";
    }
}
