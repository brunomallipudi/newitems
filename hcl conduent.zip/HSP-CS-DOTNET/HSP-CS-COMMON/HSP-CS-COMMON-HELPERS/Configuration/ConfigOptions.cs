﻿using System;

namespace HSP_CS_COMMON_HELPERS.Configuration
{
    internal class ConfigOptions
    {
        public static string ConfigProvider => Environment.GetEnvironmentVariable("CONFIG_PROVIDER");
        public static string VaultUrl => Environment.GetEnvironmentVariable("AZ_KV_URL");
        public static string SecretPrefix => Environment.GetEnvironmentVariable("AZ_KV_PREFIX");
        public static string ClientId => Environment.GetEnvironmentVariable("AZ_KV_CLIENT_ID");
        public static string TenantId => Environment.GetEnvironmentVariable("AZ_KV_TENANT_ID");
        public static string ClientCertificatePath => Environment.GetEnvironmentVariable("AZ_KV_CERT");
        public static string ClientCertificatePasswd => Environment.GetEnvironmentVariable("AZ_KV_CERT_PASS");
    }
}