﻿using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Security.Cryptography.X509Certificates;

namespace HSP_CS_COMMON_HELPERS.Configuration
{
    public class ConfigHelper
    {
        /// <summary>
        /// Reads keys/secrets using secured configuration provider.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="config"></param>
        public static void AddConfig(HostBuilderContext context, IConfigurationBuilder config)
        {
            string configProvider = ConfigOptions.ConfigProvider;
            if (string.IsNullOrWhiteSpace(configProvider))
            {
                if (context.HostingEnvironment.IsDevelopment())
                {
                    // Continue with appsettings..
                    return;
                }
                throw new Exception("Config provider and related options are not found.");
            }
            if (string.Equals(configProvider, ConfigProvider.AzureKeyVault, StringComparison.OrdinalIgnoreCase))
            {
                var vaultUri = new Uri(ConfigOptions.VaultUrl);
                var vaultConfigOptions = new AzureKeyVaultConfigurationOptions()
                {
                    Manager = new PrefixKeyVaultSecretManager(ConfigOptions.SecretPrefix)
                };

                string clientCertPath = ConfigOptions.ClientCertificatePath;
                string clientCertPasswd = ConfigOptions.ClientCertificatePasswd;

                X509Certificate2 certificate = null;
                if (string.IsNullOrWhiteSpace(clientCertPasswd))
                {
                    certificate = new X509Certificate2(clientCertPath);
                }
                else
                {
                    certificate = new X509Certificate2(clientCertPath, clientCertPasswd);
                }
                ClientCertificateCredential credential = new ClientCertificateCredential(ConfigOptions.TenantId, ConfigOptions.ClientId, certificate);

                config.AddAzureKeyVault(vaultUri, credential, vaultConfigOptions);
            }
            else
            {
                throw new NotImplementedException(configProvider);
            }
        }
    }
}
