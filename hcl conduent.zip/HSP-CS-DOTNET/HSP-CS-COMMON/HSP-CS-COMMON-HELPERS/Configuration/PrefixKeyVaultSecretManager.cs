using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;

public class PrefixKeyVaultSecretManager : KeyVaultSecretManager
{
    private readonly string Prefix;

    public PrefixKeyVaultSecretManager(string prefix)
    {
        Prefix = prefix;
    }

    /// <summary>
    /// Include or exclude secrets based on the prefix input.
    /// </summary>
    /// <param name="properties"></param>
    /// <returns></returns>
    public override bool Load(SecretProperties properties)
    {
        if (!string.IsNullOrWhiteSpace(Prefix))
        {
            return properties.Name.StartsWith($"{Prefix}-");
        }
        return true;
    }

    /// <summary>
    /// Converts incoming secret name to common format. 
    /// i.e ':' seperated nested secret with '_' in place of '-'
    /// </summary>
    /// <param name="secret"></param>
    /// <returns></returns>
    public override string GetKey(KeyVaultSecret secret)
    {
        string secretName;
        if (!string.IsNullOrWhiteSpace(Prefix))
        {
            secretName = secret.Name.Substring(Prefix.Length + 1);
        }
        else
        {
            secretName = secret.Name;
        }
        return secretName.Replace("--", ConfigurationPath.KeyDelimiter).Replace('-', '_');
    }
}