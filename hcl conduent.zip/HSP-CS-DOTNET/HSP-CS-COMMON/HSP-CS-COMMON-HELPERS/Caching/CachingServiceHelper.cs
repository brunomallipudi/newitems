﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace HSP_CS_COMMON_HELPERS.Caching
{
    public static class CachingServiceHelper
    {
        private static IConfiguration Configuration { get; set;  }

        /// <summary>
        /// Adds Cache Configuration to the API.
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="services"></param>
        /// <remarks>
        /// This implementation needs to get beefed up
        /// -- Check that the redis server is available on startup, add fallback.
        /// </remarks>
        public static void AddCacheConfiguration(IConfiguration configuration, IServiceCollection services)
        {
            CachingServiceHelper.Configuration = configuration;
            var useDistributed =
                configuration
                .GetValue<bool>($"MemoryCache:UseDistributed");

            if (!useDistributed)
                services.AddMemoryCache();

            if (useDistributed)
            {
                var cacheType =
                    configuration
                    .GetValue<string>($"MemoryCache:CacheType")
                    .ToUpper();

                switch (cacheType)
                {
                    case "SQL":
                        throw new NotImplementedException();
                    case "REDIS":
                        services.AddDistributedRedisCache(option =>
                        {
                            option.Configuration = configuration.GetValue<string>($"MemoryCache:Redis:ConnectionString");
                            option.InstanceName = configuration.GetValue<string>($"MemoryCache:Redis:InstanceName");
                        });
                        break;

                    default:
                        services.AddDistributedMemoryCache();
                        break;
                }
            }
        }

        public static CacheExpiry GetExpiry(CacheExpiryOption option)
            => new CacheExpiry
            {
                SlidingExpiration = Configuration.GetValue<int>($"MemoryCache:Expiry:{Enum.GetName(option)}:SlidingExpiration"),
                AbsoluteExpiration = Configuration.GetValue<int>($"MemoryCache:Expiry:{Enum.GetName(option)}:AbsoluteExpiration")
            };

        /// <summary>
        /// Returns expiry object for a given cache tag key.
        /// </summary>
        /// <param name="cacheKeyTag"></param>
        /// <param name="expiryOption"></param>
        /// <returns></returns>
        public static CacheExpiry GetExpiry(string cacheKeyTag, CacheExpiryOption expiryOption)
        {
            var absoluteExpiration = Configuration.GetValue($"CacheExpiry:{cacheKeyTag}:AbsoluteExpiration", -1);
            if(absoluteExpiration != -1)
            {
                var slidingExpiration = Configuration.GetValue($"CacheExpiry:{cacheKeyTag}:SlidingExpiration", absoluteExpiration);
                var cacheExpiry = new CacheExpiry
                {
                    SlidingExpiration = slidingExpiration,
                    AbsoluteExpiration = absoluteExpiration
                };
                return cacheExpiry;
            } 
            else
            {
                return GetExpiry(expiryOption);
            }
        }
    }
}