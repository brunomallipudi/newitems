﻿using System;

namespace HSP_CS_COMMON_HELPERS.Caching
{
    /// <summary>
    /// CacheExpiry object
    ///
    /// Holds values for cache expiration.
    /// Applicable to
    /// -- MemoryCache
    /// -- Distributed
    /// ----- MemoryCache
    /// ----- RedisCache
    /// ----- SQLCache
    /// </summary>
    public class CacheExpiry
    {
        public CacheExpiry()
            => CheckValues();

        /// <summary>
        /// If an item gets requested within the set timespan (in seconds)
        /// it gets refreshed - until it reaches the Absolute expiration
        /// </summary>
        public int SlidingExpiration { get; set; }

        /// <summary>
        /// If an item reaches the timespan defined by the absolute expiration
        /// (in seconds) it will be marked as expired and must refresh
        /// </summary>
        public int AbsoluteExpiration { get; set; }

        public void CheckValues()
        {
            if (AbsoluteExpiration < SlidingExpiration)
                throw new Exception("Invalid Cache expiration configuration");
        }
    }
}