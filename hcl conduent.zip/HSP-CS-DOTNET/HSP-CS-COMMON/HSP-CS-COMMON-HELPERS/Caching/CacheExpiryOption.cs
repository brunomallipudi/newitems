﻿namespace HSP_CS_COMMON_HELPERS.Caching
{
    /// <summary>
    /// The names match the configuration options;
    /// see appsettings.json
    /// </summary>
    public enum CacheExpiryOption
    {
        Development = -1,
        Default = 0,
        Low = 1,
        Medium = 2,
        High = 3
    }
}