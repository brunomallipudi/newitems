﻿using HSP_CS_COMMON_ENTITIES.Domain;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HSP_CS_COMMON_ENTITIES.Infrastructure
{
    public class ActionInfo
    {
        public string ControllerName { get; set; }
        public string ActionName { get; set; }

        [JsonIgnore]
        public IEnumerable<string> Attributes { get; set; }

        public bool EnforcesHspPermissions
            => Attributes.Contains("EnforceHSPPermissions");

        [JsonIgnore]
        public bool IsMappingRequired { get; set; }

        public bool IsMappingMissing
            => EnforcesHspPermissions && IsMappingRequired;

        public Permission Permission { get; set; }
    }
}