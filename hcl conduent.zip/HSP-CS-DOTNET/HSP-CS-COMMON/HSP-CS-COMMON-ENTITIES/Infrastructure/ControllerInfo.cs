﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace HSP_CS_COMMON_ENTITIES.Infrastructure
{
    public class ControllerInfo
    {
        public string ControllerName { get; set; }

        public IEnumerable<ActionInfo> Actions { get; set; }

        public bool EnforcesHspPermissions
            => Actions.Where(x => x.EnforcesHspPermissions).Any();

        [JsonIgnore]
        public bool IsMappingRequired
            => Actions.Where(x => x.IsMappingRequired).Any();

        public bool IsMappingMissing
            => Actions.Where(x => x.IsMappingMissing).Any();
    }
}