﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class TimeItemHistory
    {
        public int HistoryTimeItemId { get; set; }
        public int ChangedBy { get; set; }
        public string ChangeType { get; set; }
        public string ProcedureName { get; set; }
        public int TimeItemId { get; set; }
        public int FileId { get; set; }
        public int TimeItemUserId { get; set; }
        public DateTime ItemDate { get; set; }
        public decimal Hours { get; set; }
        public string DescriptionCode { get; set; }
        public string Description { get; set; }
        public string BillingCode { get; set; }
        public string BillingRole { get; set; }
        public string Reviewed { get; set; }
        public string Billed { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LocationCode { get; set; }
        public int? ContactReasonStepId { get; set; }
        public DateTime? ItemDateStartTime { get; set; }
        public DateTime? ItemDateEndTime { get; set; }
    }
}
