﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class MemberCoverage
    {
        public int MemberCoverageID { get; set; }
        public int SubscriberContractId { get; set; }
        public int MemberId { get; set; }
        public string MemberNumber { get; set; }
        public string MemberNumberMatch { get; set; }
        public string PolicyNumber { get; set; }
        public string PolicyNumberMatch { get; set; }
        public string RelationshipCode { get; set; }
        public string PrimaryPolicyIndicator { get; set; }
        public int BasePlanID { get; set; }
        public DateTime? ActiveMemberSince { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? MemberToPay { get; set; }
        public string SeparateOutOfNetworkIDCard { get; set; }
        public string OverrideTierRestrictions { get; set; }
        public string OverrideRetroEnrollmentEnforcement { get; set; }
        public string LastActiveRowVersionNumber { get; set; }
    }
}
