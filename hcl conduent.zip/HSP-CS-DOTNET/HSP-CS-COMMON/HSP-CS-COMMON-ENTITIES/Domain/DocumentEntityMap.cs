﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class DocumentEntityMap
    {
        public string EntityType { get; set; }
        public int EntityId { get; set; }
        public int DocumentId { get; set; }
        public int RowId { get; set; }
    }
}
