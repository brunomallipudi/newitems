﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Role
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
        public string RoleStatus { get; set; }
        public string RoleType { get; set; }
        public string RoleSubType { get; set; }
    }
}