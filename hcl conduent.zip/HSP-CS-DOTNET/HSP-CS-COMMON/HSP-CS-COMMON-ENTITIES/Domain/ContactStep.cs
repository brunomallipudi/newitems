﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ContactStep
    {
        public int ContactReasonStepID { get; set; }
        public string StepName { get; set; }
        public int ReasonID { get; set; }
        public int WorkGroupID { get; set; }
        public int? StepID { get; set; }
    }
}
