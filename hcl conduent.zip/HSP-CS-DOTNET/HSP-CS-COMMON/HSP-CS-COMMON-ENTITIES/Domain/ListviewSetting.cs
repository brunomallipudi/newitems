﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ListviewSetting
    {
        public int ListviewSettingId { get; set; }

        public string ListviewName { get; set; }

        /// <summary>
        /// Contains the settings in json format
        /// </summary>
        [JsonIgnore]
        public string Settings { get; set; }

        /// <summary>
        /// Contains JSON
        /// </summary>
        [JsonProperty(PropertyName = "settings", ObjectCreationHandling = ObjectCreationHandling.Replace)]
        [NotMapped]
        public object SettingsForWeb
        {
            get
            {
                return JObject.Parse(Settings);
            }
            set
            {
                Settings = ((JObject) value).ToString(Formatting.None);
            }
        }           

        public DateTime LastUpdatedAt { get; set; }

        public int LastUpdatedById { get; set; }
    }
}
