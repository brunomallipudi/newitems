﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class FindControl
    {
        public int FindControlId { get; set; }
        public string FindCommand { get; set; }
        public string Name { get; set; }
        public string Label { get; set; }
        public string ControlType { get; set; }
        public string Interface { get; set; }
        public string Visible { get; set; }
        public string Required { get; set; }
        public string DefaultValue { get; set; }
        public string DataType { get; set; }
        public int MinLength { get; set; }
        public int MaxLength { get; set; }
        public ComboboxInterface ComboboxInterface { get; set; }
        public string DisplayFieldName { get; set; }
        public string DisplayIDName { get; set; }
        public string LinkTo { get; set; }
        public string LinkFrom { get; set; }
        public string FindDisplayName { get; set; }
        public string FindResultIDName { get; set; }
        public string FindResultDisplayName { get; set; }
        public string FindAllowEdit { get; set; }
        public string FindType { get; set; }
        public string Tooltip { get; set; }
        public int SortKey { get; set; }
        public string ReferenceCodeType { get; set; }
        public string ReferenceCodeSubType { get; set; }
        public string ReferenceCodeClass { get; set; }
    }
}
