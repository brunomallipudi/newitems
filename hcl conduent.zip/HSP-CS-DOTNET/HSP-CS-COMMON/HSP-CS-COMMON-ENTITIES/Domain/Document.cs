﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Document
    {
        public string Location { get; set; }
        public string OriginalDocumentName { get; set; }
        public int DocumentId { get; set; }
    }
}
