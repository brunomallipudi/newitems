﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    /// <summary>
    /// dbo.Session
    /// </summary>
    public class Session
    {
        public int SessionId { get; set; }

        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }

        public int RoleId { get; set; }

        public string ProductName { get; set; }

        public string ProductVersion { get; set; }

        public string ComputerName { get; set; }

        public string DisconnectMode { get; set; }

        public int? DisconnectedBy { get; set; }

        public string DisconnectedFrom { get; set; }

        public DateTime ConnectTime { get; set; }

        public DateTime? DisconnectTime { get; set; }

        public string Notes { get; set; }

        public int? Port { get; set; }

        /// <summary>
        /// The original implementation would populate those
        /// in the stored procedure. We do not have access to this property
        /// at this time. It will be null.
        /// 
        /// Note:
        /// Should have been a default value in the table
        /// </summary>
        public string ServerName { get; set; }

        /// <summary>
        /// The original implementation would populate those
        /// in the stored procedure. We do not have access to this property
        /// at this time. It will be null.
        /// 
        /// Note:
        /// Should have been a default value in the table
        /// </summary>
        public string ServerVersion { get; set; }

        /// <summary>
        /// The original implementation would populate those
        /// in the stored procedure. We do not have access to this property
        /// at this time. It will be null.
        /// 
        /// Note:
        /// Should have been a default value in the table
        /// </summary>
        public string DatabaseName { get; set; }

        /// <summary>
        /// The original implementation would populate those
        /// in the stored procedure. We do not have access to this property
        /// at this time. It will be null.
        /// 
        /// Note:
        /// Should have been a default value in the table
        /// </summary>
        public short SPId { get; set; }

        public int? ImpersonationUserId { get; set; }

        public int? ApplicationKeyId { get; set; }
    }
}