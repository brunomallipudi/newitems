﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ReportUsage
    {
        public int ReportUsageID { get; set; }
        public int UserID { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string ReportName { get; set; }
        public string SQL { get; set; }
        public string ProductName { get; set; }
        public string ExportType { get; set; }
        public string UseServer { get; set; }
        public int SessionId { get; set; }
        public int OnlineReportId { get; set; }
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
    }
}
