﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ReferenceCode
    {
        public int ReferenceCodeID { get; set; }
        public string ProductName { get; set; }
        public string Type { get; set; }
        public string SubType { get; set; }
        public double SortKey { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string FedNumber { get; set; }
        public string StateNumber { get; set; }
        public string AppNumber { get; set; }
        public string Class { get; set; }
        public string Visible { get; set; }
        public int? CurrentUserID { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedAt { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
    }
}
