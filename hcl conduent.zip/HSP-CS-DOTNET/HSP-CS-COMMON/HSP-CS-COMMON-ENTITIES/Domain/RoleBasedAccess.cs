﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    [Keyless]
    public class RoleBasedAccess
    {
        public int RoleId { get; set; }

        [ForeignKey("RoleId")]
        public virtual Role Role { get; set; }

        /// <summary>
        /// Nullable to support our left join.
        /// </summary>
        public int? PermissionId { get; set; }

        [ForeignKey("PermissionId")]
        public virtual Permission Permission { get; set; }

        public int? EntityId { get; set; }
    }
}