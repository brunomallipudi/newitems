﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class EntityAttribute
    {
        public int AttributeId { get; set; }
        public string AttributeValue { get; set; }
        public string EntityType { get; set; }
        public int EntityId { get; set; }
    }
}