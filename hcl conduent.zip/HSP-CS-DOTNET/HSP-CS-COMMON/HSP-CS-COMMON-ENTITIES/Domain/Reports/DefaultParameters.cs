﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace HSP_CS_COMMON_ENTITIES.Domain.Reports
{
    [XmlRoot("Root")]
    public class DefaultParameters
    {
        public List<DefaultParameter> Parameters { get; set; }
    }

    [XmlType("Parameter")]
    public class DefaultParameter
    {
        [XmlAttribute]
        public string Name { get; set; }


        [XmlAttribute]
        public string Value { get; set; }
    }
}
