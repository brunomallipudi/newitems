﻿namespace HSP_CS_COMMON_ENTITIES.Domain.Reports
{
    public class Report
    {
        public int? ReportId { get; set; }
        public string ReportType { get; set; }
        public string ReportName { get; set; }
        public string StoredProcedureName { get; set; }
        public string ReportDescription { get; set; }
        public string CategoryName { get; set; }
        public string CategoryCode { get; set; }
        public string SubCategoryName { get; set; }
        public string SubCategoryCode { get; set; }
        public string OnlineReportName { get; set; }
        public int? PermissionId { get; set; }
        public string PermissionName { get; set; }
        public string Dataset { get; set; }
        public string SystemTableName { get; set; }
        public string MultiRecordSet { get; set; }
        public string AllowColumnSelection { get; set; }
        public string ExportDocumentSource { get; set; }
        public int? UserReportId { get; set; }
        public int? OperationalReportId { get; set; }
        public string UserReportName { get; set; }
        public string SortKey { get; set; }
        public string ReportPath { get; set; }
        public string Class { get; set; }
        public string Status { get; set; }
        public string LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public string UseSQL { get; set; }
        public string ExportType { get; set; }
        public string SelectOutputFormat { get; set; }
        public string SupportEntityAccess { get; set; }
        public string EnforceEntityAccess { get; set; }
        public object DefaultParameters { get; set; }
    }
}
