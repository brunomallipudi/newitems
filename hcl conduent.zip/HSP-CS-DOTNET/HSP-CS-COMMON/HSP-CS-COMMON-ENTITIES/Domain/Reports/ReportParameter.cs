﻿namespace HSP_CS_COMMON_ENTITIES.Domain.Reports
{
    public class ReportParameter
    {
        public string CollectionName { get; set; }
        public string ParameterName { get; set; }
        public string DisplayName { get; set; }
        public string Visible { get; set; }
        public string Required { get; set; }
        public string ParameterOrder { get; set; }
        public string ParameterDataType { get; set; }
        public int? ParameterLength { get; set; }
        public string ControlType { get; set; }
        public string SearchField { get; set; }
        public ComboboxInterface ComboboxInterface { get; set; }
        public string ComboDisplayName { get; set; }
        public string ComboIdName { get; set; }
        public string FindType { get; set; }
        public string FindParameters { get; set; }
        public string DefaultValue { get; set; }
        public string ToolTip { get; set; }
    }
}
