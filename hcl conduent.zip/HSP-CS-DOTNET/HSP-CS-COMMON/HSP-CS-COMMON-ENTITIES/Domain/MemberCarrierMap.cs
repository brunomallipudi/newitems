﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class MemberCarrierMap
    {
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string Coverage { get; set; }
        public string RelationshipToSubscriber { get; set; }
        public string COBTYPE { get; set; }
        public int MemberId { get; set; }
        public int PayerId { get; set; }
        public int RowId { get; set; }
        public string PayerMemberNumber { get; set; }
        public string SupplementalType { get; set; }
        public string MSPType { get; set; }
        public string PolicyHolderLastName { get; set; }
        public string PolicyHolderFirstName { get; set; }
        public string PolicyHolderMiddleName { get; set; }
        public string PolicyHolderSSN { get; set; }
        public string PolicyHolderGender { get; set; }
        public DateTime? PolicyHolderDOB { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string PolicyHolderPhone { get; set; }
    }
}
