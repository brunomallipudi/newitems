﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ContactReason
    {
        public int ReasonID {get;set;}
        public string ReasonShortcut {get;set;}
        public string ReasonName {get;set;}
        public string Description {get;set;}
        public string Priority {get;set;}
        public string IndividualCode {get;set;}
        public string DesignatedCloserID {get;set;}
        public string AllowOverride {get;set;}
        public string DetailsRequired {get;set;}
        public string ReasonStatus {get;set;}
        public string LastUpdatedBy {get;set;}
        public DateTime LastUpdatedAt {get;set;}
        public int CategoryID {get;set;}
        public string DefaultBillingCode {get;set;}
        public string AllowTimeForClosedFileEvent {get;set;}
        public string UseReasonNameAsSubject {get;set;}
        public string ReasonClass {get;set;}
        public string ReasonSubclass {get;set;}
        public string SortKey {get;set;}
        public string EntityTransformID {get;set;}
    }
}
