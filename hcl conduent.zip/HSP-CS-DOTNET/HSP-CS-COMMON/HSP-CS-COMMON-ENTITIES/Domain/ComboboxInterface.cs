﻿using System.Collections.Generic;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ComboboxInterface
    {
        public string UriRelativePath { get; set; }
        public IDictionary<string, string> Parameters { get; set; }
    }
}
