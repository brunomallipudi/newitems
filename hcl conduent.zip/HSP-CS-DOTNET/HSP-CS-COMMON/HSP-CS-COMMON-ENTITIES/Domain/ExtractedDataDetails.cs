﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ExtractedDataDetails
    {
        public int? BatchId { get; set; }
        public int RowID { get; set; }
        public string OutputSource { get; set; }
        public string OutputStatus { get; set; }
        public string IndividualType { get; set; }
        public int? FileId { get; set; }
        public int? StepId { get; set; }
        public int? UserReportId { get; set; }
        public string CrystalTemplate { get; set; }
        public DateTime? DateCreated { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public DateTime? ConfirmDate { get; set; }
        public DateTime? MailDate { get; set; }     

    }
}
