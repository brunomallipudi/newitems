﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class LanguageEntityMap
    {
        public int EntityID { get; set; }
        public string EntityType { get; set; }
        public string Language { get; set; }
        public int LanguageEntityID { get; set; }
        public string LanguageUse { get; set; }
    }
}
