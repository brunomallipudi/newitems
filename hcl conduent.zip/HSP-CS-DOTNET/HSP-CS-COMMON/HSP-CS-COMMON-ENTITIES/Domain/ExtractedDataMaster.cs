﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ExtractedDataMaster
    {
        public int BatchId { get; set; }
        public string Description { get; set; }
        public string CrystalTemplate { get; set; }
        public string ResultsetType { get; set; }
        public string Status { get; set; }
        public string ProductName { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public int LastUpdatedBy { get; set; }
        public string OutputType { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBy { get; set; }
        public string BatchOutputType { get; set; }
        public string ErrorMessage { get; set; }
    }
}
