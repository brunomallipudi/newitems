﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Individual
    {
        public int IndividualId { get; set; }
        public string IndividualCode { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
