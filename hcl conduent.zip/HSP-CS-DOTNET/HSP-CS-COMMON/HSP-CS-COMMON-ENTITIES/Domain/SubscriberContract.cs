﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class SubscriberContract
    {
        public int SubscriberContractID { get; set; }
        public string SubscriberPolicyNumber { get; set; }
        public int MemberId { get; set; }
        public string SubscriberMatch { get; set; }
        public int GroupId { get; set; }
        public string EmployerName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedBy { get; set; }
        public string DependentViewWebOption { get; set; }
        public DateTime? HireDate { get; set; }
        public string Volume { get; set; }
        public string LastActiveRowVersionNumber { get; set; }
    }
}
