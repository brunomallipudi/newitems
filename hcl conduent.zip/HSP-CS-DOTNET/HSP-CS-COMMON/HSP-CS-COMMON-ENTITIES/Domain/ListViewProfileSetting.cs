﻿using HSP_CS_COMMON_HELPERS.Serialization;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    /// <summary>
    /// ListView Profile Setting Class
    /// </summary>
    public class ListViewProfileSetting
    {
        public int ListviewControlId { get; set; }

        public string Interface { get; set; }

        public string InitUsage { get; set; }

        public string IsPaging { get; set; }

        /// <summary>
        /// Contains XML
        /// 
        /// We do not return this property to the client
        /// </summary>
        [JsonIgnore]
        public string Formatters { get; set; }

        /// <summary>
        /// Contains JSON
        /// </summary>
        [JsonProperty("Formatters")]
        [NotMapped]
        public object FormattersForWeb
            => JsonSerializationHelper.Xml2Json(Formatters, true);

        /// <summary>
        /// Contains XML
        /// 
        /// We do not return this property to the client
        /// </summary>
        [JsonIgnore]
        public string Settings { get; set; }

        /// <summary>
        /// Contains JSON
        /// </summary>
        [JsonProperty("Settings")]
        [NotMapped]
        public object SettingsForWeb
            => JsonSerializationHelper.Xml2Json(Settings, true);

        public int ListviewProfileSettingId { get; set; }

        public int ProfileId { get; set; }
    }
}