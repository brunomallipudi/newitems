﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class WorkRequest
    {
        public int RequestID { get; set; }
        public DateTime DateRequested { get; set; }
        public int? CheckOutUserId { get; set; }
        public int WorkGroupID { get; set; }
        public int? UserId { get; set; }
        public int EntityID { get; set; }
        public string EntityType { get; set; }
        public DateTime DateDue { get; set; }
        public DateTime? DateAssigned { get; set; }
        public DateTime? WorkDate { get; set; }
        public Single? Priority { get; set; }
    }
}
