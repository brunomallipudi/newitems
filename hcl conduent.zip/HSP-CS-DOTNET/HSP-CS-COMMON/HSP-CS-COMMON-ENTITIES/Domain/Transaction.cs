﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Transaction
    {
        public int FileID { get; set; }
        public int TransactionId { get; set; }
        public int? DocumentId { get; set; }
    }
}
