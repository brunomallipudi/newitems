﻿using HSP_CS_COMMON_HELPERS.Serialization;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class UserListViewSetting
    {
        /// <summary>
        /// Contains XML
        /// 
        /// We do not return this property to the client
        /// </summary>
        [JsonIgnore]
        public string ColumnSettings { get; set; }

        /// <summary>
        /// Contains JSON
        /// </summary>
        [JsonProperty("ColumnSettings")]
        [NotMapped]
        public object ColumnSettingsForWeb
            => JsonSerializationHelper.Xml2Json(ColumnSettings, true);
    }
}
