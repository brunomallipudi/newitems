﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class UserReport
    {
        public int UserReportId { get; set; }
        public int OperationalReportId { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public string ReportDescription { get; set; }
        public string DefaultParameters { get; set; }
        public string Class { get; set; }
        public int? PermissionId { get; set; }
        public string CategoryCode { get; set; }
        public string SubCategoryCode { get; set; }
        public string SortKey { get; set; }
        public string ExportType { get; set; }
        public string Status { get; set; }
        public string EnforceEntityAccess { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedBy { get; set; }
        public string ReportType { get; set; }
    }
}
