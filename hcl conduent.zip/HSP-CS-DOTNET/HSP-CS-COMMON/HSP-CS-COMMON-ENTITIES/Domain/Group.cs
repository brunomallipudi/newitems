﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Group
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string LOB { get; set; }
        public string GroupNumber { get; set; }
        public int GroupLevel { get; set; }
        public int ParentId { get; set; }
    }
}
