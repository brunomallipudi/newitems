﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Office
    {
        public int OfficeId { get; set; }
        public string OfficeName { get; set; }
    }
}
