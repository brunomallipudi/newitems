﻿
namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class CustomAttribute
    {
        public int AttributeID { get; set; }
        public string AttributeName { get; set; }
        public string Category { get; set; }        
    }
}
