﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    /// <summary>
    /// dbo.Ids Row
    /// </summary>
    public class DbTableId
    {

        /// <summary>
        /// Used to identify a table type
        /// Example: dbo.Sessions => "SESSION"
        /// </summary>
        [Key]
        public string IdType { get; set; }

        /// <summary>
        /// Current Increment
        /// </summary>
        public int IdValueCurr { get; set; }

        /// <summary>
        /// Max value allowed in the cokumn
        /// </summary>
        public int IdValueMax { get; set; }

        public DateTime LastUpdatedAt { get; set; }

        /// <summary>
        /// TBD
        /// </summary>
        public string IdWrapAllowed { get; set; }

        /// <summary>
        /// TBD
        /// </summary>
        public string Filler { get; set; }

        

        
    }
}