﻿namespace HSP_CS_COMMON_ENTITIES.Domain.Events.DataDrivenRouting
{
	public class IndividualInfo
	{
		public int AdditionalEntityID { get; set; }

		public string AdditionalEntityType { get; set; }

		public int AdditionalSupplementalID { get; set; }
	}
}
