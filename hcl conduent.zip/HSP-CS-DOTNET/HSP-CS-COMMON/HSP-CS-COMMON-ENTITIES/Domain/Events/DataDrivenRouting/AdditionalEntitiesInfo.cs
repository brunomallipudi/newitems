﻿using System.Collections.Generic;

namespace HSP_CS_COMMON_ENTITIES.Domain.Events.DataDrivenRouting
{
	public class AdditionalEntitiesInfo
	{
		public List<IndividualInfo> AdditionalEntityInfo { get; set; }
	}
}
