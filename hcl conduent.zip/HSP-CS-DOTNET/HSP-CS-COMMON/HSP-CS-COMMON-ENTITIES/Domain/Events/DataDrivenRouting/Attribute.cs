﻿using System.Xml.Serialization;

namespace HSP_CS_COMMON_ENTITIES.Domain.Events.DataDrivenRouting
{
	public class Attribute
	{
		[XmlAttribute]
		public int AttributeId { get; set; }

		public string AttributeName { get; set; }

		public string AttributeValue { get; set; }
	}
}
