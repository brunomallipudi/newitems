﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace HSP_CS_COMMON_ENTITIES.Domain.Events.DataDrivenRouting
{
    [XmlRoot(ElementName = "CustomAttributes")]
    public class CustomAttributesInfo
    {
        public List<Attribute> CustomAttributes { get; set; }
    }
}
