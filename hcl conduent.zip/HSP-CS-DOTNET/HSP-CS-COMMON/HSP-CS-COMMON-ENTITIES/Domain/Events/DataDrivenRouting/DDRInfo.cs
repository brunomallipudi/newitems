﻿namespace HSP_CS_COMMON_ENTITIES.Domain.Events.DataDrivenRouting
{
    public class DDRInfo
    {
        public string CallingForm { get; set; }
        public string FileID { get; set; }
        public int ReasonID { get; set; }
        public int EntityTransformID { get; set; }
        public string IndividualCode { get; set; }
        public string IndividualID { get; set; }
        public string SupplementalID { get; set; }
        public string ContactorType { get; set; }
        public string CallBackCode { get; set; }
        public string CallBackNumber { get; set; }
        public string ContactorName { get; set; }
        public string SourceCode { get; set; }
        public CustomAttributesInfo CustomAttributes { get; set; }
        public AdditionalEntitiesInfo AdditionalEntities { get; set; }
    }
}
