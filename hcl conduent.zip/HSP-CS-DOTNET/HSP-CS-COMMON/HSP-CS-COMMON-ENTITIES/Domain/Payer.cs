﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Payer
    {
        public int PayerId { get; set; }
        public string PayerName { get; set; }
        public string PayerNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string CellPhone { get; set; }
        public string FaxPhone { get; set; }
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string WorkPhoneExt { get; set; }
    }
}
