﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Broker
    {
        public int BrokerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
