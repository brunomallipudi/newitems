﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Vendor
    {
        public int VendorId { get; set; }
        public string VendorName { get; set; }
    }
}
