﻿using System.Collections.Generic;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class User
    {
        public int UserId { get; set; }
        
        public string UserName { get; set; }

        public string FullName { get; set; }

        public virtual ICollection<Session> Sessions { get; set; }
        
        public virtual ICollection<Role> Roles { get; set; }
    }
}