﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class BenefitCoverage
    {
        public int BenefitCoverageId { get; set; }
        public int EntityId { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string CoverageEntityType { get; set; }
        public int EntityTypeId { get; set; }
    }
}
