﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class EntityData
    {
        public string EntityType { get; set; }
        public int EntityId { get; set; }
        public int SequenceNumber { get; set; }
        public string SchemaType { get; set; }
        public string DataString { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string ScreenName { get; set; }
        public int? NotesCategoryId { get; set; }
    }
}
