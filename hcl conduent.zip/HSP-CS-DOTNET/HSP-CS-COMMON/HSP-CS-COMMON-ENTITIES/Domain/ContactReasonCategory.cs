﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class ContactReasonCategory
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string CategoryClass { get; set; }
        public string CategorySubclass { get; set; }
        public string SortKey { get; set; }
        public string ContactReasonCategoryType { get; set; }
    }
}
