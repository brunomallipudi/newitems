﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class FileEntityMap
    {
        public int? RowId { get; set; }
        public int FileId { get; set; }
        public string EntityType { get; set; }
        public int EntityId { get; set; }
        public string Active { get; set; }
    }
}
