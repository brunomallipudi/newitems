﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class WorkGroup
    {
        public int WorkGroupID { get; set; }
        public string WorkGroupName { get; set; }
        public string WorkgroupType { get; set; }
        public string WorkgroupSubType { get; set; }
    }
}
