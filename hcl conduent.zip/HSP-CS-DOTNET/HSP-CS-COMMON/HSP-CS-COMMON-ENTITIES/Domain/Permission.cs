﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class Permission
    {
        public int PermissionId { get; set; }
        public string PermissionName { get; set; }
        public string PermissionDescription { get; set; }
        public string EntityType { get; set; }
        public string ProductName { get; set; }
        public string Class { get; set; }
        public string SubClass { get; set; }
    }
}