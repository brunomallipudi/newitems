﻿using System;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class File
    {
        public int FileID {get;set;}
        public string TrackingNumber {get;set;}
        public int ReasonID {get;set;}
        public string SourceCode {get;set;}
        public string IndividualCode {get;set;}
        public int? IndividualID {get;set;}
        public string IndividualNumber {get;set;}
        public string StatusCode {get;set;}
        public string Subject {get;set;}
        public int OpenedByID {get;set;}
        public int? ClosedByID {get;set;}
        public int OwnerID {get;set;}
        public int? CurrentUserID {get;set;}
        public int? StepID {get;set;}
        public string CallBackCode {get;set;}
        public string CallBackNumber {get;set;}
        public string ContactorName {get;set;}
        public string ContactorType {get;set;}
        public DateTime? DateOpened {get;set;}
        public DateTime? DateClosed {get;set;}
        public string FolderType {get;set;}
        public int? ParentFileId {get;set;}
        public int? ParentStepId {get;set;}
        public string BillingCode {get;set;}
        public int? SupplementalId {get;set;}
        public string SupplementalType {get;set;}
        public DateTime? DateInitiated {get;set;}
        public int? TransactionId {get;set;}
    }
}
