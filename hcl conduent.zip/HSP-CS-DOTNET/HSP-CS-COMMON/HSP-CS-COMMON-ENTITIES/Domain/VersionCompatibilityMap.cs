﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.Domain
{
    [Keyless]
    public class VersionCompatibilityMap
    {
        public string ProductName { get; set; }
        public string AppVersion { get; set; }
        public string DbVersion { get; set; }

    }
}
