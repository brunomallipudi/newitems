﻿namespace HSP_CS_COMMON_ENTITIES.Domain
{
    public class WorkGroupUserMap
    {
        public int WorkGroupID { get; set; }
        public int UserID { get; set; }
    }
}
