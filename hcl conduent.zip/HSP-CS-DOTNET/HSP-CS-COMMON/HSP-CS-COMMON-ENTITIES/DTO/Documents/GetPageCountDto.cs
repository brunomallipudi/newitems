﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
    public class GetPageCountDto
    {
        public int PageCount { get; set; }
    }
}
