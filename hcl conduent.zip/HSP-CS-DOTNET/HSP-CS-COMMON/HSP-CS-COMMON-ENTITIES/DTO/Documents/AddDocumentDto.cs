﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
   public class AddDocumentDto
    {
        public int DocumentID { get; set; }
        public string FileName { get; set; }
    }
}
