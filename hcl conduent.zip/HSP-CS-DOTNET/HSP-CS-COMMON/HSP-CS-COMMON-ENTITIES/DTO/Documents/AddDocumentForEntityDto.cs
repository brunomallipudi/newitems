﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
    public class AddDocumentForEntityDto
    {
        public int? DocumentId { get; set; }
        public string DocumentNumber { get; set; }
        public string ImageType { get; set; }
    }
}
