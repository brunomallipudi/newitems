﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
    public  class DocumentEntityMapDto
    {
        public int RowId { get; set; }
        public int DocumentId { get; set; }
        public string EntityType { get; set; }
        public int? EntityId { get; set; }
        public int? LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string DocumentNumber { get; set; }
        public string DocumentTypeCode { get; set; }
        public string ContentType { get; set; }
        public string ContentSubType { get; set; }
        public string ImageType { get; set; }
        public DateTime? DateReceived { get; set; }
        public DateTime? DateFiled { get; set; }
        public int? FiledByID { get; set; }
        public string FiledByName { get; set; }
        public string Subject { get; set; }
        public string Description { get; set; }
        public string IndividualNumber { get; set; }
        public string IndividualCode { get; set; }
        public string ReferenceNumber { get; set; }
        public string ReferenceDate { get; set; }
        public int? TransactionID { get; set; }
        public string TranLinkCount { get; set; }
        public string OriginalDocumentName { get; set; }
        public int? InputBatchID { get; set; }
        public string AttachmentFileName { get; set; }
        public int? AttachmentCategoryId { get; set; }
        public string AttachmentCategory { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string DocumentType { get; set; }
        public string LastUpdatedByName { get; set; }
        public int? DocumentLastUpdatedBy { get; set; }
        public DateTime? DocumentLastUpdatedAt { get; set; }
        public string DocumentLastUpdatedByName { get; set; }
    }
}
