﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
    public class DownloadDocumentDto
    {
        public string FileByte { get; set; }
        public string ContentType { get; set; }        
    }
}
