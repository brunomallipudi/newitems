﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
   public class DownloadReportDto
    {
        public string FileByte { get; set; }
    }
}
