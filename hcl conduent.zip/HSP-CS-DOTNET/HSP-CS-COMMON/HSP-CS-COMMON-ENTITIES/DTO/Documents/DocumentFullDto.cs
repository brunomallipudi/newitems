﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
    public class DocumentFullDto
    {
        public int? DocumentID { get; set; }
        public string DocumentNumber { get; set; }
        public string OriginalDocumentName { get; set; }
        public string DocumentTypeCode { get; set; }
        public string ContentType { get; set; }
        public string ContentSubType { get; set; }
        public string ImageType { get; set; }
        public DateTime DateReceived { get; set; }
        public DateTime DateFiled { get; set; }
        public int FiledByID { get; set; }
        public string Subject { get; set; }
        public string Description { get; set; }
        public string IndividualNumber { get; set; }
        public string IndividualCode { get; set; }
        public string ReferenceNumber { get; set; }
        public DateTime? ReferenceDate { get; set; }
        public int? TransactionID { get; set; }
        public int? TranLinkCount { get; set; }
        public int? ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public string FiledByName { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public int? LastupdatedBy { get; set; }
        public string LastupdatedByName { get; set; }
        public string FileTrackingNumber { get; set; }
        public string FileSubject { get; set; }
        public string FileContactReason { get; set; }
        public string Location { get; set; }
    }
}
