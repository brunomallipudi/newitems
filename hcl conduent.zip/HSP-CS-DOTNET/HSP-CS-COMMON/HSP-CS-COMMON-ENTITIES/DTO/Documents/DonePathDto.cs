﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Documents
{
    public class DonePathDto
    {
        public string Path { get; set; }
    }
}
