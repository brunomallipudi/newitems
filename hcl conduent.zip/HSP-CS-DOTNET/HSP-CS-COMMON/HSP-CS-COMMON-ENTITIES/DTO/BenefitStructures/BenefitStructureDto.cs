﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.BenefitStructures
{
    public class BenefitStructureDto
    {
        public int StructureId { get; set; }
        public int? SourceId { get; set; }
        public int? PlanId { get; set; }
        public string PlanName { get; set; }
        public int? ParentId { get; set; }
        public string Type { get; set; }
        public string ProcessType { get; set; }
        public string LiabilityCounterType { get; set; }
        public string LiabilityCounterTypeName { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string BenefitCode { get; set; }
        public string RateUnitType { get; set; }
        public decimal? RateUnitValue { get; set; }
        public string BnfStructureNameWithRate { get; set; }
        public string ProcessTypeName { get; set; }
        public decimal? SortKey { get; set; }
        public int? EpisodeDays { get; set; }
        public decimal? EpisodeMaxDollars { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}