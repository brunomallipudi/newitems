﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ContactSteps
{
    /// <summary>
    /// Contact Step as it comes out from the stored procedure.
    /// </summary>

    public class ContactStepDto
    {
        public int? ReasonId { get; set; }
        public int? StepID { get; set; }
        public string StepName { get; set; }
        public int? WorkGroupID { get; set; }
        public string WorkGroupName { get; set; }
        public string Request { get; set; }
        public int? WorkDuration { get; set; }
        public string TransactionCode { get; set; }
        public string InboundOutboundProcess { get; set; }
        public string StepScript { get; set; }
        public int? XCoord { get; set; }
        public int? YCoord { get; set; }
        public string ContactStepType { get; set; }
        public int? TranFlowIdentifierId { get; set; }
        public int? DestFlowIdentifierId { get; set; }
        public string DestIndividualCode { get; set; }
        public string DelayUnitType { get; set; }
        public int? DelayUnitValue { get; set; }
        public string AllottedTimeUnitType { get; set; }
        public int? AllottedTimeUnitValue { get; set; }
        public string ContactStepClass { get; set; }
        public string ContactStepSubclass { get; set; }
        public string AllowSkipStep { get; set; }
        public string AllowOverrideStep { get; set; }
        public string DetailsRequired { get; set; }
        public string EmailOnAssignment { get; set; }
        public string RequireUserAssignment { get; set; }
        public string RequireLoggedTimeForRouting { get; set; }
        public int? ContactReasonStepId { get; set; }
        public int? RealStepId { get; set; }
        public string DefaultEmailSubject { get; set; }
        public string DefaultEmailBody { get; set; }
        public string RequireEmailBeforeRouting { get; set; }
        public int? EntityTransformID { get; set; }
        public string EntityTransformName { get; set; }
        public int? LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string PSScript { get; set; }

    }
}