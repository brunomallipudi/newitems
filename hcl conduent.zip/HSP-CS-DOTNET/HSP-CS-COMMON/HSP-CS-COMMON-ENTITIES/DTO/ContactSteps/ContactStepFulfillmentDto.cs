﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ContactStepFulfillments
{
    /// <summary>
    /// Contact Step Fulfillment as it comes out from the stored procedure.
    /// </summary>

    public class ContactStepFulfillmentDto
    {
        public int ReasonId { get; set; }
        public int StepID { get; set; }
        public int IndividualID { get; set; }
        public string IndividualType { get; set; }
        public string IndividualEmail { get; set; }
        public string IndividualFaxNumber { get; set; }
        public string IndividualContactName { get; set; }
        public string TransactionCode { get; set; }
        public string InboundOutboundProcess { get; set; }
        public string InboundOutboundProcessName { get; set; }
        public string DefaultFulfillmentType { get; set; }
        public string AutoPrint { get; set; }
        public string DefaultEmailBody { get; set; }
        public string DefaultEmailsubject { get; set; }
        public string StepName { get; set; }
        public string RequireEmailBeforeRouting { get; set; }

    }
}