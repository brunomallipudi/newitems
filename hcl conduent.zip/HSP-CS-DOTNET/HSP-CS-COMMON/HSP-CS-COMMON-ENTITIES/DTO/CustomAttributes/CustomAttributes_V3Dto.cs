﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes
{
    public class CustomAttributes_V3Dto
    {
        public int AttributeID { get; set; }
        public string AttributeName { get; set; }
        public string Category { get; set; }
        public string DataType { get; set; }
        public string DataTypeName { get; set; }
        public string ListName { get; set; }
        public string Description { get; set; }
        public string Disabled { get; set; }
        public int? MaxLength { get; set; }
        public int? MinLength { get; set; }
        public string SearchField { get; set; }
        public string EditMask { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string UseAdvancedFiltering { get; set; }
        public string IndividualCode { get; set; }
        public string EntityParentType { get; set; }
    }
}
