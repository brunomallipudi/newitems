﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes
{
    public class EntityAttributeMappingDto
    {
        public int AttributeID { get; set; }
        public string AttributeName { get; set; }
        public string Category { get; set; }
        public string DataType { get; set; }
        public string DataTypeName { get; set; }
        public string ListName { get; set; }
        public string UseAdvancedFiltering { get; set; }
        public string Disabled { get; set; }
        public int EntityAttributeMapperId { get; set; }
        public string EntityName { get; set; }
        public string CredentialType { get; set; }
        public string CredentialTypeName { get; set; }
        public string EntityParentType { get; set; }
        public string EntityParentCode { get; set; }
        public string Required { get; set; }
        public decimal SortKey { get; set; }
        public string ForeColor { get; set; }
        public string BackColor { get; set; }
        public string FontStyle { get; set; }
        public string CustomAttributesCategoryId { get; set; }
        public string CustomAttributeCategoryName { get; set; }
        public string LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string DisplayAsOfDate { get; set; }
        public string Type { get; set; }
        public string EntityType { get; set; }
        public string AttributeCategory { get; set; }
    }
}
