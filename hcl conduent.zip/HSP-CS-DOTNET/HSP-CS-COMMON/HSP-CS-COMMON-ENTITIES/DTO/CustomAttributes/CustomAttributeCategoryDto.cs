﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes
{
    /// <summary>
    /// Custom Attribute Category as returned from stored procedure.
    /// </summary>
    public class CustomAttributeCategoryDto
    {
        public int CustomAttributesCategoryID { get; set; }

        public double SortKey { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime LastUpdatedAt { get; set; }

        public int LastupdatedById { get; set; }

        public string LastupdatedBy { get; set; }
    }
}
