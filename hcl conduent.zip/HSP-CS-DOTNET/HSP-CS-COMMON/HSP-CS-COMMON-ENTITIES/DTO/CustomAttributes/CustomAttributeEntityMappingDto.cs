﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes
{
    /// <summary>
    /// Custom Attribute Entity Mapping as returned from the stored procedure.
    /// </summary>
    public class CustomAttributeEntityMappingDto
    {
        public int EntityAttributeMapperId { get; set; }

        public int AttributeID { get; set; }

        public string CustomAttributesCategoryID { get; set; }

        public string CategoryName { get; set; }
        
        public string AttributeCategory { get; set; }

        public string AttributeDataType { get; set; }
        
        public string AttributeListName { get; set; }
        
        public string AttributeName { get; set; }

        public string AttributeValue { get; set; }

        public string AttributeDescription { get; set; }
        
        public DateTime? AsOfDate { get; set; }
        
        public string Required { get; set; }
        
        public double SortKey { get; set; }

        public string ForeColor { get; set; }
        
        public string BackColor { get; set; }
       
        public string FontStyle { get; set; }
        
        public string DisplayAsOfDate { get; set; }
        
        public string MaxLength { get; set; }

        public string MinLength { get; set; }

        public string SearchField { get; set; }

        public string EditMask { get; set; }
    }
}
