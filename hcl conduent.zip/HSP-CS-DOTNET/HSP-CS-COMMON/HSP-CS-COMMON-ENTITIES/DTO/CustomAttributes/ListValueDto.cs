﻿namespace HSP_CS_COMMON_ENTITIES.DTO.CustomAttributes
{
    /// <summary>
    /// ListValue result from stored procedure
    /// </summary>
    public class ListValueDto
    {
        public string ListValue { get; set; }

        public string Description { get; set; }

        public int ListCount { get; set; }

        public double SortKey { get; set; }
    }
}
