﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.WorkRequests
{
    public class WorkRequestDetailDto
    {
        public int? RequestID { get; set; }
        public int? FileID { get; set; }
        public string TrackingNumber { get; set; }
        public int? ReasonID { get; set; }
        public string SourceCode { get; set; }
        public string IndividualCode { get; set; }
        public int? IndividualID { get; set; }
        public string IndividualNumber { get; set; }
        public string StatusCode { get; set; }
        public string Subject { get; set; }
        public int? OpenedByID { get; set; }
        public string OpenedByUserName { get; set; }
        public int? ClosedByID { get; set; }
        public string ClosedByUserName { get; set; }
        public int? OwnerID { get; set; }
        public int? CurrentUserID { get; set; }
        public int? StepID { get; set; }
        public string CallBackCode { get; set; }
        public string CallBackNumber { get; set; }
        public string ContactorName { get; set; }
        public string ContactorType { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public string FolderType { get; set; }
        public int? ParentFileId { get; set; }
        public int? ParentStepId { get; set; }
        public string BillingCode { get; set; }
        public int? SupplementalID { get; set; }
        public string SupplementalNumber { get; set; }
        public string SupplementalName { get; set; }
    }
}
