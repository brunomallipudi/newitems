﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.WorkRequests
{
    public class WorkRequestDto
    {
        public int RequestID { get; set; }
        public int? WorkGroupId { get; set; }
        public int? FileID { get; set; }
        public int? TransactionStepID { get; set; }
        public string TransactionCode { get; set; }
        public string InboundOutboundProcess { get; set; }
        public string Subject { get; set; }
        public string Request { get; set; }
        public DateTime? DateRequested { get; set; }
        public DateTime? DateDue { get; set; }
        public string TrackingNumber { get; set; }
        public string ReasonShortcut { get; set; }
        public int? ReasonID { get; set; }
        public string AllowOverrideFromReason { get; set; }
        public string DetailsRequired { get; set; }
        public string SourceCode { get; set; }
        public string IndividualCode { get; set; }
        public int? IndividualID { get; set; }
        public int? SubscriberContractId { get; set; }
        public string IndividualNumber { get; set; }
        public string IndividualName { get; set; }
        public string ContactType { get; set; }
        public string CallBackCode { get; set; }
        public string CallBackNumber { get; set; }
        public string ContactorType { get; set; }
        public string ContactorName { get; set; }
        public DateTime? DateOpened { get; set; }
        public int? OpenedByID { get; set; }
        public int? CategoryID { get; set; }
        public string EntityType { get; set; }
        public int? EntityID { get; set; }
        public string DocumentID { get; set; }
        public string DocumentNumber { get; set; }
        public DateTime? DateReceived { get; set; }
        public string OriginalDocumentName { get; set; }
        public string Location { get; set; }
        public string ImageType { get; set; }
        public int? NumberLeftOnQueue { get; set; }
        public int? CheckOutUserId { get; set; }
        public DateTime? DateAssigned { get; set; }
        public int? UserId { get; set; }
        public int? SessionId { get; set; }
        public DateTime? WorkDate { get; set; }
        public string ReasonFileOnHold { get; set; }
        public int? ParentFileId { get; set; }
        public int? ParentStepId { get; set; }
        public DateTime? ParentFileDateOpened { get; set; }
        public int? NumberOfClaims { get; set; }
        public int? ClaimId { get; set; }
        public int? LOAId { get; set; }
        public int? SupplementalID { get; set; }
        public int? GroupId { get; set; }
        public int? StepTransformID { get; set; }
        public string StepScript { get; set; }
        public string StepName { get; set; }
        public string RequireLoggedTimeForRouting { get; set; }
        public string RequireEmailBeforeRouting { get; set; }
        public string DefaultEmailBody { get; set; }
        public string FileSubject { get; set; }
    }
}
