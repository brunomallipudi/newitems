﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.WorkRequests
{
   public class GetWorkStatsDto
    {
        public int WorkGroupId { get; set; }
        public string WorkGroupName { get; set; }
        public int WorkRequestsCount { get; set; }
        public int DueWorkRequestCount { get; set; }
    }
}
