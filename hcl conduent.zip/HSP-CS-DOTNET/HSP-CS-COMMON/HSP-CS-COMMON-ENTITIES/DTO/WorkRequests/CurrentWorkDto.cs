﻿namespace HSP_CS_COMMON_ENTITIES.DTO.WorkRequests
{
    public class CurrentWorkDto
    {
        public int WorkGroupId { get; set; }
        public string WorkGroupName { get; set; }
        public int WorkRequestsCount { get; set; }
        public bool HasNewRequests { get; set; }
    }
}
