﻿using HSP_CS_COMMON_ENTITIES.Domain;

namespace HSP_CS_COMMON_ENTITIES.DTO.Permissions
{
    public class UserPermission 
        : Permission
    {
        public int UserId { get; set; }

        public bool HasPermission { get; set; }
    }
}