﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Attachments
{
    public class AttachmentDto
    {
        public int AttachmentCategoryId { get; set; }
        public string AttachmentCategoryName { get; set; }
        public string AttachmentCategoryDescription { get; set; }
        public string WebAccess { get; set; }
        public string Disabled { get; set; }
        public string AddAllowed { get; set; }
        public string EditAllowed { get; set; }
        public string DeleteAllowed { get; set; }
        public int? LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}
