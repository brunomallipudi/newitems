﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{
    public class UserReportDefaultColumnDto
    {
        public int? UserReportId { get; set; }
        public string DefaultColumns { get; set; }
    }
}