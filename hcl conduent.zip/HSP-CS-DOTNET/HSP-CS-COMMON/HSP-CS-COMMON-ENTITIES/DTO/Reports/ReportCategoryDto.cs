﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{ 
    public class ReportCategoryDto
    {
        public string CategoryName { get; set; }
        public string CategoryCode { get; set; }
        public double Sortkey { get; set; }
    }
}