﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{
    public class ReportSubCategoryDto
    {
        public string SubCategoryName { get; set; }
        public string SubCategoryCode { get; set; }
        public double Sortkey { get; set; }
    }
}