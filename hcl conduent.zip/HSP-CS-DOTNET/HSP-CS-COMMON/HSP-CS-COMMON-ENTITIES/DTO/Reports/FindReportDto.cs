﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{
    public class FindReportDto
    {
        public string CategoryName { get; set; }
        public string SubCategoryName { get; set; }
        public int? ReportId { get; set; }
        public string ReportName { get; set; }
        public string ReportTypeCode { get; set; }
        public string ReportType { get; set; }
    }
}
