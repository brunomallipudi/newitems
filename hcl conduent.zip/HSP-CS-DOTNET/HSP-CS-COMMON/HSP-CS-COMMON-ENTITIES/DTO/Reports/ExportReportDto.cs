﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{
    public class ExportReportDto
    {
        public int? ReportUsageID { get; set; }
    }
}
