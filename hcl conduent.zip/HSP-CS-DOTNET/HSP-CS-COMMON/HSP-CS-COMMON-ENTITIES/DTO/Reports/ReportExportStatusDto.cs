﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{
    public class ReportExportStatusDto
    {
        public int ReportUsageId { get; set; }
        public bool Completed { get; set; }
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
    }
}
