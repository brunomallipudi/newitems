﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Reports
{
    public class ReportUsageDto
    {
        public int? SessionID { get; set; }
        public int ReportUsageID { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string DurationTime { get; set; }
        public string ReportName { get; set; }
        public int? OnlineReportId { get; set; }
        public string SQL { get; set; }
        public string ProductName { get; set; }
        public string ExportType { get; set; }
        public string UseServer { get; set; }
    }
}
