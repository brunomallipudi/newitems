﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class UserDto
    {
		public string FullName { get; set; }
		
		public int UserId { get; set; }
		
		public int DeptId { get; set; }
		
		public int? JobTitleId { get; set; }
		
		public string EntityType { get; set; }
		
		public string EntityTypeName { get; set; }
		
		public string LastName { get; set; }
		
		public string FirstName { get; set; }
		
		public string MiddleInitial { get; set; }
		
		public string Address1 { get; set; }
		
		public string Address2 { get; set; }
		
		public string City { get; set; }
		
		public string County { get; set; }
		
		public string State { get; set; }
		
		public string Zip { get; set; }
		
		public int? ZipCodeId { get; set; }
		
		public string CountryCode { get; set; }
		
		public string CountryISOCode2 { get; set; }
		
		public string CountryISOCode3 { get; set; }
		
		public double? Latitude { get; set; }
		
		public double? Longitude { get; set; }
		
		public string HomePhone { get; set; }
		
		public string WorkgroupEmailOption { get; set; }
		
		public string WorkPhone { get; set; }
		
		public string Fax { get; set; }
		
		public string SocialSecurityNumber { get; set; }
		
		public string Username { get; set; }
		
		public string Password { get; set; }
		
		public string UserStatus { get; set; }
		
		public string Email { get; set; }
		
		public int? CustomerId { get; set; }
		
		public string CustomerName { get; set; }
		
		public string Status { get; set; }
		
		public string DefaultBillingRole { get; set; }
		
		public string RequireUserAssignment { get; set; }
		
		public string LastUpdatedBy { get; set; }
		
		public DateTime LastUpdatedAt { get; set; }
		
		public string CustomerNumber { get; set; }
		
		public string Product { get; set; }
		
		public string UserOption { get; set; }
		
		public string UseSingleSignOn { get; set; }
		
		public DateTime? LockoutAt { get; set; }
		
		public int? AssignedItems { get; set; }
		
		public int? UserPollingOptionId { get; set; }
		
		public string WorkGroupTypeCode { get; set; }
		
		public string WorkFromAnyWorkGroupCode { get; set; }
		
		public string WorkFromAnyWorkGroup { get; set; }
		
		public string PendToSameWorkGroupCode { get; set; }
		
		public string PendToSameWorkGroup { get; set; }
		
		public string SelectWorkGroupToPollFromCode { get; set; }
		
		public string SelectWorkGroupToPollFrom { get; set; }
		
		public string PollingOrderCode { get; set; }
		
		public string PollingOrder { get; set; }
		
		public string IsLogged { get; set; }

		public int? LoggedSessionId { get; set; }
	}
}
