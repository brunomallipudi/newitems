﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class OfficeDto
    {
		public int OfficeId { get; set; }

		public string OfficeNumber { get; set; }

		public string NPI { get; set; }

		public string AllowInvalidNPI { get; set; }

		public string OfficeName { get; set; }

		public string Address1 { get; set; }

		public string Address2 { get; set; }

		public string City { get; set; }

		public string PreferredCity { get; set; }

		public string State { get; set; }

		public string Zip { get; set; }

		public string OverrideDuplicateAddress { get; set; }

		public string ZipSearch { get; set; }

		public int? ZipCodeId { get; set; }

		public string CountryCode { get; set; }

		public string CountryISOCode2 { get; set; }

		public string CountryISOCode3 { get; set; }

		public double? Latitude { get; set; }

		public double? Longitude { get; set; }

		public string Region { get; set; }

		public string County { get; set; }

		public float? Distance { get; set; }

		public string ContactName { get; set; }

		public string ContactPhone { get; set; }

		public string ContactExt { get; set; }

		public string ContactEmail { get; set; }

		public string ContactFax { get; set; }

		public string WheelchairAccess { get; set; }

		public string AvailableAfterHours { get; set; }

		public string TotalOfficeHours { get; set; }

		public int? NumberOfPhysicians { get; set; }

		public string FacilityOperatingNumber { get; set; }

		public string PermanentFacilityId { get; set; }

		public string SundayStart { get; set; }

		public string SundayEnd { get; set; }

		public string MondayStart { get; set; }

		public string MondayEnd { get; set; }

		public string TuesdayStart { get; set; }

		public string TuesdayEnd { get; set; }

		public string WednesdayStart { get; set; }

		public string WednesdayEnd { get; set; }

		public string ThursdayStart { get; set; }

		public string ThursdayEnd { get; set; }

		public string FridayStart { get; set; }

		public string FridayEnd { get; set; }

		public string SaturdayStart { get; set; }

		public string SaturdayEnd { get; set; }

		public string ShowInWebDirectory { get; set; }

		public string AccessCode { get; set; }

		public int? ContractingProviderId { get; set; }

		public string ContractingProviderName { get; set; }

		public string ContractingProviderNumber { get; set; }

		public string AfterHoursContactMethod { get; set; }

		public string AfterHoursContactMethodName { get; set; }

		public DateTime LastUpdatedAt { get; set; }

		public string LastUpdatedBy { get; set; }

		public string AllowRAAccessOnWeb { get; set; }

		public string Language { get; set; }

		public string AdditionalService { get; set; }

		public string WheelchairAccessibilityLevel { get; set; }

		public string PublicTransportationAccess { get; set; }

		public string PublicTransportationLevel { get; set; }
	}
}
