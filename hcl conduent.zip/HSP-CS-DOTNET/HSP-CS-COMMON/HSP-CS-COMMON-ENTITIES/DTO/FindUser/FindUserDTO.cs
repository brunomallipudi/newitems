﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class FindUserDto
    {
        public string Username { get; set; }
        public string FullName { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public int? ZipCodeId { get; set; }
        public string CountryCode { get; set; }
        public string CountryISOCode2 { get; set; }
        public string CountryISOCode3 { get; set; }
        public double? LATITUDE { get; set; }
        public double? LONGITUDE { get; set; }
        public string HomePhone { get; set; }
        public string EMail { get; set; }
        public string WorkPhone { get; set; }
        public string Fax { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string UserStatus { get; set; }
        public string UserStatusDescription { get; set; }
        public string DeptName { get; set; }
        public string Manager { get; set; }
        public string DeptStatus { get; set; }
        public int UserID { get; set; }
        public int DeptID { get; set; }
        public string Password { get; set; }
        public string DefaultBillingRole { get; set; }
        public string DefaultBillingRoleName { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public string LastUpdatedAt { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedByName { get; set; }
        public string CreatedAt { get; set; }
        public string UseSingleSignOn { get; set; }
        public int? JobTitleID { get; set; }
        public int? WorkGroupID { get; set; }
        public string WorkGroupName { get; set; }
        public string WorkGroupType { get; set; }
        public string OwnerName { get; set; }
        public string WorkGroupStatus { get; set; }
    }
}
