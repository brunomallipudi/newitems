﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.UtilizationCounters
{
    /// <summary>
    /// UtilizationCounter results from stored procedure
    /// </summary>
    public class UtilizationCounterDto
    {
        public int LiabilityItemRowID { get; set; }
        public int LiabilityItemId { get; set; }
        public string LiabilityItemName { get; set; }
        public string LiabilityItemDescription { get; set; }
        public int LiabilityTypeId { get; set; }
        public string LiabilityTypeName { get; set; }
        public string LiabilityTypeDescription { get; set; }
        public string CarryOverType { get; set; }
        public string CarryOverTypeName { get; set; }
        public int CarryOverPeriod { get; set; }
        public string IndividualType { get; set; }
        public string UnitType { get; set; }
        public Decimal UnitValue { get; set; }
        public string PeriodType { get; set; }
        public Single PeriodValue { get; set; }
        public string PeriodTypeName { get; set; }
        public Decimal UnitsUsed { get; set; }
        public Decimal UnitsAvailable { get; set; }
        public string DateUnitsAvailable { get; set; }
        public int StepDownLiabilityItemId { get; set; }
        public string StepDownLiabilityItemName { get; set; }
        public string StepDownLiabilityTypeName { get; set; }
        public Single StepDownProcessOrder { get; set; }
        public string StepDownLimitType { get; set; }
        public string StepDownLimitTypeName { get; set; }
        public string ByTierItem { get; set; }
        public DateTime AsOfDate { get; set; }
        public DateTime PeriodStartDate { get; set; }
        public DateTime PeriodEndDate { get; set; }
        public int LiabilityTypeSourceId { get; set; }
        public int LiabilityPackageID { get; set; }
        public string LiabilityPackageName { get; set; }
    }
}
