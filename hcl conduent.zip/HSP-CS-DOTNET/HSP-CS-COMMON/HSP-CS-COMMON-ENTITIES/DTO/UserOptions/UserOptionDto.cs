﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HSP_CS_COMMON_ENTITIES.DTO.UserOptions
{
    public class UserOptionDto
    {
        [Column("UserID")]
        public int UserId { get; set; }

        public string ItemType { get; set; }

        public string ItemValue { get; set; }
    }
}