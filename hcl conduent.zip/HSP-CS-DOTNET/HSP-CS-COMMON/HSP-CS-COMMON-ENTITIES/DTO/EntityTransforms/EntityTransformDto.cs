﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.EntityTransforms
{
    public class EntityTransformDto
    {
        public int EntityTransformId { get; set; }
        public string TransformType { get; set; }
        public string TransformTypeName { get; set; }
        public string TransformName { get; set; }
        public string EntityType { get; set; }
        public string EntityTypeName { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public DateTime AsOfDate { get; set; }
        public string ElementTransform { get; set; }
        public string TestEntityXML { get; set; }
        public string OutputType { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? ResultCount { get; set; }
    }
}
