﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.CapitationRates
{
    public class CapitationRateDto
    {
        public int CapitationRateId { get; set; }
        public string CapitationRateName { get; set; }
        public string CapitationRateDescription { get; set; }
        public string CapitationType { get; set; }
        public string CapitationTypeName { get; set; }
        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        public int? LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
    }
}