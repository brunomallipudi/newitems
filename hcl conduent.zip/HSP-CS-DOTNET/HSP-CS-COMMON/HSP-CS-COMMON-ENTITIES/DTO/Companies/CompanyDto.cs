﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Companies
{
    public class CompanyDto
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public string EIN { get; set; }
        public string Description { get; set; }
        public DateTime StartingFiscalDate { get; set; }
        public string AccountName { get; set; }
        public string AdditionalPayerNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int? Zip { get; set; }
        public string County { get; set; }
        public string ZipCodeId { get; set; }
        public string ContactName { get; set; }
        public string ContactPhone { get; set; }
        public string ContactExt { get; set; }
        public string ContactEmail { get; set; }
        public string CountryCode { get; set; }
        public string CountryISOCode2 { get; set; }
        public string CountryISOCode3 { get; set; }
        public double LATITUDE { get; set; }
        public double LONGITUDE { get; set; }
        public string UseDateReceivedForPosting { get; set; }
        public int SortOrder { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}
