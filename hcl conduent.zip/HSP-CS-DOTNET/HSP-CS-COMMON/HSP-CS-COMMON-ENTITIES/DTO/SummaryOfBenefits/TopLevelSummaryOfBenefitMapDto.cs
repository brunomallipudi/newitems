﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.SummaryOfBenefits
{
    public class TopLevelSummaryOfBenefitMapDto
    {
        public string SOBReportPath { get; set; }
        public int? SOBReportPathId { get; set; }
        public string SOBReportPathCrystal { get; set; }
        public int? EntityId { get; set; }
        public string EntityType { get; set; }
        public string PlanName { get; set; }
    }
}
