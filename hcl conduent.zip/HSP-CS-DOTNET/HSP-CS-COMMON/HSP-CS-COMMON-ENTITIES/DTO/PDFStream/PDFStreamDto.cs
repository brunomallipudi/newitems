﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.PDFStream
{
    public class PDFStreamDto
    {
        public string pdfStream { get; set; }
    }
}
