﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class ConfirmFormLetterBatchDto
    {
        public int? RowId { get; set; }
        public string OutputStatus { get; set; }
    }
}
