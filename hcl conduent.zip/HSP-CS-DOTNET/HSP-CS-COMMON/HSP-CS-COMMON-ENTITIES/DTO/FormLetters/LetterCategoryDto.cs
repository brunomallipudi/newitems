﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class LetterCategoryDto
    {
        public string IndividualType { get; set; }
        public string IndividualTypeName { get; set; }
        public string OutputSource { get; set; }
        public string OutputSourceName { get; set; }
        public int? UserReportId { get; set; }
        public string CrystalTemplate { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public int ReportCount { get; set; }
    }
}
