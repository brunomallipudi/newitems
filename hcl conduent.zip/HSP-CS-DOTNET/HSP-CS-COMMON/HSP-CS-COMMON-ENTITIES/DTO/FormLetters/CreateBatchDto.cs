﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
  public  class CreateBatchDto
    {
        public string IndividualType { get; set; }
        public string Usage { get; set; }
        public int[] RowId { get; set; }
        public string ExportType { get; set; }
        public int BatchId { get; set; }
        public int SessionId { get; set; }
    }
}
