﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class AddExtractedDataMasterDto
    {
        public int BatchId { get; set; }
    }
}
