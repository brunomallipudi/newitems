﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class AddExtractedDataDetailToBatchDto
    {
        public int BatchId { get; set; }
    }
}
