﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
   public class ProcessBatchExtractedDataDetailsDto
    {
        public int SessionId { get; set; }

        public int? UserReportId { get; set; }

        public string Usage { get; set; } = "|BYUSERREPORT|";

    }
}
