﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class ContactStepFormLetterDto
    {
        public int RowId { get; set; }
        public int ReasonId { get; set; }
        public int StepId { get; set; }
        public string IndividualType { get; set; }
        public string IndividualTypeName { get; set; }
        public int? UserReportId { get; set; }
        public string UserReportName { get; set; }
        public string AutoPrint { get; set; }
        public string DefaultFulfillmentType { get; set; }
        public string DefaultFulfillmentTypeName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
