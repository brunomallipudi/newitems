﻿namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public  class GetLetterDto
    {
        public string IndividualType { get; set; }
        public string Usage { get; set; }
        public int? RowId { get; set; }
        public string ExportType { get; set; }
        public int BatchId { get; set; }
    }
}
