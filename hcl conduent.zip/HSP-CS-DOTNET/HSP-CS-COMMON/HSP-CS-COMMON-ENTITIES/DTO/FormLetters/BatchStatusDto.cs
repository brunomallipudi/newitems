﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
   public class BatchStatusDto
    {
        public bool Completed { get; set; }
        public int BatchId { get; set; }
        public string ErrorMessage { get; set; }
    }
}
