﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class LetterBatchDto
    {
        public int BatchId { get; set; }
        public string Description { get; set; }
        public string ResultsetType { get; set; }
        public string ResultsetTypeName { get; set; }
        public string IndividualType { get; set; }
        public string IndividualTypeName { get; set; }
        public string Status { get; set; }
        public string OutputType { get; set; }
        public string OutputSource { get; set; }
        public int TotalCount { get; set; }
        public string ProductName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedById { get; set; }
        public string CreatedBy { get; set; }
    }
}
