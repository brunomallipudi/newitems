﻿namespace HSP_CS_COMMON_ENTITIES.DTO.FormLetters
{
    public class DownloadAttachmentDto
    {
        public string FileByte { get; set; }
        public string LetterTransactionId { get; set; }
        public int BatchId { get; set; }
    }
}
