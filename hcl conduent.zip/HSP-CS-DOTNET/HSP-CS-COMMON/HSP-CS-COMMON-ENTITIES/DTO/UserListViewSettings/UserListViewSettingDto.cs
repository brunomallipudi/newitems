﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.UserListViewSettings
{
    /// <summary>
    /// UserListViewSetting
    /// As it gets returned from the stored procedure
    /// </summary>
    public class UserListViewSettingDto
    {
        /// <summary>
        /// This contains XML
        /// Will not serialize for the Web UI
        /// </summary>
        [JsonIgnore]
        public string ColumnSettings { get; set; }
    }
}
