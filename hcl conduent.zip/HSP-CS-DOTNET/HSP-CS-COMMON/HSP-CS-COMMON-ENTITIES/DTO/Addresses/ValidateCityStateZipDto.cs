﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.Addresses
{
    public class ValidateCityStateZipDto
    {
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string County { get; set; }
        public string CountryCode { get; set; }
        public int ZipCodeId { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
