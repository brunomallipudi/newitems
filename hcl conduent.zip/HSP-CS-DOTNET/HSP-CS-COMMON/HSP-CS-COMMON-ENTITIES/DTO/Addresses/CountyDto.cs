﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.Addresses
{
    public class CountyDto
    {
        public string County { get; set; }
    }
}
