﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class SystemOptionDto
    {
		public string ItemType { get; set; }

		public string ItemValue { get; set; }

		public DateTime LastUpdatedAt { get; set; }

		public int LastUpdatedBy { get; set; }
	}
}
