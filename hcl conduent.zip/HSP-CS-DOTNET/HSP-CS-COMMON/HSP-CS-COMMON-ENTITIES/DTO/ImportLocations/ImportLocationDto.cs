﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ImportLocations
{
    public class ImportLocationDto
    {
        public int LocationId { get; set; }
        public string LocationName { get; set; }
        public string DocumentType { get; set; }
        public string LocationPath { get; set; }
        public string StreamInput { get; set; }
        public string ExternalVerification { get; set; }
        public string AutomateInput { get; set; }
        public string EmbossImages { get; set; }
        public string ImageType { get; set; }
        public string ImportType { get; set; }
        public string SiteName { get; set; }
        public int? WorkGroupID { get; set; }
        public string ArchivePath { get; set; }
        public string FormType { get; set; }
        public string FormTypeName { get; set; }
        public string FormSubtype { get; set; }
        public string FormSubtypeName { get; set; }
        public string DefaultClass { get; set; }
        public string DefaultSubClass { get; set; }
        public string WorkGroupName { get; set; }
        public string LastUpdatedBy { get; set; }
        public int? LastUpdatedByID { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string OutputWithPaper { get; set; }
        public string DoNotSendToPayer { get; set; }
        public string FTPPath { get; set; }
        public string FTPUserName { get; set; }
        public string FTPPassword { get; set; }
        public string ClaimTotalChargeCeiling { get; set; }
        public int? ClientClaimSchemaRuleID { get; set; }
        public string DefaultSettings { get; set; }
        public string ExternalCapture { get; set; }
    }
}
