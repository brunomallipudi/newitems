﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Contracts
{
    public class ContractDto
    {
        public int ContractId { get; set; }
        public string ContractNumber { get; set; }
        public string ContractName { get; set; }
        public string CapitationOnly { get; set; }
        public string ContractDescription { get; set; }
        public string ContractNotes { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string Negotiated { get; set; }
        public string PricingMode { get; set; }
        public string ToPay { get; set; }
        public int PreEstExpUnits { get; set; }
        public string PreEstExpUnitType { get; set; }
        public string RVSMultiplier { get; set; }
        public int? CapitationRateId { get; set; }
        public string CapitationRateName { get; set; }
        public DateTime? LastPostedDate { get; set; }
        public int RetroactiveAddLimit { get; set; }
        public int RetroactiveTermLimit { get; set; }
        public int PostingCutoffDay { get; set; }
        public DateTime? CapitationCurrentPeriod { get; set; }
        public string UseHCPCSWhenFindFeeSchedule { get; set; }
        public string FeeScheduleSearchCriteria { get; set; }
        public string ApplyCopayPerSchedule { get; set; }
        public string PaymentClass { get; set; }
        public string SuppressPayment { get; set; }
        public string ProviderInheritsMemberPayment { get; set; }
        public string ContractType { get; set; }
        public string ContractTypeName { get; set; }
        public string LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? AsOfDate { get; set; }
        public int? ReimbursementId { get; set; }
        public string PanelSizeEnforcement { get; set; }
        public string PanelSizeCalculationMethod { get; set; }
        public int FuturePCPLookbackPeriod { get; set; }
        public int PrimaryPCPLookbackPeriod { get; set; }
        public string PanelOverrideAllowance { get; set; }
        public string MoneyLimitProcessingOrder { get; set; }
    }
}
