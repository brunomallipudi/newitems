﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Explanations
{
    public class ExplanationCategoryDto
    {
        public int ExplanationId { get; set; }
        public string ProductName { get; set; }
        public string Product { get; set; }
        public string Precedence { get; set; }
        public string Active { get; set; }
        public int? ExplanationCategoryId { get; set; }
        public string ExplanationCategoryName { get; set; }
        public string ExplanationCategoryType { get; set; }
        public string ExplanationCategoryTypeName { get; set; }
        public string HIPAA { get; set; }
        public string AllowUserExplanation { get; set; }
        public string AllowDenialFieldsToBeSet { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? LastUpdatedBy { get; set; }
        public string LastUpdatedByUser { get; set; }
        public string NodeName { get; set; }
        public string Description { get; set; }
        public string IsRepricingInPerfectClaim { get; set; }
        public string AllowUserExplanationsOnly { get; set; }
    }
}
