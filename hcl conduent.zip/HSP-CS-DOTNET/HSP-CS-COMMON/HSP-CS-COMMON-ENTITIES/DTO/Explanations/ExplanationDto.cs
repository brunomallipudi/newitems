﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Explanations
{
    /// <summary>
    /// Explanation as it comes out from the stored procedure.
    /// </summary>
   public class ExplanationDto
    {
        public int ExplanationId { get; set; }
        public string Severity { get; set; }
        public string SeverityName { get; set; }
        public string Abbreviation { get; set; }
        public string Explanation { get; set; }
        public string ExplanationCode { get; set; }
        public string ProductName { get; set; }
        public string Product { get; set; }
        public double? SortKey { get; set; }
        public int? ActionCodeId { get; set; }
        public string ActionCode { get; set; }
        public string ActionCodeType { get; set; }
        public string ActionCodeName { get; set; }
        public string AllowOverride { get; set; }
        public string EnableAllowOverride { get; set; }
        public string AllowInformationLevel { get; set; }
        public double? Precedence { get; set; }
        public string DefaultExplanation { get; set; }
        public string OutputType { get; set; }
        public string Active { get; set; }
        public int? ContactReasonID { get; set; }
        public string ContactReasonName { get; set; }
        public string IndividualCode { get; set; }
        public string IndividualCodeName { get; set; }
        public string AdditionalIndividualCode { get; set; }
        public string AdditionalIndividualCodeName { get; set; }
        public string DefaultGroupCode { get; set; }
        public int? ExplanationCategoryId { get; set; }
        public string ExplanationCategoryName { get; set; }
        public string ExplanationCategoryType { get; set; }
        public string ExplanationCategoryTypeName { get; set; }
        public double ExplanationCategoryPrecedence { get; set; }
        public string HIPAA { get; set; }
        public string AllowUserExplanation { get; set; }
        public string AllowDenialFieldsToBeSet { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? LastUpdatedBy { get; set; }
        public string LastUpdatedByUser { get; set; }
        public string NodeName { get; set; }
        public string ExplanationCatNameAndAbbrev { get; set; }
        public string ShortExplanation { get; set; }
        public string DenialCategory { get; set; }
        public string DenialAction { get; set; }
        public string DenialCategoryName { get; set; }
        public string DenialActionName { get; set; }
        public int? AdjActionCodeID { get; set; }
        public string AdjActionCode { get; set; }
        public string AdjActionCodeName { get; set; }
        public string AllowDenial { get; set; }
        public string AllowDenialName { get; set; }
        public string Definition { get; set; }
        public int? EntityTransformId { get; set; }
        public string TransformName { get; set; }
        public string ApplyToClaimCode { get; set; }
        public string ApplyToClaim { get; set; }
        public string AdjudicationErrorActionCode { get; set; }
        public string AdjudicationErrorAction { get; set; }
        public string ExplanationClass { get; set; }
        public string ExplanationClassName { get; set; }
        public string ExplanationSubClass { get; set; }
        public string ExplanationSubClassName { get; set; }
        public string DenialTakesPrecedence { get; set; }
   

    }
}