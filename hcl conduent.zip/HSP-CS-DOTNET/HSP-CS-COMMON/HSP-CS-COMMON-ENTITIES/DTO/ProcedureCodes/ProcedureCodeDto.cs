﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class ProcedureCodeDto
    {
		public int ProcedureCodeId { get; set; }
		
		public int ProcedureCategoryId { get; set; }
		
		public string ProcedureCategoryName { get; set; }
		
		public string CodeName { get; set; }
		
		public string ProcedureCode { get; set; }
		
		public string CodeType { get; set; }
		
		public string ProcedureName { get; set; }
		
		public string Description { get; set; }
		
		public string TypeOfService { get; set; }
		
		public string EstimatedCostWeight { get; set; }
		
		public float? EstimatedUnits { get; set; }
		
		public string UnitType { get; set; }
		
		public string AgeType { get; set; }
		
		public int? AgeRangeBegin { get; set; }
		
		public int? AgeRangeEnd { get; set; }
		
		public string SexLimit { get; set; }
		
		public DateTime EffectiveDate { get; set; }
		
		public DateTime ExpirationDate { get; set; }
		
		public float? MinimumServiceUnits { get; set; }
		
		public decimal? MinimumServiceValue { get; set; }
		
		public float? MaximumServiceUnits { get; set; }
		
		public decimal? MaximumServiceValue { get; set; }
		
		public string PreEstimateRequired { get; set; }
		
		public string PaymentGroupCode { get; set; }
		
		public DateTime MapEffectiveDate { get; set; }
		
		public DateTime MapExpirationDate { get; set; }
		
		public DateTime CurrentMapEffectiveDate { get; set; }
		
		public string MapStatus { get; set; }
		
		public float? SortKey { get; set; }
		
		public DateTime LastUpdatedAt { get; set; }
		
		public string LastUpdatedBy { get; set; }
		
		public DateTime? AsOfDate { get; set; }
		
		public string ExcludeFromDupChecking { get; set; }
		
		public string DentalValidationCode { get; set; }
	}
}
