﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.RiskGroups
{
    public class RiskGroupDto
    {
        public int RiskGroupId { get; set; }
        public string RiskGroupName { get; set; }
        public string RiskGroupDescription { get; set; }
        public string Capitation { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string RiskGroupNumber { get; set; }
        public DateTime? AsOfDate { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string County { get; set; }
        public string ContactName { get; set; }
        public string ContactPhone { get; set; }
        public string ContactExt { get; set; }
        public string ContactFax { get; set; }
        public string ContactEmail { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public int? ZipCodeId { get; set; }
        public string CountryCode { get; set; }
        public string CountryISOCode2 { get; set; }
        public string CountryISOCode3 { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string ZipSearch { get; set; }
        public string RiskGroupClass { get; set; }
        public string RiskGroupSubclass { get; set; }
        public string RiskGroupClassName { get; set; }
        public string RiskGroupSubclassName { get; set; }
        public string ClaimRedirectFulfillmentMethod { get; set; }
        public string ClaimRedirectFulfillmentMethodName { get; set; }
        public int? ClaimRedirectAddressId { get; set; }
        public string ClaimRedirectAddressName { get; set; }
        public string ClaimRedirectRule { get; set; }
        public string ClaimRedirectRuleName { get; set; }
        public int? InterchangeId { get; set; }
        public string InterchangeName { get; set; }
    }
}
