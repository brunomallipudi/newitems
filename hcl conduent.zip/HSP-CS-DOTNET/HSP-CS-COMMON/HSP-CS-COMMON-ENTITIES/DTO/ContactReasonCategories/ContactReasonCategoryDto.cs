﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ContactReasonCategories
{
    public class ContactReasonCategoryDto
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDescription { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public double SortKey { get; set; }
        public string CategoryClass { get; set; }
        public string CategorySubclass { get; set; }
    }
}