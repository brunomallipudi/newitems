﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.Notes
{
    public class NoteDto
    {
        public string EntityType { get; set; }
        public int? EntityId { get; set; }
        public int? SequenceNumber { get; set; }
        public string SchemaType { get; set; }
        public string DataString { get; set; }
        public string ShortDataString { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public int? NotesCategoryId { get; set; }
        public string NotesCategoryName { get; set; }
    }
}
