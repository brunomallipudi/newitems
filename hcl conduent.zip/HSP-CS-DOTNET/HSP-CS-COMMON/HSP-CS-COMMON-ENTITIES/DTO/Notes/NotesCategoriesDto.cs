﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Notes
{
    public class NotesCategoriesDto
    {
        public int NotesCategoryId { get; set; }
        public string NotesCategoryName { get; set; }
        public string Disabled { get; set; }
        public string Description { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string MapStatus { get; set; }
    }
}
