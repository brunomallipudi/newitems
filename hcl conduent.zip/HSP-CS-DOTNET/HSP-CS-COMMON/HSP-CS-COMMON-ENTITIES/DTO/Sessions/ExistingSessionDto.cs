﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Sessions
{
    /// <summary>
    /// Returns FROM:   E_CONNECTUSER_V3
    ///         WHEN:   A user has an existing active session.
    /// </summary>
    public class ExistingSessionDto
    {
        public string FullName { get; set; }

        public string ComputerName { get; set; }

        public DateTime ConnectTime { get; set; }
    }
}