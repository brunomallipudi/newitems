﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class IndividualDto
    {
        public string IndividualNumber { get; set; }
        public int IndividualID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string FullName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Sex { get; set; }  
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string County { get; set; }
        public int? ZipCodeId { get; set; }
        public string CountryCode { get; set; }
        public string CountryISOCode2 { get; set; }
        public string CountryISOCode3 { get; set; }  
        public double? Latitude { get; set; }    
        public double? Longitude { get; set; }
        public string HomePhone { get; set; }  
        public string WorkPhone { get; set; }  
        public string FaxNumber { get; set; } 
        public string Suffix { get; set; } 
        public string Title { get; set; } 
        public string PrintName { get; set; } 
        public string Email { get; set; }
        public string Comments { get; set; }
        public string IndividualCode { get; set; }
        public string Organization { get; set; }  
        public string Source { get; set; }
        public string LastUpdatedBy { get; set; }
        public string LastUpdatedAt { get; set; }
        public string LastNameMask { get; set; }
        public string FirstNameMask { get; set; }
        public string SocSecNumMask { get; set; }
        public string Soundex { get; set; }
    }
}
