﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.Individuals
{
   public class AddIndividualDto
    {
        public int IndividualID { get; set; }
    }
}
