﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Countries
{
    public class CountryDto
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public string BaseCurrency { get; set; }
        public string BaseCurrencyName { get; set; }
        public string PrimaryLanguage { get; set; }
        public string PrimaryLanguageName { get; set; }
        public string PhonePrefix { get; set; }
        public string CountryISOCode2 { get; set; }
        public string CountryISOCode3 { get; set; }
        public string ValidationType { get; set; }
        public string ValidationTypeName { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string LastUpdatedByName { get; set; }
    }
}