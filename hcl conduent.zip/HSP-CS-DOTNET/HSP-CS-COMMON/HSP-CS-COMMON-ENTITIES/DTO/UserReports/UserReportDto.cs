﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.UserReports
{
    public class UserReportDto
    {
        public int UserReportId { get; set; }
        public string CategoryCode { get; set; }
        public string CategoryName { get; set; }
        public string Class { get; set; }
        public object DefaultParameters { get; set; }
        public string DefaultColumns { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public int LastUpdatedById { get; set; }
        public string MultiRecordset { get; set; }
        public string OnlineReportName { get; set; }
        public int OperationalReportId { get; set; }
        public int? PermissionId { get; set; }
        public string PermissionName { get; set; }
        public string ReportDescription { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public string ReportType { get; set; }
        public double SortKey { get; set; }
        public string StoredProcedureName { get; set; }
        public string SubCategoryCode { get; set; }
        public string SubCategoryName { get; set; }
        public string Status { get; set; }
        public string StatusName { get; set; }
        public string ExportType { get; set; }
        public string ExportDocumentSource { get; set; }
        public string PSScript { get; set; }
    }
}
