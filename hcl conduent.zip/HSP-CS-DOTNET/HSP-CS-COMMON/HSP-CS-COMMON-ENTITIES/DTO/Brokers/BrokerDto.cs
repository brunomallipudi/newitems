﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class BrokerDto
    {
		public int BrokerId { get; set; }

		public string BrokerType { get; set; }

		public string BrokerTypeName { get; set; }

		public string BrokerNumber { get; set; }

		public decimal? DefaultCommission { get; set; }

		public int VendorId { get; set; }

		public string VendorName { get; set; }

		public string LastName { get; set; }

		public string FirstName { get; set; }

		public string MiddleName { get; set; }

		public string Title { get; set; }

		public string Address1 { get; set; }

		public string Address2 { get; set; }

		public string City { get; set; }

		public string State { get; set; }

		public string Zip { get; set; }

		public string County { get; set; }

		public int? ZipCodeId { get; set; }

		public string CountryCode { get; set; }

		public string CountryISOCode2 { get; set; }

		public string CountryISOCode3 { get; set; }

		public double? Latitude { get; set; }

		public double? Longitude { get; set; }

		public string HomePhone { get; set; }

		public string WorkPhone { get; set; }

		public string WorkPhoneExt { get; set; }

		public DateTime EffectiveDate { get; set; }

		public DateTime ExpirationDate { get; set; }

		public DateTime LastUpdatedAt { get; set; }

		public string LastUpdatedBy { get; set; }

		public string AccessCode { get; set; }

		public string CellPhone { get; set; }

		public string FaxPhone { get; set; }

		public string LicenseNumber { get; set; }

		public string ContactName { get; set; }

		public string ContactEmail { get; set; }

		public string BrokerName { get; set; }

		public int? WebUserId { get; set; }

		public string WebUserName { get; set; }

		public string WebUserFullName { get; set; }

		public string WebUserEmail { get; set; }

		public string Class { get; set; }

		public string SubClass { get; set; }

		public string NationalProducerNumber { get; set; }

		public DateTime? DateOfBirth { get; set; }

		public string SSN { get; set; }

		public string LicenseState { get; set; }

		public DateTime? LicenseEffectiveDate { get; set; }

		public DateTime? LicenseExpirationDate { get; set; }

		public string AppointmentStatus { get; set; }

		public DateTime? AppointmentDate { get; set; }

		public DateTime? LastVerificationDate { get; set; }

		public DateTime? NextVerificationDate { get; set; }

		public DateTime? TerminationDate { get; set; }

		public string TerminationReason { get; set; }

		public string TerminationForCause { get; set; }

		public string EIN { get; set; }

		public string LegalName { get; set; }

		public DateTime? LastVerificationFrom { get; set; }

		public DateTime? LastVerificationTo { get; set; }

		public DateTime? NextVerificationFrom { get; set; }

		public DateTime? NextVerificationTo { get; set; }

		public DateTime? AppointmentDateFrom { get; set; }

		public DateTime? AppointmentDateTo { get; set; }
	}
}
