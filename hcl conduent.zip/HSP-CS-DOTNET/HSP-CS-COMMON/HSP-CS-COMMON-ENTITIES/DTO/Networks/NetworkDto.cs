﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Networks
{
    public class NetworkDto
    {
        public int NetworkId { get; set; }
        public string NetworkName { get; set; }
        public string ShowExternally { get; set; }
        public string NetworkCode { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}