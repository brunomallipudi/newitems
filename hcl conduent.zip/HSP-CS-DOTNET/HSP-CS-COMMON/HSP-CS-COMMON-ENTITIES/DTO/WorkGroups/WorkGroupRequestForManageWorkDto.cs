﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.WorkGroups
{
    public class WorkGroupRequestForManageWorkDto
    {
        public int RequestId { get; set; }
        public string Subject { get; set; }
        public DateTime? DateRequested { get; set; }
        public DateTime? DateInitiated { get; set; }
        public DateTime? DateDue { get; set; }
        public DateTime? DateReceived { get; set; }
        public string OriginalDocumentName { get; set; }
        public string Request { get; set; }
        public string FullName { get; set; }
        public DateTime? DateStarted { get; set; }
        public int? WorkgroupId { get; set; }
        public string WorkgroupName { get; set; }
        public string WorkGroupQueueDiscipline { get; set; }
        public DateTime? WorkDate { get; set; }
        public string Locked { get; set; }
        public string OverDue { get; set; }
        public string EntityType { get; set; }
        public int? EntityID { get; set; }
        public int? FileID { get; set; }
        public string FileParentId { get; set; }
        public string FileSubject { get; set; }
        public string TrackingNumber { get; set; }
        public string FileReasonShortcut { get; set; }
        public string FileContactReasonName { get; set; }
        public string ContactCategoryName { get; set; }
        public string FileContactReasonCategoryType { get; set; }
        public string QueueDescription { get; set; }
        public int? IndividualId { get; set; }
        public string IndividualType { get; set; }
        public string IndividualTypeName { get; set; }
        public string IndividualNumber { get; set; }
        public string IndividualName { get; set; }
        public int? AdditionalIndividualId { get; set; }
        public string AdditionalIndividualType { get; set; }
        public string AdditionalIndividualTypeName { get; set; }
        public string AdditionalIndividualNumber { get; set; }
        public string AdditionalIndividualName { get; set; }
        public string GroupNumber { get; set; }
        public string GroupName { get; set; }
        public string ParentGroupNumber { get; set; }
        public string ParentGroupName { get; set; }
        public string LOB { get; set; }
        public int? GroupId { get; set; }
        public int? ParentGroupId { get; set; }
        public string Permitted { get; set; }
        public int? CountPermitted { get; set; }
        public int? CheckOutUserId { get; set; }
        public string AssignToUserName { get; set; }
        public DateTime? DateAssigned { get; set; }
        public string CheckedOutToAnotherUser { get; set; }
        public int? NumOfItems { get; set; }
        public DateTime? DateOfOldest { get; set; }
        public string AverageDaysOnQueue { get; set; }
        public int? OldestItemNumDays { get; set; }
        public string Priority { get; set; }
        public string Class { get; set; }
        public string ReasonFileOnHold { get; set; }
        public string ReasonFileOnHoldName { get; set; }
        public string AttributeValue { get; set; }
        public string AttributeValue2 { get; set; }
        public int? DaysOnQueue { get; set; }
        public int? CategoryId { get; set; }
        public string ContactCategoryId { get; set; }
        public int? AssignToId { get; set; }
        public int? ReasonId { get; set; }
        public DateTime? DateOpened { get; set; }
        public int? MemberId { get; set; }
        public string MemberNumber { get; set; }
        public string MemberName { get; set; }
        public int? SupplementalId { get; set; }
        public string SupplementalType { get; set; }
        public string BillingCode { get; set; }
        public string FileStatus { get; set; }
        public string FileStatusName { get; set; }        
        public int? StepID { get; set; }
        public string StepName { get; set; }
        public string ParentEventTrackingNumber { get; set; }
        public string ReasonName { get; set; }
    }
}
