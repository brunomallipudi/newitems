﻿using Newtonsoft.Json;
using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.WorkGroups
{
    public class AdminWorkGroupRequestDto
    {
        public int RequestID { get; set; }

        public string WorkGroupName { get; set; }

        [JsonProperty("DateOpened")]
        public string DateOpenedFormat { get; set; }

        private DateTime? _dateOpened;
        [JsonIgnore]        
        public DateTime? DateOpened
        {
            get
            {
                return _dateOpened;
            }
            set
            {
                if(value != null)
                {
                    _dateOpened = value;
                    DateOpenedFormat = _dateOpened.Value.Date.ToString("MM-dd-yyyy");
                }
            }
        }

        public string FileContactCategoryName { get; set; }

        [JsonProperty("DateAssigned")]
        public string DateAssignedFormat { get; set; }

        private DateTime? _dateAssigned;
        [JsonIgnore]
        public DateTime? DateAssigned
        {
            get
            {
                return _dateAssigned;
            }
            set
            {
                if (value != null)
                {
                    _dateAssigned = value;
                    DateAssignedFormat = _dateAssigned.Value.Date.ToString("MM-dd-yyyy");
                }
            }
        }

        public string FileContactReasonName { get; set; }

        [JsonProperty("DateDue")]
        public string DateDueFormat { get; set; }

        private DateTime? _dateDue;
        [JsonIgnore]
        public DateTime? DateDue
        {
            get
            {
                return _dateDue;
            }
            set
            {
                if (value != null)
                {
                    _dateDue = value;
                    DateDueFormat = _dateDue.Value.Date.ToString("MM-dd-yyyy");
                }
            }
        }

        public string AssignToUserName { get; set; }
    }
}
