﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class WorkGroupDto
    {
		public int WorkGroupId { get; set; }

		public string WorkGroupName { get; set; }

		public string WorkGroupAbbreviation { get; set; }

		public string QueueDisiplineCode { get; set; }

		public string QueueDisciplineName { get; set; }

		public string WorkGroupType { get; set; }

		public string WorkGroupTypeName { get; set; }

		public string WorkGroupSubtype { get; set; }

		public string WorkGroupSubTypeName { get; set; }

		public int OwnedBy { get; set; }

		public string OwnedByName { get; set; }

		public int? TargetWaitTime { get; set; }

		public int? TargetNumItems { get; set; }

		public int? NumOfItems { get; set; }

		public DateTime? DateOfOldest { get; set; }

		public int? OldestItemNumDays { get; set; }

		public int? AverageDaysOnQueue { get; set; }

		public string Allowed { get; set; }

		public string WorkGroupStatus { get; set; }

		public string WorkGroupStatusName { get; set; }

		public string EMFirstItem { get; set; }

		public string EMEveryItem { get; set; }

		public string EMOverdueItems { get; set; }

		public string EMAfterNItems { get; set; }

		public string EMAfterNHrs { get; set; }

		public string EMSummary { get; set; }

		public int? CurrentUserId { get; set; }

		public string WorkGroupClass { get; set; }

		public string WorkGroupClassName { get; set; }

		public string WorkGroupSubclass { get; set; }

		public string WorkGroupSubclassName { get; set; }

		public string DefaultButtonBar { get; set; }

		public int? DefaultStyleSheet { get; set; }

		public int? NumberOfOverdueItems { get; set; }

		public int? AgingCount { get; set; }

		public int? DaysToComplete { get; set; }

		public string CompletionCalculationMethod { get; set; }

		public string CompletionCalculationMethodName { get; set; }

		public float? WorkGroupPriority { get; set; }

		public int? AssignedItems { get; set; }

		public DateTime LastUpdatedAt { get; set; }

		public int LastUpdatedById { get; set; }

		public string LastUpdatedBy { get; set; }
	}
}
