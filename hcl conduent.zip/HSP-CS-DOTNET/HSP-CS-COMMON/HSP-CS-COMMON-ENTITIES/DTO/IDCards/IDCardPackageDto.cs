﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.IDCards
{
    /// <summary>
    /// ID Card Package as it comes out from the stored procedure.
    /// </summary>
    public class IDCardPackageDto {

        public int? IDCardPackageId { get; set; }
        public string IDCardPackageName { get; set; }
        public int? IDCardReportID { get; set; }
        public string IDCard { get; set; }
        public string IDCardPath { get; set; }
        public string SendToGroup { get; set; }
        public string SendToDependents { get; set; }
        public string OutputToFile { get; set; }
        public string WebUsage { get; set; }
        public string WebUsageName { get; set; }
        public int? PreviousCardGap { get; set; }
        public int? IDCardPackageGroupMapID { get; set; }
        public DateTime? PackageEffectiveDate { get; set; }
        public DateTime? PackageExpirationDate { get; set; }
        public int? MinimumGapInCoverage { get; set; }
        public string GenerateCardOnGroupChange { get; set; }
        public string RequireRequestType { get; set; }
        public string LastupdatedBy { get; set; }
        public DateTime? LastupdatedAt { get; set; }
        public int? NumberOfPendingRequests { get; set; }
        public int? NumberOfCompletedRequests { get; set; }
        public string VoidIdCardsWhenTerminating { get; set; }
        public int? OutputFileTransform { get; set; }
        public string OutputFileTransformName { get; set; }
        public int? TotalPendingRequestsAcrossSubGroups { get; set; }
        public int? TotalCompletedRequestsAcrossSubGroups { get; set; }
        public int? GroupId { get; set; }
        public string GroupName { get; set; }
        public string Class { get; set; }
        public string SubClass { get; set; }
        public string ClassName { get; set; }
        public string SubClassName { get; set; }
    }
}