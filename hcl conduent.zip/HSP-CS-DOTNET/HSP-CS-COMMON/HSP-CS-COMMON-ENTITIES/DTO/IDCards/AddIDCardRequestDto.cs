﻿namespace HSP_CS_COMMON_ENTITIES.DTO.IDCards
{
    public class AddIDCardRequestDto
    {
        public int IDCardRequestID { get; set; }
        public int IDCardProcessMapID { get; set; }
    }
}
