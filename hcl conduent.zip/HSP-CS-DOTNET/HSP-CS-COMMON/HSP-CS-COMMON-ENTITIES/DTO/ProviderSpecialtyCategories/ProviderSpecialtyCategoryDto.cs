﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ProviderSpecialtyCategories
{
    public class ProviderSpecialtyCategoryDto
    {
        public int ProviderSpecialtyCategoryID { get; set; }
        public string CategoryName { get; set; }
        public string DisplayStatus { get; set; }
        public int DisplayStatusSort { get; set; }
        public int SortKey { get; set; }
        public int ParentId { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}