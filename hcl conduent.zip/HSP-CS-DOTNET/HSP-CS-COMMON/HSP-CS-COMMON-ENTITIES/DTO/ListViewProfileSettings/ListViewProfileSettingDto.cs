﻿using Newtonsoft.Json;

namespace HSP_CS_COMMON_ENTITIES.DTO.ListViewProfileSettings
{
    /// <summary>
    /// ListViewProfileSetting object
    /// As it gets returned from the stored procedure
    /// </summary>
    public class ListViewProfileSettingDto
    {
        public int ListviewControlId { get; set; }
        public string Interface { get; set; }
        public string InitUsage { get; set; }
        public string IsPaging { get; set; }
        
        /// <summary>
        /// This contains XML
        /// Will not serialize for the Web UI
        /// </summary>
        [JsonIgnore]
        public string Formatters { get; set; }

        /// <summary>
        /// This contains XML
        /// Will not serialize for the Web UI
        /// </summary>
        [JsonIgnore]
        public string Settings { get; set; }

        public int ListviewProfileSettingId { get; set; }
        public int ProfileId { get; set; }
    }
}