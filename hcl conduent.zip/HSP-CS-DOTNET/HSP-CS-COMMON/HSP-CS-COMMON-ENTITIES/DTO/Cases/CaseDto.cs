﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Cases
{
    public class CaseDto
    {
        public int? MemberId { get; set; }
        public string MemberName { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MemberNumber { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string ExternalCaseNumber { get; set; }
        public string Jurisdiction { get; set; }
        public int? CaseID { get; set; }
        public string CaseNumber { get; set; }
        public int? BasePlanID { get; set; }
        public string BasePlanName { get; set; }
        public int? AdjustmentVersion { get; set; }
        public int? CurrentAdjustmentVersion { get; set; }
        public int? MemberCoverageID { get; set; }
        public int? GroupID { get; set; }
        public string GroupName { get; set; }
        public int? CompanyID { get; set; }
        public string CaseStatus { get; set; }
        public string CaseStatusName { get; set; }
        public string ApprovalStatus { get; set; }
        public string ApprovalStatusName { get; set; }
        public int? CaseManagerID { get; set; }
        public string CaseManager { get; set; }
        public int? ClaimAdjusterID { get; set; }
        public string ClaimAdjuster { get; set; }
        public int? BenefitCategoryID { get; set; }
        public string BenefitCategoryName { get; set; }
        public string ReserveType { get; set; }
        public DateTime? DateSentToReview { get; set; }
        public DateTime? DateResentToReview { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateReopened { get; set; }
        public DateTime? DateClosed { get; set; }
        public DateTime? DateOfIncident { get; set; }
        public string UseDateOfIncidentForAdjudication { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LatestDateClosed { get; set; }
        public DateTime DateCreated { get; set; }
        public string PARAmount { get; set; }
        public string StopLossAmount { get; set; }
        public string StopLossPercentStatus { get; set; }
        public string StopLossPercentStatusName { get; set; }
        public DateTime? DateStopLossPercentExceeded { get; set; }
        public DateTime? DateStopLossAmountExceeded { get; set; }
        public int? InitialPolicyID { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string CaseLevel { get; set; }
        public string CaseLevelName { get; set; }
        public string CaseClass { get; set; }
        public string CaseClassName { get; set; }
        public string CaseSubClass { get; set; }
        public string CaseSubClassName { get; set; }
        public int? ParentCaseID { get; set; }
        public string ParentCaseNumber { get; set; }
        public string CaseType { get; set; }
        public string CaseTypeName { get; set; }
        public string ClaimConnected { get; set; }
    }
}
