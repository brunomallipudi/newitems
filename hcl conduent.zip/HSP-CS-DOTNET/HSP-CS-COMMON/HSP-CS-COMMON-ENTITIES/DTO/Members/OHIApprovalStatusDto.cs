﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class OHIApprovalStatusDto
    {
        public int? MemberID { get; set; }
        public int AttributeId { get; set; }
        public string AttributeValue { get; set; }
        public string EntityType { get; set; }
        public string AttributeName { get; set; }
        public string TrackingNumber { get; set; }
    }
}