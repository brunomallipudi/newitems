﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class FamilyMemberDto
    {
        public int MemberCoverageId { get; set; }
        public int MemberId { get; set; }
        public string MemberNumber { get; set; }
        public string GroupNumber { get; set; }
        public string GroupName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string PolicyNumber { get; set; }
        public string EmployerName { get; set; }
        public string DependentViewWebOption { get; set; }
        public string DependentViewWebOptionName { get; set; }
        public int? GroupId { get; set; }
        public int? BasePlanId { get; set; }
        public string PlanName { get; set; }
        public string RelationshipCode { get; set; }
        public string Relationship { get; set; }
        public string AppNumber { get; set; }
        public int? AddedBy { get; set; }
        public string AddedByName { get; set; }
        public DateTime? AddedAt { get; set; }
        public int? TermedBy { get; set; }
        public string TermedByName { get; set; }
        public DateTime? TermedAt { get; set; }
    }
}
