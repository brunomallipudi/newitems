﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    /// <summary>
    /// Member Carrier Map as it comes out from the stored procedure.
    /// </summary>
    public class MemberCarrierMapDto
    {
        public int? RowId { get; set; }
        public int? SubscriberContractId { get; set; }
        public int? MemberId { get; set; }
        public string SubscriberFirstName { get; set; }
        public string SubscriberLastName { get; set; }
        public string GroupNumber { get; set; }
        public string GroupName { get; set; }
        public string COBType { get; set; }
        public string COBPrecedence { get; set; }
        public string COBPrecedenceName { get; set; }
        public string COBClass { get; set; }
        public string COBClassName { get; set; }
        public string COBSubClass { get; set; }
        public string COBSubClassName { get; set; }
        public string internalPayerType { get; set; }
        public string internalPayerTypeName { get; set; }
        public int? PayerID { get; set; }
        public string PayerName { get; set; }
        public string PayerType { get; set; }
        public string PayerTypeName { get; set; }
        public string PayerNumber { get; set; }
        public string PayerEmpName { get; set; }
        public string PayerGroupNumber { get; set; }
        public string PayerMemberNumber { get; set; }
        public string PayerDescription { get; set; }
        public string PayerAddress1 { get; set; }
        public string PayerAddress2 { get; set; }
        public string PayerCity { get; set; }
        public string PayerState { get; set; }
        public string PayerCounty { get; set; }
        public string PayerZip { get; set; }
        public string PayerZipCodeId { get; set; }
        public string PayerCountryCode { get; set; }
        public string RelationshipToSubscriber { get; set; }
        public string RelationshipToSubscriberName { get; set; }
        public string Coverage { get; set; }
        public string CoverageName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string DisplayName { get; set; }
        public string TrackingNumberWithPayer { get; set; }
        public int? FileId { get; set; }
        public int? InboundJobDetailId { get; set; }
        public string Import { get; set; }
        public string CreatedByName { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string Zip { get; set; }
        public int? ZipCodeId { get; set; }
        public string CountryCode { get; set; }
        public string PolicyHolderLastName { get; set; }
        public string PolicyHolderFirstName { get; set; }
        public string PolicyHolderMiddleName { get; set; }
        public string PolicyHolderNameSuffix { get; set; }
        public string PolicyHolderSuffix { get; set; }
        public string PolicyHolderSSN { get; set; }
        public DateTime? PolicyHolderDOB { get; set; }
        public string PolicyHolderGender { get; set; }
        public string PolicyHolderPhone { get; set; }
        public string RxIDNumber { get; set; }
        public string RxBINNumber { get; set; }
        public string RxPCNNumber { get; set; }
        public string RxGroupNumber { get; set; }
        public string RxPhoneNumber { get; set; }
        public string PAPNationalDrugCode1 { get; set; }
        public string PAPNationalDrugCode2 { get; set; }
        public string PAPNationalDrugCode3 { get; set; }
        public string PAPNationalDrugCode4 { get; set; }
        public string PAPNationalDrugCode5 { get; set; }
        public string MSPType { get; set; }
        public string SupplementalType { get; set; }
        public string PayerOrder { get; set; }
        public string SequenceNumber { get; set; }
        public DateTime? MACOBEffectiveDate { get; set; }
        public string ExternalIdNumber { get; set; }
    }
}