﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class COBLoginDto
    {
        public string TrackingNumber { get; set; }
        public string MemberNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int MemberID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string Gender { get; set; }
        public string GroupName { get; set; }
    }
}
