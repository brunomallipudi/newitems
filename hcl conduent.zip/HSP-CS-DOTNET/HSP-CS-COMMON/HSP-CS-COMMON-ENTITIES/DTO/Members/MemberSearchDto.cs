﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class MemberSearchDto
    {
        public int? MemberID { get; set; }
        public int? RowId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string MiddleName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string MaritalStatus { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string MBI { get; set; }
        public string PayerMemberNumber { get; set; }
        public string RelationshipToSubscriber { get; set; }
        public string RelationshipCode { get; set; }
        public string GroupName { get; set; }
        public string LOB { get; set; }
        public string DocumentLocation { get; set; }
        public string Language { get; set; }
        public int GroupLevel { get; set; }
        public string Subscriber { get; set; }
        public string SubscriberLname { get; set; }
        public string SubscriberFname { get; set; }
        public string SubscriberMname { get; set; }
        public string SubscriberSSN { get; set; }
        public string SubscriberGender { get; set; }
        public DateTime? SubscriberDOB { get; set; }
        public string SubscriberMedicareNumber { get; set; }
        public string SubscriberMaritalStatus { get; set; }
        public string SubscriberLanguage { get; set; }
        public string MemberNumber { get; set; }
        public MemberAddressDetail[] MemberAddressDetails { get; set; }
        public MemberPhoneDetail[] MemberPhoneDetails { get; set; }
        public MemberSearchOHIDetail[] MemberSearchOHIDetails { get; set; }
        public OHIAddressDetail[] OHIAddressDetails { get; set; }
        public OHIPhoneDetail[] OHIPhoneDetails { get; set; }
        public EventDetail[] EventDetails { get; set; }
        public MemberSearchFileDetail[] MemberSearchFileDetails { get; set; }
        public SubscriberAddressDetail[] SubscriberAddressDetails { get; set; }
        public SubscriberContactDetail[] SubscriberContactDetails { get; set; }
    }

    public class MemberAddressDetail
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
    }
    public class MemberPhoneDetail
    {
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string CellPhone { get; set; }
    }
    public class MemberSearchOHIDetail
    {
        public DateTime? OHIEffectiveDate { get; set; }
        public DateTime? OHIExpirationDate { get; set; }
        public string PayerName { get; set; }
        public string PayerMemberNumber { get; set; }
        public string OHICoverageCode { get; set; }
        public string GroupName { get; set; }
        public string GroupNumber { get; set; }
    }
    public class OHIAddressDetail
    {
        public string PayerAddress1 { get; set; }
        public string PayerAddress2 { get; set; }
        public string PayerCity { get; set; }
        public string PayerState { get; set; }
        public string PayerZip { get; set; }
    }
    public class OHIPhoneDetail
    {
        public string PayerCellPhone { get; set; }
        public string PayerFaxPhone { get; set; }
        public string PayerHomePhone { get; set; }
        public string PayerWorkPhone { get; set; }
        public string PayerWorkPhoneExt { get; set; }
    }
    public class EventDetail
    {
        public string TrackingNumber { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public int? FileID { get; set; }
        public string WorkGroupName { get; set; }
    }
    public class MemberSearchFileDetail
    {
        public string FileName { get; set; }
        public string FileDescription { get; set; }
        public int? DocumentID { get; set; }
    }
    public class SubscriberAddressDetail
    {
        public string SubscriberAddress1 { get; set; }
        public string SubscriberAddress2 { get; set; }
        public string SubscriberCity { get; set; }
        public string SubscriberState { get; set; }
        public string SubscriberZip { get; set; }
    }
    public class SubscriberContactDetail
    {
        public string SubscriberPhone { get; set; }
    }
    public class MemberSearchFileDBResult
    {
        public int? MemberID { get; set; }
        public int? RowId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string MiddleName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string MaritalStatus { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string MBI { get; set; }
        public string PayerName { get; set; }
        public string PayerAddress1 { get; set; }
        public string PayerAddress2 { get; set; }
        public string PayerCity { get; set; }
        public string PayerState { get; set; }
        public string PayerZip { get; set; }
        public string PayerCellPhone { get; set; }
        public string PayerFaxPhone { get; set; }
        public string PayerHomePhone { get; set; }
        public string PayerWorkPhone { get; set; }
        public string PayerWorkPhoneExt { get; set; }
        public DateTime? OHIEffectiveDate { get; set; }
        public DateTime? OHIExpirationDate { get; set; }
        public string OHICoverageCode { get; set; }
        public string RelationshipToSubscriber { get; set; }
        public string RelationshipCode { get; set; }
        public string GroupName { get; set; }
        public string LOB { get; set; }
        public string GroupNumber { get; set; }
        public string TrackingNumber { get; set; }
        public DateTime? FileDateOpened { get; set; }
        public DateTime? FileDateClosed { get; set; }
        public int? FileID { get; set; }
        public string DocumentLocation { get; set; }
        public string OriginalDocumentName { get; set; }
        public string PayerMemberNumber { get; set; }
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string CellPhone { get; set; }
        public string Language { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public int GroupLevel { get; set; }
        public string FileName { get; set; }
        public string FileDescription { get; set; }
        public int? DocumentID { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public string WorkGroupName { get; set; }
        public string SubscriberAddress1 { get; set; }
        public string SubscriberAddress2 { get; set; }
        public string SubscriberCity { get; set; }
        public string SubscriberState { get; set; }
        public string SubscriberZip { get; set; }
        public string SubscriberPhone { get; set; }
        public string Subscriber { get; set; }
        public string SubscriberLname { get; set; }
        public string SubscriberFname { get; set; }
        public string SubscriberMname { get; set; }
        public string SubscriberSSN { get; set; }
        public string SubscriberGender { get; set; }
        public DateTime? SubscriberDOB { get; set; }
        public string SubscriberMedicareNumber { get; set; }
        public string SubscriberMaritalStatus { get; set; }
        public string SubscriberLanguage { get; set; }
        public string MemberNumber { get; set; }
    }
}
