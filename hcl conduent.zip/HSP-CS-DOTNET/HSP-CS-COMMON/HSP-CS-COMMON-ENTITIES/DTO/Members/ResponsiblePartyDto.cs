﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class ResponsiblePartyDto
    {
        public int ResponsiblePartyCoverageMapId { get; set; }
        public string ResponsiblePartyType { get; set; }
        public string ResponsiblePartyTypeName { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public int MemberId { get; set; }
        public int SubscriberContractId { get; set; }
        public int ResponsiblePartyId { get; set; }
        public string HouseholdReferenceNumber { get; set; }
        public string RelationshipCode { get; set; }
        public string Relationship { get; set; }
        public int? MemberCoverageId { get; set; }
        public string GroupNumber { get; set; }
        public string MemberLastName { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberNationalIndividualID { get; set; }
        public string MemberSocialSecurityNumber { get; set; }
        public string MemberGender { get; set; }
        public DateTime? MemberDateOfBirth { get; set; }
        public string MemberAddress { get; set; }
        public string MemberCity { get; set; }
        public string MemberState { get; set; }
        public string MemberZip { get; set; }
        public string MemberHomePhone { get; set; }
        public string MemberWorkPhone { get; set; }
        public string MemberEmail { get; set; }
        public int? ResponsiblePartyMemberCoverageId { get; set; }
        public string ResponsibleLastName { get; set; }
        public string ResponsibleFirstName { get; set; }
        public string ResponsibleNationalIndividualID { get; set; }
        public string ResponsibleSocialSecurityNumber { get; set; }
        public string ResponsibleGender { get; set; }
        public DateTime? ResponsibleDateOfBirth { get; set; }
        public string ResponsibleAddress { get; set; }
        public string ResponsibleCity { get; set; }
        public string ResponsibleState { get; set; }
        public string ResponsibleZip { get; set; }
        public string ResponsibleHomePhone { get; set; }
        public string ResponsibleWorkPhone { get; set; }
        public string ResponsibleEmail { get; set; }
        public string IsResponsiblePersonMember { get; set; }
        public string ResponsiblePartyNodeName { get; set; }
        public int GroupId { get; set; }
        public int? CopyMemberId { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string EntityAccessRolePermission { get; set; }
    }
}
