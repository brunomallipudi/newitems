﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class FindMembersCoveragesV2Dto
    {
        public string MemberNumber { get; set; }
        public string MemberLastName { get; set; }
        public string MemberMiddleInitial { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberPolicyNumber { get; set; }
        public string NationalIndividualId { get; set; }
        public string SSNumber { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string Zip { get; set; }
        public string HomePhone { get; set; }
        public string Relationship { get; set; }
        public string GroupName { get; set; }
        public string SubscriberLastName { get; set; }
        public string SubscriberFirstName { get; set; }
        public string SubscriberName { get; set; }
        public string SubscriberNumber { get; set; }
        public string SubscriberPolicyNumber { get; set; }
        public DateTime? SubscriberDateOfBirth { get; set; }
        public string SubscriberGender { get; set; }
        public int SubscriberId { get; set; }
        public int SubscriberContractId { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string GroupNumber { get; set; }
        public string GroupLineOfBusiness { get; set; }
        public string PlanName { get; set; }
        public string HICN { get; set; }
        public string MBI { get; set; }
        public string HouseHoldReferenceNumber { get; set; }
        public string UseDateOfIncidentForAdjudication { get; set; }
        public int MemberCoverageID { get; set; }
        public int MemberId { get; set; }
        public int GroupId { get; set; }
        public int BasePlanBenefitCoverageId { get; set; }
        public int BasePlanId { get; set; }
        public string MedicareContractID { get; set; }
        public string MedicarePlanID { get; set; }
    }
}
