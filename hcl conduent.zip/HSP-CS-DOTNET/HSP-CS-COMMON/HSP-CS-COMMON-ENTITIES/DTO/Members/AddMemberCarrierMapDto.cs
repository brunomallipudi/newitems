﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class AddMemberCarrierMapDto
    {
        public int? RowID { get; set; }
    }
}
