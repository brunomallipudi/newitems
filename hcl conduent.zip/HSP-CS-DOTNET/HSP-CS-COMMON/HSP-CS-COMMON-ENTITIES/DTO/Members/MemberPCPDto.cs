﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Members
{
    public class MemberPCPDto
    {
        public int MemberProviderId { get; set; }
        public int SubscriberContractId { get; set; }
        public int MemberId { get; set; }
        public int ProviderId { get; set; }
        public int OfficeID { get; set; }
        public int? RiskGroupId { get; set; }
        public int? HospitalId { get; set; }
        public string CapitationType { get; set; }
        public DateTime PCPEffectiveDate { get; set; }
        public DateTime PCPExpirationDate { get; set; }
        public string Precedence { get; set; }
        public string ReasonCode { get; set; }
        public string ProductName { get; set; }
        public string Notes { get; set; }
        public int LastUpdatedById { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string CapitationTypeName { get; set; }
        public string PrecedenceName { get; set; }
        public string ReasonCodeName { get; set; }
        public string ProviderName { get; set; }
        public string ProviderNumber { get; set; }
        public string OfficeName { get; set; }
        public string OfficeNumber { get; set; }
        public string OfficeAddress1 { get; set; }
        public string OfficeAddress2 { get; set; }
        public string OfficeCity { get; set; }
        public string OfficeZip { get; set; }
        public string OfficeState { get; set; }
        public string RiskGroupName { get; set; }
        public string RiskGroupNumber { get; set; }
        public string RiskGroupClass { get; set; }
        public string RiskGroupClassName { get; set; }
        public string RiskGroupSubclass { get; set; }
        public string RiskGroupSubclassName { get; set; }
        public string HospitalName { get; set; }
        public string HospitalNumber { get; set; }
        public string HospitalNPI { get; set; }
        public string ProviderContractNumber { get; set; }
        public string ContactPhone { get; set; }
        public string ContactExt { get; set; }
        public string ContactEmail { get; set; }
        public string ContactFax { get; set; }
        public string LastUpdatedBy { get; set; }
        public int? GroupID { get; set; }
        public string GroupNumber { get; set; }
        public string GroupName { get; set; }
        public string GroupLOB { get; set; }
        public string GroupProductType { get; set; }
        public string GroupProductLine { get; set; }
        public string GroupCoverageCode { get; set; }
        public string AutoAssignment { get; set; }
        public string OverridePCPPanel { get; set; }
        public string OverrideRetroEnrollmentEnforcement { get; set; }
        public string ManuallyAssigned { get; set; }
        public string IsInherited { get; set; }
        public int? ContractId { get; set; }
        public string ContractName { get; set; }
        public string PCPNodeName { get; set; }
        public int? AddedBy { get; set; }
        public string AddedByName { get; set; }
        public DateTime? AddedAt { get; set; }
        public int? TermedBy { get; set; }
        public string TermedByName { get; set; }
        public DateTime? TermedAt { get; set; }
    }
}
