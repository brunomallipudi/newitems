﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Metadata
{
    public class MetadataDto
    {
        public string Name { get; set; }

        public bool Required { get; set; }

        public string DataType { get; set; }

        public int MaxLength { get; set; }
    }
}
