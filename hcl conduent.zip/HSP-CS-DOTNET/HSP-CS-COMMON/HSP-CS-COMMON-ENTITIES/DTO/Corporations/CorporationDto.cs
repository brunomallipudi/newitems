﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Corporations
{
    public class CorporationDto
    {
        public int CorporationId { get; set; }
        public string EIN { get; set; }
        public string EINType { get; set; }
        public string EINTypeName { get; set; }
        public string LegalName { get; set; }
        public int? CorporationDetailID { get; set; }
        public string OtherName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public int? ZipCodeId { get; set; }
        public string County { get; set; }
        public string CountryCode { get; set; }
        public string CountryISOCode2 { get; set; }
        public string CountryISOCode3 { get; set; }
        public double? LATITUDE { get; set; }
        public double? LONGITUDE { get; set; }
        public string ContactName { get; set; }
        public string ContactPhone { get; set; }
        public string ContactExt { get; set; }
        public string ContactEmail { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedByID { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
