﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Claims
{
    public class ClaimActionCodeDto
    {
        public int ClaimActionCodeMapId { get; set; }
        public int ActionCodeId { get; set; }
        public string ActionCodeTypeCode { get; set; }
        public string ActionCode { get; set; }
        public string ActionCodeName { get; set; }
        public string ActionCodeDescription { get; set; }
        public string AllowOverride { get; set; }
        public int ClaimId { get; set; }
        public int? AdjustmentVersion { get; set; }
        public int? LineNumber { get; set; }
        public string Description { get; set; }
        public string Overridden { get; set; }
        public string OverriddenCheckBox { get; set; }
        public string OverrideReason { get; set; }
        public int? ActionEntityMapId { get; set; }
        public int? InitialVersionApplied { get; set; }
        public DateTime? InitialDateApplied { get; set; }
        public string AddedFromCode { get; set; }
        public int LastUpdatedById { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? OverridePermissionId { get; set; }
        public string ClaimHasActionCodes { get; set; }
        public string LastUpdatedBy { get; set; }
        public string ActionCodeType { get; set; }
        public string AddedFrom { get; set; }
        public string EntityType { get; set; }
        public string EntityDescription { get; set; }
    }
}
