﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Claims
{
    public class ClaimIdForNumberDto
    {
        public int ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public string ClaimType { get; set; }
        public string FormType { get; set; }
        public int AdjustmentVersion { get; set; }
        public string Status { get; set; }
        public string ProcessingStatus { get; set; }
        public int? MemberId { get; set; }
        public int? MemberCoverageId { get; set; }
        public int? SubscriberContractId { get; set; }
        public int? SubscriberId { get; set; }
        public int? GroupId { get; set; }
        public int? ProviderId { get; set; }
        public int? VendorId { get; set; }
        public DateTime? ServiceDateFrom { get; set; }
        public DateTime? ServiceDateTo { get; set; }
        public DateTime? DateReceived { get; set; }
        public decimal TotalCharges { get; set; }
        public string  MemberLastName { get; set; }
        public string  MemberFirstName { get; set; }
        public DateTime? MemberDateOfBirth { get; set; }
        public string ProviderLastName { get; set; }
        public string ProviderFirstName { get; set; }
        public string ProviderNumber { get; set; }
        public string VendorName { get; set; }
        public string VendorNumber { get; set; }
        public string ExternalClaimEditing { get; set; }
        public string ClaimStatus { get; set; }
        public string ProcessingStatusName { get; set; }
        public string ExternalClaimNumber { get; set; }
        public string PatientAccountNumber { get; set; }
        public string ReturnDetails { get; set; }
        public string RadiographReferenceNumber { get; set; }
        public int DocumentID { get; set; }
        public string MemberNumber { get; set; }
    }
}
