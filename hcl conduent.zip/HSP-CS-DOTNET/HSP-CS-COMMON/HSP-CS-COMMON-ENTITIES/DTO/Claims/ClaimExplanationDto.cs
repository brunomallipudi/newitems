﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Claims
{
    public class ClaimExplanationDto
    {
        public int ClaimId { get; set; }
        public int AdjustmentVersion { get; set; }
        public int? Line { get; set; }
        public int? LineNumber { get; set; }
        public string Parameter1 { get; set; }
        public string Parameter2 { get; set; }
        public string Parameter3 { get; set; }
        public string Parameter4 { get; set; }
        public string Parameter5 { get; set; }
        public DateTime DateProcessed { get; set; }
        public int? Queue { get; set; }
        public int? Override { get; set; }
        public string Overridden { get; set; }
        public string Description { get; set; }
        public int? ExplanationID { get; set; }
        public string Abbreviation { get; set; }
        public string ExplanationCode { get; set; }
        public string Explanation { get; set; }
        public string ShortExplanation { get; set; }
        public string SortKey { get; set; }
        public string ExplanationPrecedence { get; set; }
        public string AllowOverride { get; set; }
        public string EnableAllowOverride { get; set; }
        public int? OverridePermissionId { get; set; }
        public string PermittedToOverride { get; set; }
        public string Severity { get; set; }
        public int? ExplanationCategoryId { get; set; }
        public string ExplanationCategoryType { get; set; }
        public string AllowUserExplanation { get; set; }
        public string ExplanationCategoryTypeName { get; set; }
        public string ExplanationCategoryName { get; set; }
        public string ExplanationCategoryDescription { get; set; }
        public string ExplanationCategoryPrecedence { get; set; }
        public string ProductName { get; set; }
        public int? ActionCodeId { get; set; }
        public string ActionCode { get; set; }
        public string ActionCodeType { get; set; }
        public string ActionNumber { get; set; }
        public string ActionCodeName { get; set; }
        public string Icon { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public string EntityType { get; set; }
        public int? EntityTypeId { get; set; }
        public int? EntityId { get; set; }
        public string Entity { get; set; }
        public string FastTrackField { get; set; }
    }
}
