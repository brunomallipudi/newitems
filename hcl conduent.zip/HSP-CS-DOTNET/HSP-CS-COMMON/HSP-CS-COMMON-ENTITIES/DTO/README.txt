﻿This namespace contains object that return from
stored procedures (or views) and ARE NOT table rows.