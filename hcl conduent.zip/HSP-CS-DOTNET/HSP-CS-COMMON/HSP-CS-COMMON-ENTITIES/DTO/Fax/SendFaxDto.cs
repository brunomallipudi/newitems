﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.Fax
{
    public class SendFaxDto
    {
        public string Message { get; set; }
    }
}
