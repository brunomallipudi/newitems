﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Departments
{
    public class DepartmentDto
    {
        public int DeptID { get; set; }
        public string DeptName { get; set; }
        public int? ManagerID { get; set; }
        public string Manager { get; set; }
        public string ManagerName { get; set; }
        public string DeptStatus { get; set; }
        public string Status { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedUserName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}
