﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Records
{
    public class RecordDetailDto
    {
        public int? RecordDetailID { get; set; }
        public int RecordID { get; set; }
        public string ItemType { get; set; }
        public string DetailType { get; set; }
        public int LineNumber { get; set; }
        public int ItemID { get; set; }
        public decimal Units { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal? AppliedAmount { get; set; }
        public string ReferenceNumber { get; set; }
        public int? ClaimID { get; set; }
        public string ClaimNumber { get; set; }
        public DateTime? PostDate { get; set; }
        public DateTime? ProcessedDate { get; set; }
        public int? AdjustmentVersion { get; set; }
        public string Notes { get; set; }
        public DateTime? CoveragePeriodStartDate { get; set; }
        public DateTime? CoveragePeriodEndDate { get; set; }
        public int? NumberOfDaysCovered { get; set; }
        public string CheckNumber { get; set; }
        public string ExternalCheckNumber { get; set; }
        public string ExternalCheckCurrency { get; set; }
        public decimal? ExternalCheckAmount { get; set; }
        public decimal? ExternalConversionRate { get; set; }
        public int? GracePeriod { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public string MemberName { get; set; }
        public int? InvoiceRecordID { get; set; }
        public string Status { get; set; }
        public string GroupName { get; set; }
        public string BrokerName { get; set; }
        public string SuspendedCheckNumber { get; set; }
        public int? RateID { get; set; }
        public string GroupRateType { get; set; }
        public string RateTypeName { get; set; }
        public string RateUsage { get; set; }
        public string RateUsageName { get; set; }
        public string RateBillingEntityId { get; set; }
        public string RateBillingEntityName { get; set; }
        public string PayBrokerCommissions { get; set; }
        public int? BillingReferenceID { get; set; }
        public int? TierItemID { get; set; }
        public string TierItemName { get; set; }
        public string RiderName { get; set; }
        public string QualifierName { get; set; }
        public string AppliedLevel { get; set; }
        public string AppliedLevelName { get; set; }
        public decimal? CheckAmount { get; set; }
        public decimal? FundingAmountReq { get; set; }
        public decimal? FundingAmountRcv { get; set; }
        public string UtilizationType { get; set; }
        public string UtilizationTypeName { get; set; }
        public string UtilizationStatus { get; set; }
        public string UtilizationStatusName { get; set; }
        public string FundingType { get; set; }
        public string FundingTypeName { get; set; }
        public string FundingStatus { get; set; }
        public string FundingStatusName { get; set; }
        public int? JobId { get; set; }
    }
}
