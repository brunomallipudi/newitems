﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Records
{
    public class DocumentRequestRecordDto
    {
        public int? RecordId { get; set; }
        public string RecordType { get; set; }
        public string RecordTypeName { get; set; }
        public DateTime? CreationDate { get; set; }
        public string RecordStatus { get; set; }
        public string RecordStatusName { get; set; }
        public string EntityType { get; set; }
        public string EntityTypeName { get; set; }
        public string DocumentTypev { get; set; }
        public string DocumentTypeName { get; set; }
        public int? MemberId { get; set; }
        public int? SubscriberContractId { get; set; }
        public int? MemberCoverageId { get; set; }
        public string MemberLastName { get; set; }
        public string MemberFirstName { get; set; }
        public string MemberNumber { get; set; }
        public int? GroupId { get; set; }
        public string GroupNumber { get; set; }
        public string GroupName { get; set; }
        public int? ProviderId { get; set; }
        public int? OfficeId { get; set;  }
        public int? ReferringProviderId { get; set; }
        public int? ReferringOfficeId { get; set; }
        public int? ReportId { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public int? NumberOfClaims { get; set; }
        public int? JobId { get; set; }
        public string JobNumber { get; set; }
        public string JobStatus { get; set; }
        public string JobStatusName { get; set; }
        public int? JobDetailId { get; set; }
        public int? DocumentID { get; set; }
        public string DocumentNumber { get; set; }
        public string Location { get; set; }
        public string FilePath { get; set; }
        public string FulfillmentMethod { get; set; }
        public string FulfillmentMethodName { get; set; }
        public string JobFulfillmentMethodCode { get; set; }
        public string JobFulfillmentMethod { get; set; }
        public string FulfillmentID { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string FulfillmentStatus { get; set; }
        public string FulfillmentStatusName { get; set; }
        public DateTime? FulfilledAt { get; set; }
        public int? FulfilledBy { get; set; }
        public string FulfilledByName { get; set; }
        public string SuppressionReason { get; set; }
        public string SuppressionReasonName { get; set; }
        public int? ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public int? AdjustmentVersion { get; set; }
        public int? ClaimRedirectAddressId { get; set; }
        public string ClaimRedirectAddressName { get; set; }
        public string Message { get; set; }
        public int? DocumentRequestId { get; set; }
        public string MemberEOBPreference { get; set; }
        public string EmailNotification { get; set; }
    }
}
