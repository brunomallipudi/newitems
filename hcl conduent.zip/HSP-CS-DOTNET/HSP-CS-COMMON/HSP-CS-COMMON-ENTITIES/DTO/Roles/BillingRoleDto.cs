﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Roles
{
    public class BillingRoleDto
    {
        public int BillingRoleID { get; set; }
        public string RoleName { get; set; }
        public string RoleCode { get; set; }
        public string DefaultRole { get; set; }
        public int UserID { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}
