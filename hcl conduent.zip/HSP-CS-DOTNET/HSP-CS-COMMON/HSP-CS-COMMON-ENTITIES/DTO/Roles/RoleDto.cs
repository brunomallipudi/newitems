﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Roles
{
    public class RoleDto
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
        public string RoleStatus { get; set; }
        public string Status { get; set; }
        public string RoleType { get; set; }
        public string RoleSubType { get; set; }
        public string RoleTypeName { get; set; }
        public string RoleSubTypeName { get; set; }
        public string ProfessionalChargesLimit { get; set; }
        public string ProfessionalPaidLimit { get; set; }
        public string InstitutionalChargesLimit { get; set; }
        public string InstitutionalPaidLimit { get; set; }
        public string DentalChargesLimit { get; set; }
        public string DentalPaidLimit { get; set; }
        public string NonMedicalChargesLimit { get; set; }
        public string NonMedicalPaidLimit { get; set; }
        public string DentalESTChargesLimit { get; set; }
        public string DentalESTPaidLimit { get; set; }
        public string RxChargesLimit { get; set; }
        public string RxPaidLimit { get; set; }
        public string BillingRefundCreationLimit { get; set; }
        public string BillingRefundPostingLimit { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}
