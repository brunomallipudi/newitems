﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Providers
{
    public class ProviderCredentialDto
    {
        public int ProviderCredentialID { get; set; }
        public int ProviderID { get; set; }
        public string CredentialType { get; set; }
        public string CredTypeName { get; set; }
        public string CredentialSubType { get; set; }
        public string CredentialEntity { get; set; }
        public string CredSubTypeName { get; set; }
        public string CredentialNumber { get; set; }
        public int? SpecialtyId { get; set; }
        public string SpecialtyName { get; set; }
        public DateTime? CredentialDate { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string State { get; set; }
        public string VerificationSource { get; set; }
        public string VerificationContact { get; set; }
        public DateTime? VerifiedDate { get; set; }
        public int? VerifiedBy { get; set; }
        public DateTime? ReverificationDate { get; set; }
        public string ReferenceNumber { get; set; }
        public string DocumentID { get; set; }
        public string Comments { get; set; }
        public string LastupdatedBy { get; set; }
        public DateTime LastupdatedAt { get; set; }
        public decimal? Amount { get; set; }
        public decimal? TotalAmount { get; set; }
        public int? FacilityID { get; set; }
        public string FacilityName { get; set; }
        public string ProviderName { get; set; }

    }
}
