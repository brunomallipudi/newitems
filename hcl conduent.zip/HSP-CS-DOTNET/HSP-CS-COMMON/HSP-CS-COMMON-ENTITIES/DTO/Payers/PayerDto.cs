﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Payers
{
    public class PayerDto
    {
        public int? PayerId { get; set; }
        public string PayerName { get; set; }
        public string PayerNumberQualifier { get; set; }
        public string PayerNumberQualifierName { get; set; }
        public string PayerNumber { get; set; }
        public string PayerType { get; set; }
        public string PayerTypeName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string Zip { get; set; }
        public int? ZipCodeId { get; set; }
        public string CountryCode { get; set; }
        public string CellPhone { get; set; }
        public string FaxPhone { get; set; }
        public string ContactName { get; set; }
        public string ContactEmail { get; set; }
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string WorkPhoneExt { get; set; }
        public string PCPWaiver { get; set; }
        public string PCPWaiverName { get; set; }
        public string ReferralWaiver { get; set; }
        public string ReferralWaiverName { get; set; }
        public string AuthorizationWaiver { get; set; }
        public string AuthorizationWaiverName { get; set; }
        public string NDCWaiver { get; set; }
        public string NDCWaiverName { get; set; }
        public string PreEstimateWaiver { get; set; }
        public string PreEstimateWaiverName { get; set; }
        public string UPNWaiver { get; set; }
        public string UPNWaiverName { get; set; }
        public string SequestrationCalculation { get; set; }
        public string SequestrationCalculationName { get; set; }
        public double? SequestrationPercentage { get; set; }
        public string LastupdatedBy { get; set; }
        public DateTime LastupdatedAt { get; set; }
        public string PayerDescription { get; set; }

    }
}
