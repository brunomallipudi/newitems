﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Levies
{
    public class LevyDto
    {
        public int LevyId { get; set; }
        public int CorporationId { get; set; }
        public string LevyNumber { get; set; }
        public string ExternalLevyNumber { get; set; }
        public int VendorToPayId { get; set; }
        public string UnitType { get; set; }
        public decimal UnitValue { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public int Precedence { get; set; }
        public string Class { get; set; }
        public string SubClass { get; set; }
        public string Description { get; set; }
        public int LastUpdatedById { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string CorporationLegalName { get; set; }
        public string VendorToPayNumber { get; set; }
        public string VendorToPayName { get; set; }
        public string UnitTypeName { get; set; }
        public string ClassName { get; set; }
        public string SubClassName { get; set; }
        public string LastUpdatedBy { get; set; }
        public Decimal? TotalPaidToDate { get; set; }
    }
}
