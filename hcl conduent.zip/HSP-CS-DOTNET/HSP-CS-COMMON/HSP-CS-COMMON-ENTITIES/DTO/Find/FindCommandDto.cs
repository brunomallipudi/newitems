﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Find
{
    public class FindCommandDto
    {
        public int FindCommandId { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public string Description { get; set; }
        public string Interface { get; set; }
        public string InterfaceUrl { get; set; }
        public string InitUsage { get; set; }
        public string FindUsage { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string CustomAttributeSearchCommand { get; set; }
    }
}