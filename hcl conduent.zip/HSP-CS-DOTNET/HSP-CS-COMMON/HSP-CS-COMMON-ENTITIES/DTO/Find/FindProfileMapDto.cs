﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Find
{
    public class FindProfileMapDto
    {
        public int FindControlId { get; set; }
        public int FindProfileId { get; set; }
        public int FindProfileMapId { get; set; }
        public string Name { get; set; }
        public string Label { get; set; }
        public string ControlType { get; set; }
        public string Visible { get; set; }
        public string Required { get; set; }
        public string DefaultValue { get; set; }
        public string DataType { get; set; }
        public int MinLength { get; set; }
        public int MaxLength { get; set; }
        public string ComboBoxSql { get; set; }
        public string DisplayFieldName { get; set; }
        public string DisplayIDName { get; set; }
        public string LinkTo { get; set; }
        public string LinkFrom { get; set; }
        public string FindDisplayName { get; set; }
        public string FindResultIDName { get; set; }
        public string FindResultDisplayName { get; set; }
        public string FindAllowEdit { get; set; }
        public string FindType { get; set; }
        public string Tooltip { get; set; }
        public int SortKey { get; set; }
        public string ReferenceCodeType { get; set; }
        public string ReferenceCodeSubType { get; set; }
        public string ReferenceCodeClass { get; set; }
        public string MapLabel { get; set; }
        public string MapVisible { get; set; }
        public string MapDefaultValue { get; set; }
        public string MapTooltip { get; set; }
        public int MapSortKey { get; set; }
        public string MapLastUpdatedById { get; set; }
        public DateTime MapLastUpdatedAt { get; set; }
        public string FindCommand { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
