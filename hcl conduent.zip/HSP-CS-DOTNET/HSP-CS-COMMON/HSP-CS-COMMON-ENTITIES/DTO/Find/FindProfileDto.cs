﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Find
{
    public class FindProfileDto
    {
        public int FindProfileId { get; set; }
        public string Name { get; set; }
        public int FindCommandId { get; set; }
        public string Description { get; set; }
        public int SortKey { get; set; }
        public int? OwnerId { get; set; }
        public string StatusCode { get; set; }
        public int LastUpdatedById { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string Owner { get; set; }
        public string Status { get; set; }
        public string FindCommand { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}
