﻿using System;


namespace HSP_CS_COMMON_ENTITIES.DTO.Find
{
    public class FindProfileRoleDto
    {
        public int FindProfileId { get; set; }
        public int FindProfileRoleId { get; set; }
        public int RoleId { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
    }
}
