﻿
namespace HSP_CS_COMMON_ENTITIES.DTO.Email
{
    public class SendMailDto
    {
        public string tempFileName { get; set; }
    }
}
