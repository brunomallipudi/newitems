﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.BenefitPlans
{
    public class BenefitForPlanDto
    {
        public int BnfCategoryID { get; set; }
        public string BnfCategoryType { get; set; }
        public string BnfServiceTypeCode { get; set; }
        public string BnfCategoryTypeName { get; set; }
        public int? BnfCategoryLevel { get; set; }
        public int? ParentID { get; set; }
        public int? PlanID { get; set; }
        public string BnfCategoryName { get; set; }
        public string Description { get; set; }
        public string RateType { get; set; }
        public string RateTypeName { get; set; }
        public string Self { get; set; }
        public string Spouse { get; set; }
        public string Child { get; set; }
        public string Other { get; set; }
        public string AgeType { get; set; }
        public int AgeRangeBegin { get; set; }
        public int AgeRangeEnd { get; set; }
        public int? ContinuousCoveragePeriod { get; set; }
        public int? MinimumCoveragePeriod { get; set; }
        public int LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string ExpenseAccountType { get; set; }
        public string ExpenseAccountTypeName { get; set; }
        public string ExpenseAccountSubType { get; set; }
        public string ExpenseAccountSubTypeName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string AppliedLevel { get; set; }
        public string AppliedLevelName { get; set; }
        public double? SortKey { get; set; }
        public string SummaryOfBenefitsDisplayStatus { get; set; }
        public string Suppress { get; set; } 
        public string Coverage { get; set; }
        public string CoverageName { get; set; }
        public string Coverage2 { get; set; }
        public string Coverage2Name { get; set; }
        public string Coverage3 { get; set; }
        public string Coverage3Name { get; set; }
        public string Coverage4 { get; set; }
        public string Coverage4Name { get; set; }
        public string IncludeInReinsurance { get; set; }
        public string Class { get; set; }
        public string SubClass { get; set; }
        public string BenefitsReportClass { get; set; }
        public string BenefitsReportSubClass { get; set; }
        public string COBConsideration { get; set; }
        public string COBConsiderationName { get; set; }
        public int? LiabilityPackageId { get; set; }
        public int? LiabilityLevelId { get; set; }
        public string LiabilityLevelName { get; set; }
        public string LiabilityPackageName { get; set; }
        public int? EpisodeDays { get; set; }
        public string EpisodeMaxDollars { get; set; }
        public string HasBenefitRestrictions { get; set; } 
        public string HasPreExistingConditions { get; set; } 
        public string HasActionCodes { get; set; }
        public string MemberRelationship { get; set; }
        public string MemberRelationshipName { get; set; }
        public string MemberRelationshipMapping { get; set; }
        public string MemberRelationshipSuppress { get; set; }
    }
}
