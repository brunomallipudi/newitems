﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.EntityData
{
    public class EntityDataDto
    {
        public int EntityId { get; set; }
        public string EntityType { get; set; }
        public int SequenceNumber { get; set; }
        public string SchemaType { get; set; }
        public string DataString { get; set; }
        public int LastUpdateById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string ScreenName { get; set; }
    }
}