﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Demographics
{
    public class DemographicDto
    {
        public string Demographic { get; set; }
    }
}