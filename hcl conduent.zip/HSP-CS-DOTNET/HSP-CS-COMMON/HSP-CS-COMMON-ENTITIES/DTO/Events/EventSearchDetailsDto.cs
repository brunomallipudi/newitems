﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class EventSearchDetailsDto
    {
        public int FileID { get; set; }
        public string TrackingNumber { get; set; }
        public string StatusCode { get; set; }
        public string FileLocation { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public string LOB { get; set; }
        public string ClientName { get; set; }
        public int MemberID { get; set; }
        public int? RowId { get; set; }
        public string MemberName { get; set; }
        public string Subscriber { get; set; }
        public string SubscriberName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string WorkGroupName { get; set; }
        public string MemberNumber { get; set; }
        public OHIDetail[] OHIDetails { get; set; }
        public FileDetail[] FileDetails { get; set; }

    }
    public class OHIDetail
    {
        public string OHINumber { get; set; }
        public DateTime? OHIBeginDate { get; set; }
        public DateTime? OHIEndDate { get; set; }
        public string OHIName { get; set; }
    }
    public class FileDetail
    {
        public string FileName { get; set; }
        public string FileDescription { get; set; }
        public string DocumentID { get; set; }

    }
    public class EventSearchDBResult
    {
        public int FileID { get; set; }
        public string TrackingNumber { get; set; }
        public string StatusCode { get; set; }
        public string FileLocation { get; set; }
        public DateTime? DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public string LOB { get; set; }
        public string ClientName { get; set; }
        public int MemberID { get; set; }
        public int? RowId { get; set; }
        public string MemberName { get; set; }
        public string Subscriber { get; set; }
        public string SubscriberName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string OHINumber { get; set; }
        public DateTime? OHIBeginDate { get; set; }
        public DateTime? OHIEndDate { get; set; }
        public string OHIName { get; set; }
        public string FileName { get; set; }
        public string FileDescription { get; set; }
        public string DocumentID { get; set; }
        public string WorkGroupName { get; set; }
        public string MemberNumber { get; set; }
    }
}
