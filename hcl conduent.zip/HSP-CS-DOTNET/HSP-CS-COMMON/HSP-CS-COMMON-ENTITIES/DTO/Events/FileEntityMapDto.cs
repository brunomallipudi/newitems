﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class FileEntityMapDto
    {
        public int RowId { get; set; }
        public int FileId { get; set; }
        public string EntityType { get; set; }
        public string EntityName { get; set; }
        public int EntityId { get; set; }
        public string Active { get; set; }
        public string LinkedItemName { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public string IndividualType { get; set; }
        public int? IndividualId { get; set; }
        public int? SupplementalId { get; set; }
        public string SupplementalType { get; set; }
        public string SupplementalNumber { get; set; }
        public string SupplementalName { get; set; }
        public string TrackingNumber { get; set; }
        public string Subject { get; set; }
        public string IndividualNumber { get; set; }
        public DateTime? DateOpenedv { get; set; }
        public DateTime? DateClosed { get; set; }
        public int? GroupId { get; set; }
        public int? MemberId { get; set; }
    }
}