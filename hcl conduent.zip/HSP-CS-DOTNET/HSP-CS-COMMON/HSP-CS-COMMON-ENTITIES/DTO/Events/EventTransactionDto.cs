﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class EventTransactionDto
    {
        public int TransactionID { get; set; }
        public int FileID { get; set; }
        public string IndividualCode { get; set; }
        public string IndividualNumber { get; set; }
        public DateTime? DateRequested { get; set; }
        public DateTime DateStarted { get; set; }
        public DateTime DateCompleted { get; set; }
        public string Subject { get; set; }
        public string UserName { get; set; }
        public string TransactionCode { get; set; }
        public string TransactionCodeName { get; set; }
        public string DocumentTypeCode { get; set; }
        public string Location { get; set; }
        public string DocumentNumber { get; set; }
        public string ImageType { get; set; }
        public string DocumentID { get; set; }
        public int? StepId { get; set; }
        public string Description { get; set; }
        public string Email { get; set; }
        public string FaxNumber { get; set; }
        public string FaxContactName { get; set; }
    }
}