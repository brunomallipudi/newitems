﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public  class AdditionalEntityDto
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
