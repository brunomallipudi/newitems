﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class AddTimeItemDto
    {
        public int TimeItemId { get; set; }
    }
}
