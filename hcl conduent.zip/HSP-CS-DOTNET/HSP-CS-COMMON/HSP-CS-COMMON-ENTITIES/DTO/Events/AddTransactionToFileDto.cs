﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
  public  class AddTransactionToFileDto
    {
        public int FileID { get; set; }
        public int? TransactionID { get; set; }
        public int? ParentFileId { get; set; }
        public string AddLetterNext { get; set; }
        public string TrackingNumber { get; set; }
        public DateTime? DateOpened { get; set; }
        public string FileClosed { get; set; }
        public string AutoPrint { get; set; }
        public string DefaultFulfillmentType { get; set; }
        public int? AutoPrintRowId { get; set; }
    }
}
