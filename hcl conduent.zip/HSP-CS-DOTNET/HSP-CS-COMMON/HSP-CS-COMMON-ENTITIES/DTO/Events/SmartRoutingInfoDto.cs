﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class SmartRoutingInfoDto
    {
        public string WorkGroupAbbreviation { get; set; }
        public string StepName { get; set; }
        public string Request { get; set; }
        public string AssignToUsername { get; set; }
        public string EmailList { get; set; }
        public string AllottedTime { get; set; }
        public string CustomAttributesCheck { get; set; }
        public string Error { get; set; }
    }
}
