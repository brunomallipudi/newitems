﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class EventSearchFilter
    {
        public int? FileID { get; set; }
        public string FileStatus { get; set; }
        public DateTime? DateOpened { get; set; }
        public int? IndividualId { get; set; }
        public string IndividualName { get; set; }
        public DateTime? IndividualDOB { get; set; }
        public string Gender { get; set; }
        public string LOB { get; set; }
        public string ClientName { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string TrackingNumber { get; set; }
        public string WorkGroupName { get; set; }
        public string GroupName { get; set; }
        public string MemberNumber { get; set; }
    }
}
