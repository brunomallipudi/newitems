﻿namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class RoutingInfoDto
    {
        public int? WorkGroupID { get; set; }
        public int? StepID { get; set; }
        public int? AssignToUserID { get; set; }
    }
}
