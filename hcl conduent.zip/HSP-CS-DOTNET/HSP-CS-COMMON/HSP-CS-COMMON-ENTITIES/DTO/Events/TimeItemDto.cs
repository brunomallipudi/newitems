﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Events
{
    public class TimeItemDto
    {
        public int TimeItemId { get; set; }
        public int FileId { get; set; }
        public string FileSubject { get; set; }
        public string FileTrackingNumber { get; set; }
        public string FileIndividualType { get; set; }
        public string FileIndividualTypeName { get; set; }
        public int? FileIndividualId { get; set; }
        public string FileIndividualName { get; set; }
        public string FileIndividualNumber { get; set; }
        public int? TimeItemUserId { get; set; }
        public string TimeItemUserName { get; set; }
        public DateTime ItemDate { get; set; }
        public decimal Hours { get; set; }
        public string Description { get; set; }
        public DateTime? ItemDateStartTime { get; set; }
        public string ItemDateStartTimeHHMI { get; set; }
        public string ItemDateStartTimeAMPM { get; set; }
        public DateTime? ItemDateEndTime { get; set; }
        public string ItemDateEndTimeHHMI { get; set; }
        public string ItemDateEndTimeAMPM { get; set; }
        public string BillingCode { get; set; }
        public string BillingCodeName { get; set; }
        public string BillingRole { get; set; }
        public string BillingRoleName { get; set; }
        public string Reviewed { get; set; }
        public string Billed { get; set; }
        public int LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedAt { get; set; }
        public int? GroupId { get; set; }
        public int? MemberId { get; set; }
        public int? SupplementalId { get; set; }
        public string SupplementalType { get; set; }
        public string LocationCode { get; set; }
        public string Location { get; set; }
        public string DescriptionCode { get; set; }
        public string DescriptionCodeName { get; set; }
        public string DescriptionCodeDescription { get; set; }
        public string ContactCategoryName { get; set; }
        public int? ReasonId { get; set; }
        public string ContactReasonName { get; set; }
        public int? ContactReasonStepId { get; set; }
        public string ContactReasonStepName { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string ProductName { get; set; }
        public string ContactCategoryType { get; set; }
    }
}
