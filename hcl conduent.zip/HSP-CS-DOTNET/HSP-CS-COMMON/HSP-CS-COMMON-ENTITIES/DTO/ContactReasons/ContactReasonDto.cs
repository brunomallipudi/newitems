﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ContactReasons
{
    /// <summary>
    /// Contact Reason as it comes out from the stored procedure.
    /// </summary>
    /// <remarks>
    /// The properties with Y|N comments should have been bool (bit in the database)
    /// </remarks>
    public class ContactReasonDto
    {
        public int ReasonId { get; set; }
        public int ContactReasonId { get; set; }
        public string ReasonShortcut { get; set; }
        public string ReasonName { get; set; }
        public string ContactReasonName { get; set; }
        public string Description { get; set; }
        public string Priority { get; set; }
        public string IndividualCode { get; set; }
        public int? DesignatedCloserID { get; set; }

        /// <summary>
        /// Y|N
        /// </summary>
        public string AllowOverride { get; set; }

        public string ReasonStatus { get; set; }

        /// <summary>
        /// Y|N
        /// </summary>
        public string DetailsRequired { get; set; }

        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int ContactCategoryID { get; set; }
        public int CategoryID { get; set; }
        public string ReasonDescription { get; set; }
        public string ReasonScript { get; set; }

        /// <summary>
        /// Y|N
        /// </summary>
        public string AllowTimeforClosedFileEvent { get; set; }

        /// <summary>
        /// Y|N
        /// </summary>
        public string UseReasonNameAsSubject { get; set; }

        public double? SortKey { get; set; }
        public string ReasonClass { get; set; }
        public string ReasonSubclass { get; set; }
        public int? EntityTransformID { get; set; }
        public string EntityTransformName { get; set; }
        public string ContactCategory { get; set; }
    }
}