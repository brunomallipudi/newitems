﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ContactReasons
{
    /// <summary>
    /// Contact Reasons for Step as it comes out from the stored procedure.
    /// </summary>
    public class ContactReasonForStepDto
    {
        public int RowId { get; set; }
        public int ReasonId { get; set; }
        public int StepId { get; set; }
        public int NewReasonId { get; set; }
        public string NewReasonCode { get; set; }
        public string NewReasonName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedBy { get; set; }
    }
}