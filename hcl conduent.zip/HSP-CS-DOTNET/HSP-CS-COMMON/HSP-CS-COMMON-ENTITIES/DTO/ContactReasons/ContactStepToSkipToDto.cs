﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ContactReasons
{
    /// <summary>
    /// Contact Reasons for Step as it comes out from the stored procedure.
    /// </summary>

    public class ContactStepToSkipToDto
    {
        public int ReasonId { get; set; }
        public int StepId { get; set; }
        public string StepName { get; set; }
        public string AllowSkipStep { get; set; }
        public string AllowOverride { get; set; }
        public int WorkGroupID { get; set; }
        public string RequireUserAssignment { get; set; }
        public string AllottedTimeUnitType { get; set; }
        public int? AllottedTimeUnitValue { get; set; }
        public string DelayUnitType { get; set; }
        public int? DelayUnitValue { get; set; }
        public int? FinalStepID { get; set; }
        public string InboundOutboundProcess { get; set; }
        public int? EntityTransformID { get; set; }
        public string Request { get; set; }
   }
}