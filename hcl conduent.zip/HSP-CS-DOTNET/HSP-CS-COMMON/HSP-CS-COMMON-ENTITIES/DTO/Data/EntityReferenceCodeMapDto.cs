﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class EntityReferenceCodeMapDto
    {
        public int EntityReferenceCodeMapID { get; set; }
        public int EntityID { get; set; }
        public string EntityType { get; set; }
        public int ReferenceCodeID { get; set; }
        public string ReferenceCodeType { get; set; }
        public string ReferenceCodeSubType { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime ReferenceCodeEffectiveDate { get; set; }
        public DateTime ReferenceCodeExpirationDate { get; set; }
        public int? SecondaryReferenceCodeID { get; set; }
        public string SecondaryReferenceCodeType { get; set; }
        public string SecondaryReferenceCodeSubType { get; set; }
        public string SecondaryName { get; set; }
        public string SecondaryCode { get; set; }
        public string SecondaryDescription { get; set; }
        public DateTime? SecondaryReferenceCodeEffectiveDate { get; set; }
        public DateTime? SecondaryReferenceCodeExpirationDate { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string LastUpdatedBy { get; set; }
        public int LastUpdatedByID { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}
