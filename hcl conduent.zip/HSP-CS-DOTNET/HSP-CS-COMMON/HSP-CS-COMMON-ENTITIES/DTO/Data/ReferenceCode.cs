﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class ReferenceCode
    {
        public int ReferenceCodeID { get; set; }
        public string Type { get; set; }
        public string SubType { get; set; }
        public string SortKey { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Class { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedID { get; set; }
        public string LastUpdatedBy { get; set; }
        public string FullName { get; set; }
        public string ProductName { get; set; }


    }
}
