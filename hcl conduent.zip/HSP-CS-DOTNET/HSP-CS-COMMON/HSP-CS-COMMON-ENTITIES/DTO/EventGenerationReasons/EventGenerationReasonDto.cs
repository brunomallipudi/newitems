﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.EventGenerationReasons
{
    public  class EventGenerationReasonDto
    {
        public int EventGenerationReasonId { get; set; }
        public string EventGenerationReasonCode { get; set; }
        public string EventGenerationReasonName { get; set; }
        public int? ContactReasonId { get; set; }
        public string ContactReasonName { get; set; }
        public string Required { get; set; }
        public string Locked { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}