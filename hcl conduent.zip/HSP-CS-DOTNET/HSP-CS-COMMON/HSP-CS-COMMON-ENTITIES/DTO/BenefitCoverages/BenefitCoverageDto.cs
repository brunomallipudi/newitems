﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.BenefitCoverages
{
    public class BenefitCoverageDto
    {
        public int BenefitCoverageId { get; set; }
        public int EntityId { get; set; }
        public int EntityTypeId { get; set; }
        public int CoverageEntityId { get; set; }
        public string CoverageEntityType { get; set; }
        public string CoverageType { get; set; }
        public string Name { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string TerminationReason { get; set; }
        public string TerminationReasonName { get; set; }
        public int? TierItemId { get; set; }
        public string TierName { get; set; }
        public string TierCode { get; set; }
        public DateTime? TierAsOfDate { get; set; }
        public string OverrideRetroEnrollmentEnforcement { get; set; }
        public string OverrideTierRestrictions { get; set; }
        public string AppliedLevel { get; set; }
        public string AppliedLevelName { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int LastUpdatedBy { get; set; }
        public string LastUpdatedByName { get; set; }
        public int? SortKey { get; set; }
    }
}
