﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ProcedureCategories
{
    public class ProcedureCategoryDto
    {
        public int ProcedureCategoryID { get; set; }
        public int ParentId { get; set; }
        public string ChildType { get; set; }
        public int ProcedureCategoryLevel { get; set; }
        public string ProcedureCategoryName { get; set; }
        public string ProcedureCategoryDescription { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public double SortKey { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public string LastUpdatedBy { get; set; }
        public string MapStatus { get; set; }
    }
}