﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO
{
    public class ActionCodeDto
    {
        public int ActionCodeId { get; set; }
		
        public string ProductName { get; set; }
		
        public int Precedence { get; set; }
		
        public string ActionCode { get; set; }
		
        public string ActionNumber { get; set; }
		
        public string ActionCodeName { get; set; }
		
        public string NodeDisplay { get; set; }
		
        public string Description { get; set; }
		
        public int LastUpdatedBy { get; set; }
		
        public string LastUpdatedByName { get; set; }
		
        public DateTime LastUpdatedAt { get; set; }
		
        public string ActionCodeType { get; set; }
		
        public string Owner { get; set; }
		
        public int ClientExplanation { get; set; }
		
        public int? ContactReasonId { get; set; }
		
        public string ContactReasonName { get; set; }
		
        public string IndividualCode { get; set; }
		
        public string AdditionalIndividualCode { get; set; }
		
        public string ActionCodeStatus { get; set; }
		
        public string Status { get; set; }
		
        public int CategoryLevel { get; set; }
		
        public string AllowOverride { get; set; }
		
        public string HasEntities { get; set; }
		
        public string ActionCodeClass { get; set; }
		
        public int? OverridePermissionId { get; set; }
		
        public string OverridePermission { get; set; }
		
        public string ExternalRepricingAction { get; set; }
    }
}
