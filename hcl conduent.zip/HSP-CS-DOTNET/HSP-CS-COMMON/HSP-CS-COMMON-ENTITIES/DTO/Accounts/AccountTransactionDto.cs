﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.Accounts
{
    /// <summary>
    /// Account Transaction as it comes out from the stored procedure.
    /// </summary>
    public class AccountTransactionDto
    {
        public int? AccountId { get; set; }
        public string AccountName { get; set; }
        public string AccountTypeCode { get; set; }
        public string AccountType { get; set; }
        public string XactType { get; set; }
        public string XactName { get; set; }
        public string Amount { get; set; }
        public int? BnfAccountId { get; set; }
        public string RemainingBalance { get; set; }
        public int RecordID { get; set; }
        public int? ReferenceNumber { get; set; }
        public string RecordType { get; set; }
        public string RecordTypeName { get; set; }
        public string RecordStatus { get; set; }
        public string RecordStatusName { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? DateRecorded { get; set; }
        public string Notes { get; set; }
        public int? CheckId { get; set; }
        public string CheckNumber { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateVoided { get; set; }
        public string VoidReason { get; set; }
        public DateTime LastUpdatedAt { get; set; }
        public int? LastUpdatedById { get; set; }
        public string LastUpdatedBy { get; set; }
    }
}