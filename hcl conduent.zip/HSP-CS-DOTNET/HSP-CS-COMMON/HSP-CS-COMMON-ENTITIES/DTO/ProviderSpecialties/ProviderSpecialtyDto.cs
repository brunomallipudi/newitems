﻿using System;

namespace HSP_CS_COMMON_ENTITIES.DTO.ProviderSpecialties
{
    public class ProviderSpecialtyDto
    {
        public int? ProviderSpecialtyCategoryMapId { get; set; }
        public int? ProviderSpecialtyCategoryId { get; set; }
        public int? ProviderSpecialtySubCategoryId { get; set; }
        public int ProviderSpecialtyId { get; set; }
        public string SpecialtyName { get; set; }
        public string SpecialtyNameTaxonomy { get; set; }
        public string SpecialtyDescription { get; set; }
        public int? ParentId { get; set; }
        public string DisplayName { get; set; }
        public string SpecialtyStatus { get; set; }
        public int? SpecialtyStatusSort { get; set; }
        public int? SortKey { get; set; }
        public string CategoryName { get; set; }
        public int CategorySort { get; set; }
        public string SubCategoryName { get; set; }
        public int SubCategorySort { get; set; }
        public int ProviderSpecialtySort { get; set; }
        public string TaxonomyCode { get; set; }
        public string AlternateCode1 { get; set; }
        public string AlternateCode2 { get; set; }
        public string CertificationBoard { get; set; }
        public string PrimaryCare { get; set; }
        public int LastUpdatedByID { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }
}