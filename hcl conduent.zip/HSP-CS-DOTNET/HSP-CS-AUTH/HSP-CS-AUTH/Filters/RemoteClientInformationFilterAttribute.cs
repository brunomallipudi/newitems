﻿using HSP_CS_AUTH.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace HSP_CS_AUTH.Filters
{
    public class RemoteClientInformationFilterAttribute
        : IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            // Any controller that inhertis from BaseController
            var controller = context.Controller as BaseController;

            if (controller != null)
            {
                var remoteClient = controller.RemoteClient;

                remoteClient.IPAddress =
                    context.HttpContext.Connection
                        .RemoteIpAddress.ToString();

                remoteClient.Port =
                    context.HttpContext.Connection
                        .RemotePort;

                remoteClient.ConnectionId =
                    context.HttpContext.Connection.Id;
            }
        }
    }
}