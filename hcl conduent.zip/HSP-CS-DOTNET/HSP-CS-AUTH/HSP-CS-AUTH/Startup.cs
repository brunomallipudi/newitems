using HSP_CS_AUTH.Filters;
using HSP_CS_AUTH.Services.Interfaces;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_HELPERS.Caching;
using HSP_CS_COMMON_HELPERS.Security;
using HSP_CS_COMMON_REPOSITORIES.Implementation;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Implementation.Cache;
using HSP_CS_COMMON_SERVICES.Implementation.Infrastructure;
using HSP_CS_COMMON_SERVICES.Implementation.Permissions;
using HSP_CS_COMMON_SERVICES.Implementation.Security;
using HSP_CS_COMMON_SERVICES.Implementation.Sessions;
using HSP_CS_COMMON_SERVICES.Implementation.TableIds;
using HSP_CS_COMMON_SERVICES.Interfaces.Cache;
using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using HSP_CS_COMMON_SERVICES.Interfaces.Permissions;
using HSP_CS_COMMON_SERVICES.Interfaces.Security;
using HSP_CS_COMMON_SERVICES.Interfaces.Sessions;
using HSP_CS_COMMON_SERVICES.Interfaces.TableIds;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace HSP_CS_AUTH
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime.
        // Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();

            services.AddScoped<RemoteClientInformationFilterAttribute>();
            services.AddScoped<EnforceHSPPermissionsAttribute>();

            services.AddTransient<IJwtService, JwtService>();
            services.AddSingleton<IDbConnectionString>(new DbConnectionString(Configuration.GetConnectionString("HSPCSUIDB")));

            services.AddTransient<IAuthenticationService, Services.Implementation.OpenIAM.AuthenticationService>();
            services.AddTransient<IAuthenticationUserService, Services.Implementation.OpenIAM.AuthenticationUserService>();
            services.AddTransient<IAuthenticationTokenService, Services.Implementation.OpenIAM.AuthenticationTokenService>();

            services.AddScoped<ITableIdsRepository, TableIdsRepository>();
            services.AddScoped<ITableIdsService, TableIdsService>();

            //////////////////////////////////////////////////////////////////////////////
            /// HSP Session Management
            /// 
            /// SessionsRepositoryCore  => EF
            /// SessionsRepository      => Stored Procedure
            /// services.AddScoped<ISessionsRepository, SessionsRepository>();
            services.AddScoped<ISessionsRepository, SessionsRepositoryCore>();
            services.AddScoped<ISessionsService, SessionsService>();
            //////////////////////////////////////////////////////////////////////////////
            
            services.AddScoped<IPermissionsRepository, PermissionsRepository>();
            services.AddScoped<IPermissionsService, PermissionsService>();
            services.AddScoped<IRouteInfoService, RouteInfoService>();

            JwtServiceHelper.AddJwtAuthentication(Configuration, services);

            //////////////////////////////////////////////////////////////////////////////
            /// CACHING & DISTRIBUTED CACHING
            /// 
            /// If we want to use local memory cache, then we can simply
            /// use the following code.
            /// @LocalCache
            /// services.AddTransient<ICacheService, MemoryCacheService>();
            /// 
            /// Comment out if using local.
            /// Can also use distributed, with MEMORY option; see appsettings.json
            /// 
            /// Note: these options work for other APIs provided you have a complete
            /// configuration.
            CachingServiceHelper.AddCacheConfiguration(Configuration, services);
            services.AddTransient<ICacheService, DistributedCacheService>();
            //////////////////////////////////////////////////////////////////////////////
            

            // Entity Framework
            services.AddDbContext<HSPDbContext>(
                options => options.UseSqlServer(Configuration.GetConnectionString("HSPCSUIDB"))
            );

            services
                .AddControllers(
                    config =>
                    {
                        config.Filters.Add(new RemoteClientInformationFilterAttribute());
                    }
                )
                .AddNewtonsoftJson(x => { x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore; });

            services.AddSwaggerGen(c => 
            { 
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "HSP_CS_AUTH", Version = "v1" });

                var securityScheme = new OpenApiSecurityScheme
                {
                    Name = "JWT token",
                    Description = "Enter JWT Bearer token",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    Reference = new OpenApiReference
                    {
                        Id = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme,
                        Type = ReferenceType.SecurityScheme
                    }
                };

                c.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {securityScheme, new string[] { }}
                });
            });

            services.AddHttpClient();
        }

        // This method gets called by the runtime.
        // Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "HSP_CS_AUTH v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors
            (
                x => x
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .SetIsOriginAllowed(origin => true)
                    .AllowCredentials()
            );
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });
        }
    }
}