﻿using HSP_CS_AUTH.Helpers;
using HSP_CS_AUTH.Models.Entities.Common;
using HSP_CS_AUTH.Services.Interfaces;
using HSP_CS_COMMON_SERVICES.Interfaces.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Controllers
{
    /// <summary>
    /// Auth Token Controller
    /// </summary>
    /// <remarks>
    /// Contains auth token related methods.
    /// </remarks>
    [ApiController]
    [Route("[controller]/[action]")]
    public class TokenController 
        : BaseController
    {
        #region Properties

        private readonly IAuthenticationTokenService _authenticationTokenService;
        private readonly IAuthenticationUserService _authenticationUserService;
        private readonly IJwtService _jwtService;

        #endregion Properties

        #region Constructors

        public TokenController(
            IAuthenticationTokenService authenticationTokenService,
            IAuthenticationUserService authenticationUserService,
            IJwtService jwtService)
        {
            _authenticationTokenService = authenticationTokenService;
            _authenticationUserService = authenticationUserService;
            _jwtService = jwtService;
        }

        #endregion Constructors

        /// <summary>
        /// Retrieves Token Information for a given access token.
        ///
        /// If Expired is FALSE, the rest of the properties are populayed/
        /// If Expired is TRUE, the rest of the propererties are not set.
        ///
        /// 3rd party services errors - 500/401 etc - will always set Expired
        /// as TRUE and skip everything else.
        /// </summary>
        /// <param name="token">Access token to get info for</param>
        /// <returns>TokenInfoResult Object</returns>
        [HttpGet]
        public async Task<TokenInfoResult> Info(string token)
        {
            using (TokenInfoResult infoResult = new TokenInfoResult { })
            {
                var reqResponseObj = await _authenticationTokenService.Info(token);
                infoResult.AccessToken = reqResponseObj.AccessToken;
                infoResult.UserId = reqResponseObj.UserId;
                infoResult.ClientId = reqResponseObj.ClientId;
                infoResult.Expired = reqResponseObj.Expired;
                infoResult.Scopes = reqResponseObj.Scopes;
                infoResult.ExpiresOn = reqResponseObj.ExpiresOn;
                infoResult.ExpiresInSeconds = reqResponseObj.ExpiresIn;

                return infoResult;
            }
        }

        /// <summary>
        /// Refreshes a valid auth token (against a 3rd party provider) and returns
        /// an AuthResult object containing properties for consumption from
        /// other applicates/APIs.
        ///
        /// Returns new
        /// -- Access Token
        /// -- Bearer Token for internal services
        /// -- Refresh Token
        /// </summary>
        /// <param name="postdata"></param>
        /// <returns>HSP AuthResult Object.</returns>
        [HttpGet]
        public async Task<AuthResult> Refresh(string token, string username)
        {
            using (AuthResult authResult = new AuthResult { })
            {
                var reqResponseObj = await _authenticationTokenService.Refresh(token);

                if (String.IsNullOrEmpty(reqResponseObj.AccessToken))
                    authResult.ErrorType = "Invalid Refresh Token Provided";

                authResult.AccessToken = reqResponseObj.AccessToken;
                authResult.RefreshToken = reqResponseObj.RefreshToken;
                authResult.ExpiresInSeconds = reqResponseObj.ExpiresIn;

                if (authResult.Success)
                {
                    var userInfo = await _authenticationUserService.GetUserInfo(reqResponseObj.AccessToken);

                    var claims = new List<Claim>();
                    claims.Add(ClaimsHelper.CreateClaim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                    claims.Add(ClaimsHelper.CreateClaim("Valid", "1"));
                    claims.Add(ClaimsHelper.CreateClaim("userId", userInfo.UserId));
                    claims.Add(ClaimsHelper.CreateClaim("username", username));
                    claims.Add(ClaimsHelper.CreateClaim("email", userInfo.EmailAddress));

                    authResult.Data = _jwtService.Issue(claims, authResult.ExpirationDateTime);
                }

                return authResult;
            }
        }

        /// <summary>
        /// Retrieves Token Validation Information for a given token token.
        /// </summary>
        /// <remarks>
        /// This method requires an authenticated browser session against OpenIAM
        /// </remarks>
        /// <param name="token">token to validate</param>
        /// <returns>TokenValidateResult Object</returns>
        [HttpGet]
        public async Task<TokenValidateResult> Validate(string token)
        {
            using (TokenValidateResult result = new TokenValidateResult { })
            {
                var reqResponseObj = await _authenticationTokenService.Validate(token);
                result.StatusCode = reqResponseObj.Code;
                result.ErrorMessage = reqResponseObj.ErrorDescription;
                result.ErrorType = reqResponseObj.Error;

                return result;
            }
        }

        /// <summary>
        /// Revokes a given token token.
        /// </summary>
        /// <remarks>
        /// This method requires an authenticated browser session against OpenIAM
        /// </remarks>
        /// <param name="token">Token to revoke</param>
        /// <returns>TokenRevokeResult Object</returns>
        [HttpGet]
        public async Task<TokenRevokeResult> Revoke(string token)
        {
            using (TokenRevokeResult result = new TokenRevokeResult { })
            {
                var reqResponseObj = await _authenticationTokenService.Revoke(token);
                result.StatusCode = reqResponseObj.Code;
                result.ErrorMessage = reqResponseObj.ErrorDescription;
                result.ErrorType = reqResponseObj.Error;
                result.Failure = reqResponseObj.Failure;
                result.Success = reqResponseObj.Success;

                return result;
            }
        }
    }
}