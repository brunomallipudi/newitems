﻿using HSP_CS_COMMON_CORE.SessionHandling.Implementation;
using HSP_CS_COMMON_SERVICES.Interfaces.Sessions;
using HSP_CS_COMMON_SERVICES.Request.Sessions;
using HSP_CS_COMMON_SERVICES.Response.Sessions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]/[action]")]
    public class SessionsController
        : BaseController
    {
        #region Properties

        private readonly ISessionsService _sessionService;

        #endregion Properties

        #region Constructors

        public SessionsController(ISessionsService sessionService)
        {
            _sessionService = sessionService;
        }

        #endregion Constructors

        /// <summary>
        /// This endpoint attempts to connect a user and get a SessionId from the database.
        /// </summary>
        /// <param name="postdata">
        /// </param>
        /// <returns>
        ///     ConnectUserResponse that contains the necessary values for the consumer
        /// </returns>
        /// <remarks>
        /// If the user is attempting to connect with DisconnectOldSession TRUE
        /// when there are no active sessions, the response will always be Success FALSE
        /// and the SessionId returned will be 0.
        /// </remarks>
        [HttpPost]
        public async Task<ConnectUserResponse> ConnectUser(ConnectUserRequest postdata)
        {
            using (ConnectUserResponse result = new ConnectUserResponse { })
            {
                var sessionResult =
                    await _sessionService.ConnectUserAsync
                    (
                        postdata.Username,
                        postdata.DisconnectOldSession ?? false,
                        postdata.WebSessionId
                    );

                result.Status = sessionResult.StatusRow.StatusRow;
                result.HSPSession =
                    new HSPSession
                    (
                        sessionResult.StatusRow.StatusRow.SessionId,
                        result.Status.UserId
                    );

                if (!result.Status.Success)
                {
                    result.HSPSession = null;
                    result.ResultSet = sessionResult.results;
                }

                return result;
            }
        }

        /// <summary>
        /// This endpoint will attempt to invalidate/disconnect a SessionId from the database.
        /// This can be called on the logout process.
        ///
        /// Returns
        ///     true; when sessionId exists and is active
        ///     false; when sessionId does not exist, or exists and is already inactive.
        /// </summary>
        /// <param name="sessionId">Database provided SessionId</param>
        /// <returns>bool</returns>
        [HttpGet]
        public async Task<DisconnectUserResponse> DisconnectUser(int sessionId)
        {
            using (var result = new DisconnectUserResponse { })
            {
                result.Success =
                    await _sessionService.DisconnectUserAsync(sessionId);

                return result;
            }
        }
    }
}