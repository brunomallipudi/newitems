﻿using HSP_CS_AUTH.Helpers;
using HSP_CS_AUTH.Models.Entities.Common;
using HSP_CS_AUTH.Models.ViewModels.Auth;
using HSP_CS_AUTH.Services.Interfaces;
using HSP_CS_COMMON_SERVICES.Interfaces.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Controllers
{
    /// <summary>
    /// Authentication Controller
    /// </summary>
    /// <remarks>
    /// Contains Authentication related methods.
    /// </remarks>
    [ApiController]
    [Route("[controller]/[action]")]
    public class AuthenticationController 
        : BaseController
    {
        #region Properties

        private readonly IAuthenticationService _authenticationService;
        private readonly IAuthenticationUserService _authenticationUserService;
        private readonly IAuthenticationTokenService _authenticationTokenService;
        private readonly IJwtService _jwtService;

        #endregion Properties

        #region Constructors

        public AuthenticationController(
            IAuthenticationService authenticationService,
            IAuthenticationUserService authenticationUserService,
            IAuthenticationTokenService authenticationTokenService,
            IJwtService jwtService)
        {
            _authenticationService = authenticationService;
            _authenticationUserService = authenticationUserService;
            _authenticationTokenService = authenticationTokenService;
            _jwtService = jwtService;
        }

        #endregion Constructors

        /// <summary>
        /// Authenticates the user against an identity provider and returns
        /// an AuthResult object containing properties for consumption from
        /// other applicates/APIs.
        /// </summary>
        /// <param name="postdata"></param>
        /// <returns>HSP AuthResult Object.</returns>
        [HttpPost]
        public async Task<AuthResult> Login(LoginViewModel postdata)
        {
            using (AuthResult authResult = new AuthResult { })
            {
                var reqResponseObj = await _authenticationService.Authenticate(postdata);

                authResult.ErrorMessage = reqResponseObj.ErrorDescription;
                authResult.ErrorType = reqResponseObj.Error;
                authResult.AccessToken = reqResponseObj.AccessToken;
                authResult.RefreshToken = reqResponseObj.RefreshToken;
                authResult.ExpiresInSeconds = reqResponseObj.ExpiresIn;

                if (authResult.Success)
                {
                    var userInfo = await _authenticationUserService.GetUserInfo(reqResponseObj.AccessToken);

                    var claims = new List<Claim>();
                    claims.Add(ClaimsHelper.CreateClaim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                    claims.Add(ClaimsHelper.CreateClaim("Valid", "1"));
                    claims.Add(ClaimsHelper.CreateClaim("userId", userInfo.UserId));
                    claims.Add(ClaimsHelper.CreateClaim("username", postdata.Username));
                    claims.Add(ClaimsHelper.CreateClaim("email", userInfo.EmailAddress));

                    authResult.Data = _jwtService.Issue(claims, authResult.ExpirationDateTime);
                }

                return authResult;
            }
        }

        /// <summary>
        /// Authenticates the user against an identity provider and returns
        /// an authresult by using an existing valid access token, a username and a 
        /// refresh token.
        /// </summary>
        /// <remarks>
        /// We are assuming here that a refresh token is required, and that it
        /// has been stored in the application prior to its expiration.
        /// </remarks>
        /// <param name="postdata">AuthResult</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<AuthResult> TokenLogin(TokenLoginViewModel postdata)
        {
            using (AuthResult authResult = new AuthResult { })
            {
                var valTokenResponse =
                    await _authenticationTokenService
                        .Validate(postdata.AccessToken);

                if (valTokenResponse.Success)
                {
                    // We can also do a paranoid check against the provided username/userId
                    // and the response we get from the auth provider.
                    var tokenInfoResponse =
                        await _authenticationTokenService
                            .Info(postdata.AccessToken);

                    var userInfo = 
                        await _authenticationUserService
                            .GetUserInfo(postdata.AccessToken);

                    var claims = new List<Claim>();
                    claims.Add(ClaimsHelper.CreateClaim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                    claims.Add(ClaimsHelper.CreateClaim("Valid", "1"));
                    claims.Add(ClaimsHelper.CreateClaim("userId", userInfo.UserId));
                    claims.Add(ClaimsHelper.CreateClaim("username", postdata.Username));
                    claims.Add(ClaimsHelper.CreateClaim("email", userInfo.EmailAddress));

                    authResult.AccessToken = postdata.AccessToken;
                    authResult.RefreshToken = postdata.RefreshToken;
                    authResult.ExpiresInSeconds = tokenInfoResponse.ExpiresIn;
                    authResult.Data = _jwtService.Issue(claims, DateTime.Now.AddSeconds(tokenInfoResponse.ExpiresIn));
                }
                else
                {
                    authResult.ErrorMessage = "Invalid Access Token Provided.";
                    authResult.ErrorType = "Invalid Request";
                    authResult.ExpiresInSeconds = 0;
                }

                return authResult;
            }
        }

        /// <summary>
        /// Logs a user out
        ///
        /// If an access token gets provided, we invalidate it on the authentication
        /// provider. If one is not present, it will expire at some point.
        /// </summary>
        /// <remarks>
        /// We can introduce paranoia checking here by utilizing the provided username
        /// and checking the access token info for a match.
        /// </remarks>
        /// <param name="postdata"></param>
        /// <returns>AuthResult</returns>
        [HttpPost]
        public async Task<AuthResult> Logout(LogoutViewModel postdata)
        {
            using (AuthResult authResult = new AuthResult { })
            {
                // Fire & Forget
                if (!string.IsNullOrEmpty(postdata.AccessToken))
                    await _authenticationTokenService.Revoke(postdata.AccessToken);

                return authResult;
            }
        }
    }
}