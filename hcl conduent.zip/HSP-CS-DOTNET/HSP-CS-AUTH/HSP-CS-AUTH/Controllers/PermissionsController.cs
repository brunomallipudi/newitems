﻿using HSP_CS_COMMON_ENTITIES.DTO.Permissions;
using HSP_CS_COMMON_SERVICES.Implementation.Permissions;
using HSP_CS_COMMON_SERVICES.Interfaces.Permissions;
using HSP_CS_COMMON_SERVICES.Request;
using HSP_CS_COMMON_SERVICES.Request.Permissions;
using HSP_CS_COMMON_SERVICES.Response.Search;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Controllers
{
    /// <summary>
    /// Permissions Controller
    ///
    /// Responsible for handling the user permissions
    /// </summary>
    [Authorize]
    [ApiController]
    [Route("[controller]/[action]")]
    public class PermissionsController
        : BaseController
    {

        #region Properties

        private readonly IPermissionsService _permissionsService;
        private readonly string CACHE_KEY_TAG = "PERMS";

        #endregion Properties

        #region Constructors

        public PermissionsController(IPermissionsService permissionsService)
            => _permissionsService = permissionsService;

        #endregion Constructors

        /// <summary>
        /// Returns a list of user permissions.
        /// </summary>
        /// <param name="getPermissionsRequest"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> GetPermissions(GetPermissionsRequest getPermissionsRequest)
        {
            using (var actionResult = new ListResponse<UserPermission>())
            {
                var result =
                    await _permissionsService
                        .GetPermissionsAsync(getPermissionsRequest, CACHE_KEY_TAG);

                actionResult.Status = result.statusRow.StatusRow;
                actionResult.ResultSet1 = result.results;

                return Ok(actionResult);
            }
        }

        /// <summary>
        /// Sample call to demonstrate HSP Permissions
        /// </summary>
        /// <param name="getPermissionsRequest"></param>
        /// <returns></returns>
        [HttpPost]
        [EnforceHSPPermissions]
        public IActionResult SampleAuthorizeCall(BaseRequest request)
            => new JsonResult(new { Ok = "SampleAutorizeCall" });
    }
}