﻿using HSP_CS_AUTH.Filters;
using HSP_CS_AUTH.Models.Entities.Auth;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Controllers
{
    [Route("[controller]/[action]")]
    public class BaseController
        : ControllerBase
    {
        public RemoteClient RemoteClient = 
            new RemoteClient { };

        [HttpGet]
        public async Task<RemoteClient> RemoteClientInformation() 
            => await Task.FromResult(RemoteClient);
    }
}
