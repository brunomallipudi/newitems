﻿using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using HSP_CS_COMMON_SERVICES.Interfaces.Permissions;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace HSP_CS_AUTH.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class RouteInfoController
        : BaseController
    {
        private readonly IPermissionsService _permissionsService;
        private readonly IRouteInfoService _routeInfoService;

        #region Constructors

        public RouteInfoController(IPermissionsService permissionsService, IRouteInfoService routeInfoService)
        {
            _permissionsService = permissionsService;
            _routeInfoService = routeInfoService;
        }

        #endregion Constructors

        /// <summary>
        /// Returns a list of unmapped permissions/routes
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetMissingPermissionMappings()
            => new JsonResult(_permissionsService.GetMissingPermissionMappings(Assembly.GetExecutingAssembly()));

        /// <summary>
        /// Returns a JsonResult with complete route info for the executing assembly
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetRouteInfo()
            => new JsonResult(_permissionsService.GetRouteInfo(Assembly.GetExecutingAssembly()));
    }
}