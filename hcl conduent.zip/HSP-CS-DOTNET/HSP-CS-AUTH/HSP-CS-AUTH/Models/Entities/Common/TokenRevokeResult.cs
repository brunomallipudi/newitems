﻿namespace HSP_CS_AUTH.Models.Entities.Common
{
    /// <summary>
    /// HSP Token Revoke Result
    /// </summary>
    /// <remarks>
    /// Wrapper object returned to the user after any token revoke request.
    /// </remarks>
    public class TokenRevokeResult : BaseEntity
    {
        /// <summary>
        /// Holds HttpStatusCodes
        /// </summary>
        public int StatusCode { get; set; }

        public string Status { get; set; }

        /// <summary>
        /// Error Message
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Error Type
        /// </summary>
        public string ErrorType { get; set; }

        public bool Failure { get; set; }

        public bool Success { get; set; }
    }
}