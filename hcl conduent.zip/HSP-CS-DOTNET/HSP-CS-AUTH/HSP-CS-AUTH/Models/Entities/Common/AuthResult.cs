﻿using System;

namespace HSP_CS_AUTH.Models.Entities.Common
{
    /// <summary>
    /// HSP Authentication Result
    /// </summary>
    /// <remarks>
    /// Wrapper object returned to the user after any authentication request.
    /// </remarks>
    public class AuthResult : BaseEntity
    {
        /// <summary>
        /// JWT Token data \ Bearer-Token
        ///
        /// Use to authorize access to our internal services.
        /// Pass into the header request.
        /// </summary>
        public string Data { get; set; }

        /// <summary>
        /// Used to make further requests to the provider.
        /// </summary>
        public string AccessToken { get; set; }

        /// <summary>
        /// Error Message
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Error Type
        /// </summary>
        public string ErrorType { get; set; }

        /// <summary>
        /// Seconds until expiration
        /// </summary>
        public int ExpiresInSeconds { get; set; }

        /// <summary>
        /// Used to refresh current provided token.
        /// </summary>
        public string RefreshToken { get; set; }

        /// <summary>
        /// Sets a DateTime to be consumed by the clients based on
        /// the expiration in seconds provided by the auth provider.
        /// </summary>
        public DateTime ExpirationDateTime
            => DateTime.Now.AddSeconds(ExpiresInSeconds);

        /// <summary>
        /// Sets success/failure of the request based on the
        /// error type.
        /// </summary>
        public bool Success
            => string.IsNullOrEmpty(ErrorType);
    }
}