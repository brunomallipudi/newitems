﻿using System;
using System.Collections.Generic;

namespace HSP_CS_AUTH.Models.Entities.Common
{
    /// <summary>
    /// HSP Token Info Result
    /// </summary>
    /// <remarks>
    /// Wrapper object returned to the user after any token info request.
    /// </remarks>
    public class TokenInfoResult : BaseEntity
    {
        /// <summary>
        /// Calculates the offset based on the provided UNIX timestamp
        /// and returns a DateTime object.
        ///
        /// Defaults to 1970-01-01 for invalid requests.
        /// </summary>
        public DateTime ExpiresOnDateTime =>
            DateTimeOffset
                .FromUnixTimeMilliseconds(ExpiresOn)
                .DateTime;

        /// <summary>
        /// The 3rd party service UserId associated with
        /// the access token we are checking.
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Whether the token has expired or not.
        /// </summary>
        public bool Expired { get; set; }

        /// <summary>
        /// ClientId, as set in the authentiction provider.
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// The Access Token being validated.
        /// </summary>
        public string AccessToken { get; set; }

        public int ExpiresInSeconds { get; set; }

        /// <summary>
        /// UNIX Timestamp
        /// </summary>
        public long ExpiresOn { get; set; }

        public List<ScopeResult> Scopes { get; set; }
    }
}