﻿namespace HSP_CS_AUTH.Models.Entities.Common
{
    /// <summary>
    /// HSP Token Validation Result
    /// </summary>
    /// <remarks>
    /// Wrapper object returned to the user after any token validation request.
    /// </remarks>
    public class TokenValidateResult : BaseEntity
    {
        /// <summary>
        /// Holds HttpStatusCodes
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// Error Message
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Error Type
        /// </summary>
        public string ErrorType { get; set; }

        /// <summary>
        /// Sets success/failure of the request based on the
        /// error type.
        /// </summary>
        public bool Success
            => string.IsNullOrEmpty(ErrorType);

        /// <summary>
        /// Sets success/failure of the request based on the
        /// status code.
        /// </summary>
        public bool Valid
            => StatusCode == 200;
    }
}