﻿using System;

namespace HSP_CS_AUTH.Models.Entities.Common
{
    /// <summary>
    /// Base Entity
    /// </summary>
    /// <remarks>
    /// We primarily use this to force the IDisposable implementation
    /// to all classes inheriting it.
    ///
    /// Enables us to do using(){ }
    /// </remarks>
    public class BaseEntity : IDisposable
    {
        public void Dispose()
        {
        }
    }
}