﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;

namespace HSP_CS_AUTH.Models.Entities.Common
{
    public class ScopeResult
    {
        public string ScopeId { get; set; }

        public string Name { get; set; }

    }
}