﻿namespace HSP_CS_AUTH.Models.Entities.Auth
{
    public class RemoteClient
    {
        public string ConnectionId { get; set; }
        public string IPAddress { get; set; }
        public int Port { get; set; }
    }
}