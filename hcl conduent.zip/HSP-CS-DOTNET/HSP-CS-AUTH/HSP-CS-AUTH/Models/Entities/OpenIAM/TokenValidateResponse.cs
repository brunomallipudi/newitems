﻿using Newtonsoft.Json;

namespace HSP_CS_AUTH.Models.Entities.OpenIAM
{
    /// <summary>
    /// OpenIAM TokenValidate Response
    /// </summary>
    /// <remarks>
    /// Maps to the JSON response from the OpeinIAM token
    /// validation request.
    /// </remarks>
    public class TokenValidateResponse
    {
        /// <summary>
        /// Holds HttpStatusCodes
        /// </summary>
        [JsonProperty("code")]
        public int Code { get; set; }

        /// <summary>
        /// Type of Error
        /// Example: invalid_request
        /// </summary>
        [JsonProperty("error")]
        public string Error { get; set; }

        /// <summary>
        /// Detailed error message \ description
        /// Example: Authentication fails for given username and password.
        /// </summary>
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Whether the response was successful or not.
        /// </summary>
        public bool Success
            => string.IsNullOrEmpty(Error) && Code == 200;
    }
}