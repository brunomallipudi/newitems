﻿using Newtonsoft.Json;

namespace HSP_CS_AUTH.Models.Entities.OpenIAM
{
    /// <summary>
    /// OpenIAM Token Revoke Response
    ///
    /// This is partial mapping.
    /// </summary>
    public class TokenRevokeResponse
    {
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("code")]
        public int Code { get; set; }

        [JsonProperty("error")]
        public string Error { get; set; }

        [JsonProperty("error_text")]
        public string ErrorDescription { get; set; }

        [JsonProperty("failure")]
        public bool Failure { get; set; }

        [JsonProperty("success")]
        public bool Success { get; set; }
    }
}