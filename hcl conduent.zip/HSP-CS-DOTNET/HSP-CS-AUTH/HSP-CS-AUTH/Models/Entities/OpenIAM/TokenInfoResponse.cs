﻿using HSP_CS_AUTH.Models.Entities.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace HSP_CS_AUTH.Models.Entities.OpenIAM
{
    /// <summary>
    /// OpenIAM TokenInfo response
    /// </summary>
    /// <remarks>
    /// This object binds specifically to the OpenIAM JSON response
    /// when we request TokenInfo
    /// </remarks>
    public class TokenInfoResponse
    {
        /// <summary>
        /// OpenIAM returns the following
        /// - Int32 for sysadmin
        /// - Guid  for newly created users.
        /// </summary>
        [JsonProperty("user_id")]
        public string UserId { get; set; }

        [JsonProperty("expired")]
        public bool Expired { get; set; }

        [JsonProperty("client_id")]
        public string ClientId { get; set; }

        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonProperty("expires_on")]
        public long ExpiresOn { get; set; }

        [JsonProperty("scopes")]
        public List<ScopeResult> Scopes { get; set; }
    }
}