﻿using HSP_CS_AUTH.Models.Entities.Common;
using Newtonsoft.Json;

namespace HSP_CS_AUTH.Models.Entities.OpenIAM
{
    /// <summary>
    /// OpenIAM Auth Response
    /// </summary>
    /// <remarks>
    /// Maps to the JSON response from the OpeinIAM authentication
    /// request.
    /// </remarks>
    public class AuthResponse
    {
        /// <summary>
        /// OAuth Token
        /// </summary>
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Type of Error
        /// Example: invalid_request
        /// </summary>
        [JsonProperty("error")]
        public string Error { get; set; }

        /// <summary>
        /// Detailed error message \ description
        /// Example: Authentication fails for given username and password.
        /// </summary>
        [JsonProperty("error_description")]
        public string ErrorDescription { get; set; }

        /// <summary>
        /// Number of seconds until token expiration.
        /// </summary>
        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }

        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }

        /// <summary>
        /// Token Type
        /// </summary>
        [JsonProperty("token_type")]
        public string TokenType { get; set; }
    }
}