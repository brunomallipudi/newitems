﻿using HSP_CS_AUTH.Models.Entities.Common;
using Newtonsoft.Json;

namespace HSP_CS_AUTH.Models.Entities.OpenIAM
{
    public class TokenRefreshResponse
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        /// <summary>
        /// Number of seconds until token expiration.
        /// </summary>
        [JsonProperty("expires_in")]
        public int ExpiresIn { get; set; }

        /// <summary>
        /// Token Type
        /// </summary>
        [JsonProperty("token_type")]
        public string TokenType { get; set; }

        [JsonProperty("refresh_token")]
        public string RefreshToken { get; set; }
    }
}