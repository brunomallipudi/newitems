﻿using HSP_CS_AUTH.Models.Entities.Common;
using Newtonsoft.Json;

namespace HSP_CS_AUTH.Models.Entities.OpenIAM
{
    /// <summary>
    /// OpenIAM UserInfo response
    /// </summary>
    /// <remarks>
    /// This object binds specifically to the OpenIAM JSON response
    /// when we request UserInfo
    /// </remarks>
    public class UserInfoResponse
    {
        /// <summary>
        /// OpenIAM returns the following
        /// - Int32 for sysadmin
        /// - Guid  for newly created users.
        /// </summary>
        [JsonProperty("sub")]
        public string UserId { get; set; }

        [JsonProperty("email")]
        public string EmailAddress { get; set; }
    }
}