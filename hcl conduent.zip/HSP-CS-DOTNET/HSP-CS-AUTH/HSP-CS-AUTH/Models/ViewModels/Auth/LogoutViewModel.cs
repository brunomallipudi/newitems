﻿using HSP_CS_AUTH.Models.ViewModels.Common;
using System.ComponentModel.DataAnnotations;

namespace HSP_CS_AUTH.Models.ViewModels.Auth
{
    /// <summary>
    /// Logout ViewModel
    /// </summary>
    public class LogoutViewModel : BaseViewModel
    {
        /// <summary>
        /// AccessToken to invalidate, if present
        /// </summary>
        public string AccessToken { get; set; }

        /// <summary>
        /// The logged on username.
        /// </summary>
        [Required]
        public string Username { get; set; }
    }
}