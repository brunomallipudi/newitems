﻿using HSP_CS_AUTH.Models.ViewModels.Common;
using System.ComponentModel.DataAnnotations;

namespace HSP_CS_AUTH.Models.ViewModels.Auth
{
    /// <summary>
    /// Login ViewModel
    /// </summary>
    /// <remarks>
    /// Binds to the POST body from the UI request.
    /// </remarks>
    public class LoginViewModel : BaseViewModel
    {
        /// <summary>
        /// Provided password.
        /// </summary>
        [Required]
        public string Password { get; set; }

        /// <summary>
        /// Provided username.
        /// </summary>
        [Required]
        public string Username { get; set; }
    }
}