﻿using HSP_CS_AUTH.Models.ViewModels.Common;
using System.ComponentModel.DataAnnotations;

namespace HSP_CS_AUTH.Models.ViewModels.Auth
{
    /// <summary>
    /// TokenLogin ViewModel
    /// </summary>
    /// <remarks>
    /// Binds to the POST body from the UI request.
    /// </remarks>
    public class TokenLoginViewModel : BaseViewModel
    {
        /// <summary>
        /// Existing AccessToken to validate
        /// </summary>
        [Required]
        public string AccessToken { get; set; }

        /// <summary>
        /// Existing RefreshToken
        /// 
        /// This cannot be validated, but is required in order to use
        /// the refresh endpoints
        /// </summary>
        [Required]
        public string RefreshToken { get; set; }

        /// <summary>
        /// The username logged on in the application
        /// </summary>
        [Required]
        public string Username { get; set; }
    }
}