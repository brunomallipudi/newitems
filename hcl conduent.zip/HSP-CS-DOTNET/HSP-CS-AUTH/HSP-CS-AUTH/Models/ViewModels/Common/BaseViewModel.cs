﻿using System;

namespace HSP_CS_AUTH.Models.ViewModels.Common
{
    /// <summary>
    /// Base ViewModel
    /// </summary>
    /// <remarks>
    /// We primarily use this to force the IDisposable implementation
    /// to all classes inheriting it.
    ///
    /// Enables us to do using(){ }
    /// </remarks>
    public class BaseViewModel : IDisposable
    {
        public void Dispose()
        {
        }
    }
}