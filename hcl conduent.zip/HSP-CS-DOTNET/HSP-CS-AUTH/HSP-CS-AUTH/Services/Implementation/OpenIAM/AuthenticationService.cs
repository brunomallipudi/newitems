﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;
using HSP_CS_AUTH.Models.ViewModels.Auth;
using HSP_CS_AUTH.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Services.Implementation.OpenIAM
{
    /// <summary>
    /// Authentication Service - OpenIAM
    ///
    /// Attempts to authenticate against the OpenIAM authentication provider
    /// with a username/password combination.
    /// </summary>
    /// <remarks>
    /// </remarks>
    public class AuthenticationService : IAuthenticationService
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;
        private List<KeyValuePair<string, string>> FormContent;
        private readonly ILogger<AuthenticationService> _logger;

        public AuthenticationService(IConfiguration config, IHttpClientFactory httpClientFactory, ILogger<AuthenticationService> logger)
        {
            _configuration = config;
            _httpClientFactory = httpClientFactory;
            FormContent = new List<KeyValuePair<string, string>>();
            _logger = logger;
        }

        /// <summary>
        /// Authenticates against OpenIAM
        /// </summary>
        /// <param name="postdata"></param>
        /// <returns>HSP Authentication Result Object</returns>
        /// <remarks>
        /// This method also utilizes the AuthenticationUserService to
        /// fetch some metadata after a successful authentication request.
        /// See inline code for details.
        ///
        /// Throws an HttpRequestException if the request returns anything
        /// other than a OK 20x response.
        /// </remarks>
        public async Task<AuthResponse> Authenticate(LoginViewModel postdata)
        {
            var reqResponseObj = new AuthResponse { };
            string authUrl =
                string.Format("{0}{1}",
                    _configuration.GetValue<string>("OpenIAMBaseURL"),
                    _configuration.GetValue<string>("OpenIAMAuthURL")
                );

            PopulateFormContent(postdata);

            using (var client = _httpClientFactory.CreateClient())
            {
                var result =
                   await client.PostAsync
                   (
                       authUrl,
                       new FormUrlEncodedContent(FormContent.ToArray())
                   );

                if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    throw new HttpRequestException("Unable to complete request.");

                string resultContent = await result.Content.ReadAsStringAsync();
                reqResponseObj = JsonConvert.DeserializeObject<AuthResponse>(resultContent);
            }

            try
            {
                _logger.LogInformation("AuthenticationService.Authenticate Method gets called at " + DateTime.Now + " With below information", "");
                _logger.LogInformation("Username:" + postdata.Username);
                _logger.LogInformation("ErrorDescription:" + reqResponseObj.ErrorDescription);
                _logger.LogInformation("Error:" + reqResponseObj.Error);
                _logger.LogInformation("AccessToken:" + reqResponseObj.AccessToken);
                _logger.LogInformation("RefreshToken:" + reqResponseObj.RefreshToken);
                _logger.LogInformation("ExpiresIn:" + reqResponseObj.ExpiresIn);
                _logger.LogInformation("ExpirationDateTime:" + DateTime.Now.AddSeconds(reqResponseObj.ExpiresIn));
            }
            catch (Exception ex)
            {
                _logger.LogInformation("AuthenticationService.Authenticate Method Exception:" + ex.Message);
            }

            return reqResponseObj;

        }

        #region Private Methods

        /// <summary>
        /// Populate the FormContent for the request.
        /// </summary>
        /// <remarks>
        /// Removes clutter from implementation
        /// </remarks>
        /// <param name="postdata"></param>
        private void PopulateFormContent(LoginViewModel postdata)
        {
            FormContent.Add(
                new KeyValuePair<string, string>
                (
                    _configuration.GetValue<string>("OpenIAMClientSecretKey"),
                    _configuration.GetValue<string>("OpenIAMClientSecretValue")
                )
            );

            FormContent.Add(
                new KeyValuePair<string, string>
                (
                    _configuration.GetValue<string>("OpenIAMClientIdKey"),
                    _configuration.GetValue<string>("OpenIAMClientIdValue")
                )
            );

            FormContent.Add(
                new KeyValuePair<string, string>
                (
                    _configuration.GetValue<string>("OpenIAMGrantTypeKey"),
                    _configuration.GetValue<string>("OpenIAMGrantTypeValue")
                )
            );

            FormContent.Add(new KeyValuePair<string, string>("username", postdata.Username));
            FormContent.Add(new KeyValuePair<string, string>("password", postdata.Password));
        }

        #endregion Private Methods
    }
}