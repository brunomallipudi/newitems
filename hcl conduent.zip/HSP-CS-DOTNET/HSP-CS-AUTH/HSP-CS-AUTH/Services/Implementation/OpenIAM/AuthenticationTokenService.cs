﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;
using HSP_CS_AUTH.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace HSP_CS_AUTH.Services.Implementation.OpenIAM
{
    /// <summary>
    /// Token Service - OpenIAM
    /// </summary>
    /// <remarks>
    /// Contains methods to communicate with OpenIAM to retrieve
    /// token information, refresh a token etc.
    /// </remarks>
    public class AuthenticationTokenService : IAuthenticationTokenService
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<AuthenticationTokenService> _logger;

        public AuthenticationTokenService(IConfiguration config, IHttpClientFactory httpClientFactory, ILogger<AuthenticationTokenService> logger)
        {
            _configuration = config;
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        /// <summary>
        /// Retrieves information for a token
        /// </summary>
        /// <remarks>
        /// OpenIAM Returns 200 OK
        /// -- token is valid
        /// -- token has just expired (to the second)
        /// OpenIAM Returns 401 Unauthorized
        /// -- token has expired
        /// OpenIAM Returns 500 Bad Request
        /// -- token is invalid for whatever reason.
        ///
        /// We do not expose the user to misconfiguration or other
        /// server side specific error messages. The consumer needs
        /// to check the Expired flag only.
        /// </remarks>
        /// <param name="token">Auth token to check</param>
        /// <returns>TokenInfoResponse</returns>
        public async Task<TokenInfoResponse> Info(string token)
        {
            var reqResponseObj = new TokenInfoResponse { };

            string infoUrl =
                string.Format("{0}{1}",
                    _configuration.GetValue<string>("OpenIAMBaseURL"),
                    _configuration.GetValue<string>("OpenIAMTokenInfoURL")
                );

            var builder = new UriBuilder(infoUrl);
            var query = HttpUtility.ParseQueryString(builder.Query);
            query["token"] = token;
            builder.Query = query.ToString();
            string url = builder.ToString();

            using (var client = _httpClientFactory.CreateClient())
            {
                var result = await client.GetAsync(url);

                string resultContent = await result.Content.ReadAsStringAsync();
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                    reqResponseObj = JsonConvert.DeserializeObject<TokenInfoResponse>(resultContent);

                if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    reqResponseObj.Expired = true;
            }

            try
            {
                _logger.LogInformation("AuthenticationTokenService.Info Method gets called at " + DateTime.Now + " With below information", "");
                _logger.LogInformation("AccessTokenReceivedInParam:"+ token);
                _logger.LogInformation("AccessTokenfromreqResponseObj:" + reqResponseObj.AccessToken);
                _logger.LogInformation("Clientid:" + reqResponseObj.ClientId);
                _logger.LogInformation("Expired:" + reqResponseObj.Expired);
                _logger.LogInformation("ExpiresIn:" + reqResponseObj.ExpiresIn);
                _logger.LogInformation("ExpirationDateTime:" + DateTime.Now.AddSeconds(reqResponseObj.ExpiresIn));
                _logger.LogInformation("ExpiresOn:" + reqResponseObj.ExpiresOn);
                _logger.LogInformation("Userid:" + reqResponseObj.UserId);               

            }
            catch (Exception ex)
            {
                _logger.LogInformation("AuthenticationTokenService.Info Method Exception:" + ex.Message);
            }

            return reqResponseObj;
        }

        /// <summary>
        /// Refreshes an Access Token via a Refresh Token
        /// </summary>
        /// <remarks>
        /// Only works of the Authentication Provider has been set up to
        /// allow for Refresh Tokens.
        ///
        /// If there is an error, the response status code is 400.
        /// </remarks>
        /// <param name="token">Refresh Token</param>
        /// <returns>TokenRefreshResponse</returns>
        public async Task<TokenRefreshResponse> Refresh(string token)
        {
            var reqResponseObj = new TokenRefreshResponse { };

            string url =
                string.Format("{0}{1}",
                    _configuration.GetValue<string>("OpenIAMBaseURL"),
                    _configuration.GetValue<string>("OpenIAMTokenRefreshURL")
                );

            var FormContent = new List<KeyValuePair<string, string>>();
            FormContent.Add(new KeyValuePair<string, string>("refresh_token", token));

            using (var client = _httpClientFactory.CreateClient())
            {
                var result =
                    await client.PostAsync
                    (
                        url,
                        new FormUrlEncodedContent(FormContent.ToArray())
                    );

                if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    throw new HttpRequestException("Unable to complete request.");

                string resultContent = await result.Content.ReadAsStringAsync();
                reqResponseObj = JsonConvert.DeserializeObject<TokenRefreshResponse>(resultContent);

                try
                {
                    _logger.LogInformation("AuthenticationTokenService.Refresh Method gets called at " + DateTime.Now + " With below information", "");                    
                    _logger.LogInformation("AccessTokenReceivedInParam:" + token);
                    _logger.LogInformation("AccessTokenfromreqResponseObj:" + reqResponseObj.AccessToken);
                    _logger.LogInformation("RefreshToken:" + reqResponseObj.RefreshToken);
                    _logger.LogInformation("ExpiresIn:" + reqResponseObj.ExpiresIn);
                    _logger.LogInformation("ExpirationDateTime:" + DateTime.Now.AddSeconds(reqResponseObj.ExpiresIn));
                }
                catch (Exception ex)
                {
                    _logger.LogInformation("AuthenticationTokenService.Refresh Method Exception:"+ ex.Message);
                }

                return reqResponseObj;
            }
        }

        /// <summary>
        /// Retrieves validity information for an OpenIAM created token
        /// </summary>
        /// <remarks>
        /// OpenIAM Returns Code 200 OK
        /// -- token is valid
        /// OpenIAM Returns 401 Unauthorized
        /// -- token does not exist
        ///
        /// </remarks>
        /// <param name="token">Auth token to check</param>
        /// <returns>TokenValidateResponse</returns>
        public async Task<TokenValidateResponse> Validate(string token)
        {
            var reqResponseObj = new TokenValidateResponse { };

            string infoUrl =
                string.Format("{0}{1}",
                    _configuration.GetValue<string>("OpenIAMBaseURL"),
                    _configuration.GetValue<string>("OpenIAMTokenValidateURL")
                );

            var builder = new UriBuilder(infoUrl);
            var query = HttpUtility.ParseQueryString(builder.Query);
            query["token"] = token;
            builder.Query = query.ToString();
            string url = builder.ToString();

            using (var client = _httpClientFactory.CreateClient())
            {
                var result = await client.GetAsync(url);

                string resultContent = await result.Content.ReadAsStringAsync();
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                    reqResponseObj = JsonConvert.DeserializeObject<TokenValidateResponse>(resultContent);
            }

            try
            {
                _logger.LogInformation("AuthenticationTokenService.Validate Method gets called at " + DateTime.Now + " With below information", "");
                _logger.LogInformation("Code:" + reqResponseObj.Code);
                _logger.LogInformation("AccessTokenReceivedInParam:" + token);
                _logger.LogInformation("Error:" + reqResponseObj.Error);
                _logger.LogInformation("ErrorDescription:" + reqResponseObj.ErrorDescription);
                _logger.LogInformation("Success:" + reqResponseObj.Success);             

            }
            catch (Exception ex)
            {
                _logger.LogInformation("AuthenticationTokenService.Validate Method Exception:" + ex.Message);
            }

            return reqResponseObj;
        }

        /// <summary>
        /// Revokes an OpenIAM created token
        /// </summary>
        /// <param name="token">Auth token to revoke</param>
        /// <returns>TokenRevokeResponse</returns>
        public async Task<TokenRevokeResponse> Revoke(string token)
        {
            var reqResponseObj = new TokenRevokeResponse { };

            string infoUrl =
                string.Format("{0}{1}",
                    _configuration.GetValue<string>("OpenIAMBaseURL"),
                    _configuration.GetValue<string>("OpenIAMTokenRevokeURL")
                );

            var builder = new UriBuilder(infoUrl);
            var query = HttpUtility.ParseQueryString(builder.Query);
            query["token"] = token;
            query["token_type_hint"] = "access_token";
            builder.Query = query.ToString();
            string url = builder.ToString();

            using (var client = _httpClientFactory.CreateClient())
            {
                var result = await client.GetAsync(url);

                string resultContent = await result.Content.ReadAsStringAsync();
                try
                {
                    // if it is an invalid token that has been provided
                    // the authentication provider attempts to redirect to
                    // the provider's login page.
                    //
                    // This would throw an exception.
                    reqResponseObj = JsonConvert.DeserializeObject<TokenRevokeResponse>(resultContent);
                }
                catch (Exception)
                {
                    reqResponseObj.Success = true;
                    reqResponseObj.Failure = false;
                    reqResponseObj.ErrorDescription = "Invalid Token provided; Assuming Revoke Success.";
                }

                try
                {
                    _logger.LogInformation("AuthenticationTokenService.Revoke Method gets called at " + DateTime.Now + " With below information", "");
                    _logger.LogInformation("AccessTokenReceivedInParam:" + token);
                    _logger.LogInformation("Code:" + reqResponseObj.Code);
                    _logger.LogInformation("Error:" + reqResponseObj.Error);
                    _logger.LogInformation("ErrorDescription:" + reqResponseObj.ErrorDescription);
                    _logger.LogInformation("Faliure:" + reqResponseObj.Failure);
                    _logger.LogInformation("Status:" + reqResponseObj.Status);
                    _logger.LogInformation("Success:" + reqResponseObj.Success);

                }
                catch (Exception ex)
                {
                    _logger.LogInformation("AuthenticationTokenService.Revoke Method Exception:" + ex.Message);
                }

                return reqResponseObj;
            }
        }
    }
}