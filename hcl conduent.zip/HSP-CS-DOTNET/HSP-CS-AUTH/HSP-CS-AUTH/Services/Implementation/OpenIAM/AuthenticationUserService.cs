﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;
using HSP_CS_AUTH.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace HSP_CS_AUTH.Services.Implementation.OpenIAM
{
    /// <summary>
    /// Authentication User Service - OpenIAM
    /// </summary>
    /// <remarks>
    ///  Fetches metadata for a user from the OpenIAM auth provider.
    ///  The provider currently returns an emailAddress and a userId.
    /// </remarks>
    public class AuthenticationUserService : IAuthenticationUserService
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<AuthenticationUserService> _logger;

        public AuthenticationUserService(IConfiguration config, IHttpClientFactory httpClientFactory, ILogger<AuthenticationUserService> logger)
        {
            _configuration = config;
            _httpClientFactory = httpClientFactory;
            _logger = logger;
        }

        /// <summary>
        /// Returns an object containing parsed metadata from OpenIAM
        /// </summary>
        /// <param name="token">AccessToken; provided by the OpenIAM authentication service</param>
        /// <returns></returns>
        public async Task<UserInfoResponse> GetUserInfo(string token)
        {
            UserInfoResponse reqResponseObj = new UserInfoResponse { };

            string infoUrl =
                string.Format("{0}{1}",
                    _configuration.GetValue<string>("OpenIAMBaseURL"),
                    _configuration.GetValue<string>("OpenIAMUserInfoURL")
                );

            var builder = new UriBuilder(infoUrl);
            var query = HttpUtility.ParseQueryString(builder.Query);
            query["token"] = token;
            builder.Query = query.ToString();
            string url = builder.ToString();

            using (var client = _httpClientFactory.CreateClient())
            {
                var result = await client.GetAsync(url);

                if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    throw new HttpRequestException("Unable to complete request.");

                string resultContent = await result.Content.ReadAsStringAsync();
                reqResponseObj = JsonConvert.DeserializeObject<UserInfoResponse>(resultContent);
            }

            try
            {
                _logger.LogInformation("AuthenticationUserService.GetUserInfo Method gets called at " + DateTime.Now + " With below information", "");
                _logger.LogInformation("UserId:" + reqResponseObj.UserId );
                _logger.LogInformation("EmailAddress:" + reqResponseObj.EmailAddress);                
            }
            catch (Exception ex)
            {
                _logger.LogInformation("AuthenticationUserService.GetUserInfo Method Exception:" + ex.Message);
            }

            return reqResponseObj;
        }
    }
}