﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Services.Interfaces
{
    public interface IAuthenticationTokenService
    {
        /// <summary>
        /// Get Token Info
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<TokenInfoResponse> Info(string token);

        /// <summary>
        /// Refresh a token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<TokenRefreshResponse> Refresh(string token);

        /// <summary>
        /// Validate a token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<TokenValidateResponse> Validate(string token);

        /// <summary>
        /// Revoke a token
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<TokenRevokeResponse> Revoke(string token);
    }
}