﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Services.Interfaces
{
    /// <summary>
    /// AuthenticationUserService Interface
    /// </summary>
    /// <remarks>
    /// Describes methods that can be used to fetch user info and/or metadata from
    /// an authentication provider.
    /// </remarks>
    public interface IAuthenticationUserService
    {
        /// <summary>
        /// Returns User Info metadata based on an access token provided.
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<UserInfoResponse> GetUserInfo(string token);
    }
}