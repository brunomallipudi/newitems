﻿using HSP_CS_AUTH.Models.Entities.OpenIAM;
using HSP_CS_AUTH.Models.ViewModels.Auth;
using System.Threading.Tasks;

namespace HSP_CS_AUTH.Services.Interfaces
{
    /// <summary>
    /// AuthenticationService Interface
    /// </summary>
    /// <remarks>
    /// All authentication services must implement the defined methods, as a minimum.
    /// </remarks>
    public interface IAuthenticationService
    {
        /// <summary>
        /// Authenticates the user against an authentication provider
        /// </summary>
        /// <param name="postdata">
        /// Minimum required parameters for the authentication provider;
        /// username/password combination
        /// </param>
        /// <returns></returns>
        Task<AuthResponse> Authenticate(LoginViewModel postdata);
    }
}