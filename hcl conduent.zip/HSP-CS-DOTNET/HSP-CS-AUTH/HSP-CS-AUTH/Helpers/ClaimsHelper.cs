﻿#nullable enable

using System.Security.Claims;

namespace HSP_CS_AUTH.Helpers
{
    /// <summary>
    /// Claims Helper
    /// </summary>
    /// <remarks>
    /// Contains methods that help with Claim CRUD operations.
    /// </remarks>
    public static class ClaimsHelper
    {
        /// <summary>
        /// Create a claim to be passed into our bearer token.
        ///
        /// If a value is null, we are adding the key with a string.Empty value. The applications
        /// need to be able to handle the values in the keys, not the keys.
        /// </summary>
        /// <param name="key">Key; must be unique</param>
        /// <param name="value">Value; it can be null or an empty string.</param>
        /// <returns></returns>
        public static Claim CreateClaim(string key, string? value) =>
            new Claim
            (
                key,
                value != null       // not all users are configured equally.
                    ? value
                    : string.Empty
            );
    }
}