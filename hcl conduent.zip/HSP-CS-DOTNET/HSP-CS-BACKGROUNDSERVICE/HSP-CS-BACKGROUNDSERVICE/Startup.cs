using HSP_CS_BACKGROUNDSERVICE;
using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Implementation;
using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Helpers;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Implementation;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_REPOSITORIES.Implementation;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Implementation.Infrastructure;
using HSP_CS_COMMON_SERVICES.Implementation.Security;
using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using HSP_CS_COMMON_SERVICES.Interfaces.Security;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace HSP_CS_BACKGROUNDSERVICE_API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }
        
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();

            services.AddSingleton<IDbConnectionString>(new DbConnectionString(Configuration.GetConnectionString("HSPCSUIDB")));            
            services.AddSingleton<ICryptography, AESCryptographyService>();            
            services.AddSingleton<IBatchQueueService, BatchQueueService>();
            services.AddSingleton<IReportQueueService, ReportQueueService>();
            services.AddSingleton<IReportQueueRepository, ReportQueueRepository>();
            services.AddSingleton<IBatchQueueRepository, BatchQueueRepository>();
            services.AddSingleton<IFormLettersRepository, FormLettersRepository>();
            services.AddSingleton<IUserReportsRepository, UserReportsRepository>();
            services.AddSingleton<HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface.IRepository, HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Implementation.Repository>();
            services.AddSingleton<IFileServerService, NetworkConnection>(); 
            services.AddSingleton<IReportsRepository, ReportsRepository>();            
            services.AddSingleton<IHostedService, BackGroundServices>();

            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddSingleton<IUrlHelper>(x =>
            {
                var actionContext = x.GetRequiredService<IActionContextAccessor>().ActionContext;
                var factory = x.GetRequiredService<IUrlHelperFactory>();
                return factory.GetUrlHelper(actionContext);
            });
            
            //Entity Framework
            services.AddDbContext<HSPDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("HSPCSUIDB")), ServiceLifetime.Transient, ServiceLifetime.Singleton);
            
            services.AddHttpClient();
            services.AddAutoMapper(typeof(Startup));          

            services.AddControllers()
                    .AddNewtonsoftJson();

            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {                
            }
            app.UseExceptionHandler("/error");            
        }
    }
}
