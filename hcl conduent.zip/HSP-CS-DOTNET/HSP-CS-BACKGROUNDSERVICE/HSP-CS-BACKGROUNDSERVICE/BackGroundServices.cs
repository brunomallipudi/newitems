﻿using Confluent.Kafka;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE
{
    /// <summary>
    /// Back Ground Service
    /// Configured with Kafka
    /// </summary>
    public class BackGroundServices : IHostedService
    {
        private readonly IBatchQueueService _batchQueueService;
        private readonly IReportQueueService _reportQueueService;
        private readonly ILogger<BackGroundServices> _logger;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Back Ground Services
        /// </summary>
        /// <param name="batchQueueService"></param>
        /// <param name="reportQueueService"></param>
        /// <param name="logger"></param>
        public BackGroundServices(IBatchQueueService batchQueueService, 
                                    IReportQueueService reportQueueService, 
                                    ILogger<BackGroundServices> logger,
                                    IConfiguration configuration)
        {
            _batchQueueService = batchQueueService;
            _reportQueueService = reportQueueService;
            _logger = logger;
            _configuration = configuration;
        }        

        /// <summary>
        /// Start Async
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task StartAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine("StartAsync Start");
                
            _logger.LogInformation("StartAsync Start");            
            Thread StartReportProcess = new Thread(StartReportConsumer)
            {
                Name = "StartReportProcess"
            };
            Thread StartBatchProcess = new Thread(StartBatchConsumer)
            {
                Name = "StartBatchProcess"
            };

            StartReportProcess.Start();
            StartBatchProcess.Start();

            return Task.CompletedTask; 
        }

        /// <summary>
        /// Start Batch Consumer
        /// </summary>
        private void StartBatchConsumer()
        {
            _logger.LogInformation("StartBatchConsumer Start");
            var conf = new ConsumerConfig
            {
                GroupId = _configuration["HSP-CS-KAFKA-Settings:BatchGroupID"],
                BootstrapServers = _configuration["HSP-CS-KAFKA-Settings:BootstrapServers"],
                AutoOffsetReset = AutoOffsetReset.Earliest
            };

            using (var builder = new ConsumerBuilder<Ignore, string>(conf).Build())
            {
                builder.Subscribe(_configuration["HSP-CS-KAFKA-Settings:BatchTopic"]);
                var cancelToken = new CancellationTokenSource();
                while (true)
                {
                    var consumer = builder.Consume(cancelToken.Token);
                    try
                    {                        
                        _logger.LogInformation($"Message: {consumer.Message.Value} received from {consumer.Topic}");
                        BatchQueueProcessRequest request = JsonConvert.DeserializeObject<BatchQueueProcessRequest>(consumer.Message.Value);
                        _batchQueueService.BatchQueueProcess(request);
                    }
                    catch (Exception exception)
                    {
                        builder.Close();
                        _logger.LogError($"Exception in {nameof(StartBatchConsumer)}.", exception);
                        Console.WriteLine($"Exception Message : {exception.Message}");
                    }
                }
            }
        }

        /// <summary>
        /// Start Report Consumer
        /// </summary>
        private void StartReportConsumer()
        {
            _logger.LogInformation("StartReportConsumer Start");
            var conf = new ConsumerConfig
            {
                GroupId = _configuration["HSP-CS-KAFKA-Settings:ReportGroupID"],
                BootstrapServers = _configuration["HSP-CS-KAFKA-Settings:BootstrapServers"],
                AutoOffsetReset = AutoOffsetReset.Earliest
            };

            using (var builder = new ConsumerBuilder<Ignore, string>(conf).Build())
            {
                builder.Subscribe(_configuration["HSP-CS-KAFKA-Settings:ReportTopic"]);
                var cancelToken = new CancellationTokenSource();
                while (true)
                {                    
                    var consumer = builder.Consume(cancelToken.Token);
                    try
                    {                        
                        _logger.LogInformation($"Message: {consumer.Message.Value} received from {consumer.Topic}");
                        ReportQueueRequest request = JsonConvert.DeserializeObject<ReportQueueRequest>(consumer.Message.Value);
                        _reportQueueService.ReportQueueProcess(request);
                    }
                    catch (Exception exception)
                    {
                        builder.Close();
                        _logger.LogError($"Exception in {nameof(StartReportConsumer)}.", exception);
                        Console.WriteLine($"Exception Message: {exception.Message}");
                    }
                }
            }
        }
        /// <summary>
        /// Stop Async
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("StopAsync Start");
            return Task.CompletedTask;
        }
    }
}
