using HSP_CS_BACKGROUNDSERVICE_API;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NLog.Web;
using System;

namespace HSP_CS_BACKGROUNDSERVICE
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Main Function Start");
            CreateHostBuilder(args).Build().Run();
            
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                })
                .ConfigureServices(services =>
                {
                    services.AddHostedService<BackGroundServices>();
                })
                .UseNLog();                                                                   
    }
}
