﻿using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request;
using HSP_CS_COMMON_CORE.ResultHandling;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces
{
    public interface IReportQueueService
    {
        /// <summary>
        /// ReportQueueProcess
        /// </summary>
        /// <param name="reportQueueRequest"></param>
        /// <returns></returns>
        Task<HSPDbResult<HSPStatusRow>> ReportQueueProcess(ReportQueueRequest reportQueueRequest);
    }
}
