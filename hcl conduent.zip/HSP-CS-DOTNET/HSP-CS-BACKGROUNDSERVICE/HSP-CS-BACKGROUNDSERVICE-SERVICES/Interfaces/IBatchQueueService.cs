﻿using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces
{
    public interface IBatchQueueService
    {
        /// <summary>
        /// Batch Queue Process
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>void</returns>
        public void BatchQueueProcess(BatchQueueProcessRequest parameters);
        /// <summary>
        /// Get All Files
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>byte[]</returns>
        public byte[] GetAllNetworkDriveFilesbyte(string FilePath);      

    }
}
