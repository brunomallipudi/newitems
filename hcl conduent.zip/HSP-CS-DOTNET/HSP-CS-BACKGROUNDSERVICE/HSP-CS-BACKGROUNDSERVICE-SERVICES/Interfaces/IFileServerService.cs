﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces
{
    public interface IFileServerService
    {
        /// <summary>
        /// UploadFile with stram
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="fileName"></param>
        /// <param name="inputStream"></param>
        /// <returns></returns>
        public Task UploadFile(string filePath, string fileName, byte[] inputStream);
        /// <summary>
        /// Upload file Multicast
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="fileName"></param>
        /// <param name="inputStream"></param>
        public void UploadFile(string filePath, string fileName, IFormFile inputStream);
        /// <summary>
        /// GetAllNetworkDriveFiles
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public string[] GetAllNetworkDriveFiles(string filePath);
        /// <summary>
        /// CreateZipFiles
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="ZipfolderName"></param>
        /// <returns></returns>
        public Task CreateZipFiles(string filePath, string ZipfolderName);

        public void RemoveDirectory(string folderPath, string directoryName);
    }
}
