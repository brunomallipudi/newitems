﻿using HSP_CS_COMMON_SERVICES.Request;
using System.ComponentModel.DataAnnotations;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request
{
    public class ReportQueueRequest : BaseRequest
    {
        [Required]
        public int? ReportId { get; set; }
        [Required]
        public int? ReportUsageID { get; set; }
        [Required]
        public string ReportType { get; set; }
        [Required]
        public string ExportType { get; set; }
        public object ReportParameters { get; set; }
        public string ReportColumns { get; set; }
        public string ProductName { get; set; } = "E-Uniflow";
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public string StoredProcedureName { get; set; }        
        public string Usage { get; set; } = "|ByUserReport|";
        //public int? UserReportId { get; set; }
    }
}
