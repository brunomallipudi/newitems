﻿using HSP_CS_COMMON_SERVICES.Request;
using System.ComponentModel.DataAnnotations;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Report
{
    public class UpdateReportUsageRequest : BaseRequest
    {
        [Required]
        public int? ReportUsageID { get; set; }
        public string ReportUsageStatus { get; set; }
      
    }
}
