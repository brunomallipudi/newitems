﻿using HSP_CS_COMMON_SERVICES.Request;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request
{
   public class GetReportsRequest:BaseRequest
    {
        public object reportparameters { get; set; }
        public string Usage { get; set; } = "|ByUserReport|";
        public int? UserReportId { get; set; }
    }
}
