﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch
{
   public class BatchQueue
    {
        public string SessionId { get; set; }
        public string ReportUsageId { get; set; }
        public string BatchId { get; set; }
        public string IndividualCode { get; set; }
    }
}
