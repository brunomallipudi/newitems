﻿using HSP_CS_COMMON_SERVICES.Request;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch
{
    public class BatchQueueProcessRequest : BaseRequest
    {
        public string IndividualType { get; set; }
        public string Usage { get; set; }
        public int[] RowId { get; set; }
        public string ExportType { get; set; }
        public int BatchId { get; set; }
    }
}
