﻿using HSP_CS_COMMON_SERVICES.Request;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch
{
    public  class UpdateFormLetterRequest:BaseRequest
    {
        public string Usage { get; set; } = "|UpdateStatus|";
        public int BatchId { get; set; }
        public int? RowId { get; set; }
        public string OutputStatus { get; set; } = "EXT";        
    }
}
