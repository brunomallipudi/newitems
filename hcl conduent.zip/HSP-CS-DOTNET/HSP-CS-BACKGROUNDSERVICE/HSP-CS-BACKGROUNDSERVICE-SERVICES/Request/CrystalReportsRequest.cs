﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Request
{
    public class CrystalReportsRequest
    {
        public int SessionId { get; set; }
        public object reportparameters { get; set; }
        public string Usage { get; set; } = "|ByUserReport|";
        public int? UserReportId { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public string StoredProcedureName { get; set; }
    }
}
