﻿using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using ICSharpCode.SharpZipLib.Zip;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Helpers
{
    public class NetworkConnection : IDisposable, IFileServerService
    {
        private string _networkName;
        private readonly IConfiguration _configuration;
        private readonly string _userName;
        private readonly string _password;
        private string _serverName;
        private string _serverIP;
        private readonly string _networkPath;
        private readonly string _hostNameWithIP;
        private readonly string _hostnameWithoutIP;
        private readonly string _mountPath;
        private readonly string _IsMountPath;
        private readonly ILogger<NetworkConnection> _logger;
        private readonly string _replacePath;

        /// <summary>
        /// Network Connection Constructor
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="logger"></param>
        public NetworkConnection(IConfiguration configuration, ILogger<NetworkConnection> logger)
        {
            _configuration = configuration;
            _userName = _configuration["NetworkSettings:UserName"];
            _password = _configuration["NetworkSettings:Password"];
            _serverName = _configuration["NetworkSettings:DocumentServer"];
            _serverIP = _configuration["NetworkSettings:DocumentServerIP"];
            _networkPath = _configuration["NetworkSettings:NetworkPath"];
            _mountPath = _configuration["NetworkSettings:MountPath"];
            _IsMountPath = _configuration["NetworkSettings:IsMountPath"];
            _replacePath = _configuration["NetworkSettings:ReplacePath"];
            _logger = logger;
        }

        /// <summary>
        /// Upload File on Access Path
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="fileName"></param>
        /// <param name="inputStream"></param>
        public async Task UploadFile(string filePath, string fileName, byte[] inputStream)
        {
            try
            {
                if (!Convert.ToBoolean(_IsMountPath))
                {
                    NetworkDriveConnection(filePath);
                    filePath = filePath.Replace(_serverName, _serverIP, StringComparison.OrdinalIgnoreCase);
                }
                else
                {
                    filePath = ConvertPath(filePath);
                }
                _logger.LogInformation("Process File path:" + filePath + fileName);
                await CopyStreamToNetworkLocation(filePath, fileName, inputStream);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(UploadFile)}.");
                throw;
            }
        }
        /// <summary>
        /// Upload Document on Accessed Network Drive
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="fileName"></param>
        /// <param name="inputStream"></param>
        public async void UploadFile(string filePath, string fileName, IFormFile inputStream)
        {
            try
            {
                if (!Convert.ToBoolean(_IsMountPath))
                {
                    NetworkDriveConnection(filePath);
                    filePath = filePath.Replace(_serverName, _serverIP, StringComparison.OrdinalIgnoreCase);
                }
                else
                {
                    filePath = ConvertPath(filePath);
                }
                await CopyStreamToNetworkLocation(filePath, fileName, inputStream);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(UploadFile)}.");
                throw;
            }
        }

        /// <summary>
        /// Create File on Access Location
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="finalName"></param>
        /// <param name="inputStream"></param>
        /// <returns></returns>
        private async Task CopyStreamToNetworkLocation(string filePath, string finalName, byte[] inputStream)
        {
            try
            {
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                string fullPath = filePath + finalName;
                using (Stream file = File.OpenWrite(fullPath))
                {
                    await file.WriteAsync(inputStream, 0, inputStream.Length);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Exception in {nameof(CopyStreamToNetworkLocation)}.");
                throw;
            }
        }

        /// <summary>
        /// Create File On Access Location
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="finalName"></param>
        /// <param name="inputStream"></param>
        /// <returns></returns>
        private async Task CopyStreamToNetworkLocation(string filePath, string finalName, IFormFile inputStream)
        {
            try
            {
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                string fullPath = filePath + finalName;
                using (Stream file = File.Create(fullPath))
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        inputStream.CopyTo(ms);
                        byte[] stream = ms.ToArray();
                        await file.WriteAsync(stream, 0, stream.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Exception in {nameof(CopyStreamToNetworkLocation)}.");
                throw;
            }
        }

        /// <summary>
        /// Convert Path to Access MountPath on Docker Host Environment
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        private string ConvertPath(string filePath)
        {
            if (!string.IsNullOrEmpty(filePath))
            {
                filePath = filePath.Replace(_replacePath, _mountPath, StringComparison.OrdinalIgnoreCase).Replace(@"\", @"/");
            }
            return filePath;
        }

        /// <summary>
        /// Make Connection with Network Derive For LocalHost
        /// </summary>
        /// <param name="filePath"></param>
        private void NetworkDriveConnection(string filePath)
        {
            NetworkCredential credentials = new NetworkCredential(_userName, _password);
            _networkName = filePath.Replace(_serverName, _serverIP, StringComparison.OrdinalIgnoreCase);

            var netResource = new NetResource
            {
                Scope = ResourceScope.GlobalNetwork,
                ResourceType = ResourceType.Disk,
                DisplayType = ResourceDisplaytype.Share,
                RemoteName = _networkName
            };

            var userName = string.IsNullOrEmpty(credentials.Domain) ? credentials.UserName
                                    : string.Format(@"{0}\{1}", credentials.Domain, credentials.UserName);

            int isConnect = WNetAddConnection2(
           netResource,
           credentials.Password,
           userName,
           0);

            if (isConnect == 0)
            {
                throw new Win32Exception(isConnect, "Not able to make connection with Network Drive in local environment");
            }

        }

        /// <summary>
        /// Make connection with Network Drive
        /// </summary>
        /// <param name="netResource"></param>
        /// <param name="password"></param>
        /// <param name="username"></param>
        /// <param name="flags"></param>
        /// <returns></returns>
        [DllImport("mpr.dll")]
        private static extern int WNetAddConnection2(NetResource netResource, string password, string username, int flags);

        /// <summary>
        /// Dispose Network Connection on Localhost
        /// </summary>
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        [StructLayout(LayoutKind.Sequential)]
        public class NetResource
        {
            public ResourceScope Scope;
            public ResourceType ResourceType;
            public ResourceDisplaytype DisplayType;
            public int Usage;
            public string LocalName;
            public string RemoteName;
            public string Comment;
            public string Provider;
        }
        public enum ResourceScope : int
        {
            Connected = 1,
            GlobalNetwork,
            Remembered,
            Recent,
            Context
        };
        public enum ResourceType : int
        {
            Any = 0,
            Disk = 1,
            Print = 2,
            Reserved = 8,
        }
        public enum ResourceDisplaytype : int
        {
            Generic = 0x0,
            Domain = 0x01,
            Server = 0x02,
            Share = 0x03,
            File = 0x04,
            Group = 0x05,
            Network = 0x06,
            Root = 0x07,
            Shareadmin = 0x08,
            Directory = 0x09,
            Tree = 0x0a,
            Ndscontainer = 0x0b
        }

        /// <summary>
        /// Get All Network Drive Files from Path
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public string[] GetAllNetworkDriveFiles(string filePath)
        {
            string[] filePaths = { };
            try
            {
                if (!Convert.ToBoolean(_IsMountPath))
                {
                    NetworkDriveConnection(filePath);
                    filePath = filePath.Replace(_serverName, _serverIP, StringComparison.OrdinalIgnoreCase);
                }
                else
                {
                    filePath = ConvertPath(filePath);
                }
                if (File.Exists(filePath))
                {
                    filePaths = Directory.GetFiles(filePath);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Exception in {nameof(GetAllNetworkDriveFiles)}.");
                throw;
            }
            return filePaths;
        }

        /// <summary>
        /// Create Files zip in folder
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="ZipfolderName"></param>
        public async Task CreateZipFiles(string filePath, string ZipfolderName)
        {
            string[] filePaths = { };
            try
            {
                if (!Convert.ToBoolean(_IsMountPath))
                {
                    NetworkDriveConnection(filePath);
                    filePath = filePath.Replace(_serverName, _serverIP, StringComparison.OrdinalIgnoreCase);
                }
                else
                {
                    filePath = ConvertPath(filePath);
                }
                if (Directory.Exists(filePath))
                {

                    filePaths = Directory.GetFiles(filePath);
                    if (filePaths.Length > 0)
                    {
                        ZipOutputStream s = new ZipOutputStream(File.Create($"{filePath}{ZipfolderName}.zip"));
                        foreach (string filename in filePaths)
                        {
                            using (FileStream fs = File.OpenRead(filename))
                            {
                                fs.Flush();
                                byte[] buffer = new byte[fs.Length];
                                fs.Read(buffer, 0, buffer.Length);
                                ZipEntry entry = new ZipEntry(filename);
                                s.PutNextEntry(entry);
                                s.Write(buffer, 0, buffer.Length);
                                fs.Close();
                            }
                        }

                        s.SetLevel(5);
                        s.Finish();
                        s.Close();
                    }

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Exception in {nameof(CreateZipFiles)}.");
                throw;
            }

        }

        /// <summary>
        /// Remove Folder from Network Drive
        /// </summary>
        /// <param name="folderPath"></param>
        /// <param name="directoryName"></param>
        public void RemoveDirectory(string folderPath, string directoryName)
        {
            try
            {
                string finalPath = Path.Combine(folderPath, directoryName);
                if (!Convert.ToBoolean(_IsMountPath))
                {
                    NetworkDriveConnection(finalPath);
                    finalPath = finalPath.Replace(_serverName, _serverIP, StringComparison.OrdinalIgnoreCase);
                }
                else
                {
                    finalPath = ConvertPath(finalPath);
                }

                if (Directory.Exists(finalPath))
                {
                    foreach (var file in Directory.GetFiles(finalPath))
                    {
                        File.Delete(file);
                    }

                    Directory.Delete(finalPath);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(RemoveDirectory)}.");
                throw;
            }
        }
    }
}
