﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.Packaging;
using PdfSharpCore.Pdf;
using PdfSharpCore.Pdf.IO;
using Syncfusion.DocIO;
using Syncfusion.DocIO.DLS;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Helpers
{
    public static class ReportGenerationHelper
    {
        /// <summary>
        /// Create CSV File
        /// </summary>
        /// <param name="dtRecords"></param>
        /// <param name="columnsList"></param>
        /// <returns></returns>
        public static byte[] CreateCSVFile(DataTable dtRecords, string columnsList)
        {
            string delimiter = ",";
            StringBuilder csvGen = new StringBuilder();
            int index = 0;
            if (columnsList != null && dtRecords.TableName.ToUpper() == "MAIN")
            {
                List<string> dataColumns = new List<string>();
                List<string> columnlst = columnsList.Split(',').ToList();
                foreach (DataColumn column in dtRecords.Columns)
                {
                    dataColumns.Add(column.ColumnName.ToUpper().Trim());
                }
                List<string> finalColumn = dataColumns.FindAll(x => columnlst.Any(y => y.ToUpper().Trim() == x.ToUpper().Trim()));

                foreach (string column in finalColumn)
                {
                    csvGen.Append(column.ToUpper().Trim()).Append(delimiter);
                }
                index = csvGen.ToString().LastIndexOf(',');
                if (index > 0)
                {
                    csvGen = csvGen.Remove(index, 1);
                }
                csvGen.Append("\r\n");
                foreach (DataRow row in dtRecords.Rows)
                {
                    foreach (string column in finalColumn)
                    {
                        csvGen.Append(row[column].ToString()).Append(delimiter);
                    }
                    csvGen.AppendLine();
                    index = csvGen.ToString().LastIndexOf(',');
                    if (index > 0)
                    {
                        csvGen = csvGen.Remove(index, 1);
                    }
                }
            }
            else
            {
                foreach (DataColumn column in dtRecords.Columns)
                {
                    csvGen.Append(column.ColumnName.ToUpper().Trim()).Append(delimiter);
                }
                index = csvGen.ToString().LastIndexOf(',');
                if (index > 0)
                {
                    csvGen = csvGen.Remove(index, 1);
                }
                csvGen.Append("\r\n");

                foreach (DataRow row in dtRecords.Rows)
                {
                    foreach (DataColumn column in dtRecords.Columns)
                    {
                        csvGen.Append(row[column.ColumnName].ToString()).Append(delimiter);
                    }
                    csvGen.AppendLine();
                    index = csvGen.ToString().LastIndexOf(',');
                    if (index > 0)
                    {
                        csvGen = csvGen.Remove(index, 1);
                    }
                }
            }

            byte[] bytearry = Encoding.ASCII.GetBytes(csvGen.ToString());
            return bytearry;
        }

        /// <summary>
        /// Merge Files into one
        /// </summary>
        /// <param name="filesPathCollection"></param>
        /// <returns></returns>
        public static byte[] MergepdFiles(List<string> filesPathCollection)
        {
            byte[] fileBytes = null;
            using (PdfDocument targetdoc = new PdfDocument())
            {
                foreach (var filePath in filesPathCollection)
                {
                    using (PdfDocument pdfdoc = PdfReader.Open(filePath, PdfDocumentOpenMode.Import))
                    {
                        for (int i = 0; i < pdfdoc.PageCount; i++)
                        {
                            targetdoc.AddPage(pdfdoc.Pages[i]);
                        }
                    }
                }
                using (MemoryStream ms = new MemoryStream())
                {
                    targetdoc.Save(ms);
                    fileBytes = ms.ToArray();
                }
            }
            return fileBytes;
        }

        /// <summary>
        /// Create Excel
        /// </summary>
        /// <param name="table"></param>
        /// <param name="columnList"></param>
        /// <returns></returns>
        public static byte[] CreateExcel(DataTable table, string columnList)
        {
            byte[] fileBytes = null;
            if(!string.IsNullOrEmpty(columnList) && table.TableName.ToUpper() == "MAIN")
            {
                List<string> dataColumns = new List<string>();
                List<string> columnlst = columnList.Split(',').ToList();
                foreach (DataColumn column in table.Columns)
                {
                    dataColumns.Add(column.ColumnName.ToUpper().Trim());
                }
                List<string> finalColumn = dataColumns.FindAll(x => columnlst.Any(y => y.ToUpper().Trim() == x.ToUpper().Trim()));               
                
                DataTable tableData = new DataTable();
                tableData.TableName = table.TableName;
                if (table.Rows != null && table.Rows.Count > 0)
                {
                    int rowIndex = 0;
                    foreach (string column in finalColumn)
                    {
                        tableData.Columns.Add(column, typeof(string));
                    }
                    foreach (DataRow row in table.Rows)
                    {
                        foreach (string column in finalColumn)
                        {
                            tableData.Rows[rowIndex][column] = row[column];
                        }
                        rowIndex++;
                    }
                }
                else
                {
                    foreach (string column in finalColumn)
                    {
                        tableData.Columns.Add(column, typeof(string));
                    }
                }
                using (var book = new XLWorkbook())
                {
                    book.Worksheets.Add(tableData, (tableData.TableName.Length > 30 ? tableData.TableName.Substring(0, 30) : tableData.TableName.ToString()));

                    using (var stream = new MemoryStream())
                    {
                        book.SaveAs(stream);
                        fileBytes = stream.ToArray();
                    }
                }
            }
            else
            {
                using (var book = new XLWorkbook())
                {
                    book.Worksheets.Add(table, (table.TableName.Length > 30 ? table.TableName.Substring(0, 30) : table.TableName.ToString()));

                    using (var stream = new MemoryStream())
                    {
                        book.SaveAs(stream);
                        fileBytes = stream.ToArray();
                    }
                }
            }
            return fileBytes;
        }

        /// <summary>
        /// Create Doc
        /// </summary>
        /// <param name="table"></param>
        /// <returns></returns>
        public static byte[] CreateDOC(DataTable table, string columnList)
        {
            byte[] fileBytes = null;
            StringBuilder stringBuilder = new StringBuilder();
            if (!string.IsNullOrEmpty(columnList) && table.TableName.ToUpper() == "MAIN")
            {
                List<string> dataColumns = new List<string>();
                List<string> columnlst = columnList.Split(',').ToList();
                foreach (DataColumn column in table.Columns)
                {
                    dataColumns.Add(column.ColumnName.ToUpper().Trim());
                }
                List<string> finalColumn = dataColumns.FindAll(x => columnlst.Any(y => y.ToUpper().Trim() == x.ToUpper().Trim()));

                DataTable tableData = new DataTable();
                tableData.TableName = table.TableName;
                if (table.Rows != null && table.Rows.Count > 0)
                {                    
                    int rowIndex = 0;
                    foreach (string column in finalColumn)
                    {
                        tableData.Columns.Add(column, typeof(string));
                    }
                    foreach (DataRow row in table.Rows)
                    {                        
                        foreach (string column in finalColumn)
                        {
                            tableData.Rows[rowIndex][column] = row[column];
                        }
                        rowIndex++;                        
                    }
                }
                else
                {
                    foreach (string column in finalColumn)
                    {
                        tableData.Columns.Add(column, typeof(string));
                    }
                }

                tableData.Rows.Cast<DataRow>().ToList().ForEach(dataRow =>
                {
                    tableData.Columns.Cast<DataColumn>().ToList().ForEach(column =>
                    {
                        stringBuilder.AppendFormat("{0}:{1} ", column.ColumnName, dataRow[column]);
                    });
                    stringBuilder.Append(Environment.NewLine);
                });

                using (WordDocument document = new WordDocument())
                {
                    //Adds a section and a paragraph to the document
                    document.EnsureMinimal();                    
                    //Appends text to the last paragraph of the document
                    document.LastParagraph.AppendText(stringBuilder.ToString());                                                                                
                    using (MemoryStream stream = new MemoryStream())
                    {
                        //Saves the Word document to  MemoryStream
                        document.Save(stream, FormatType.Docx);
                        stream.Position = 0;
                        fileBytes = stream.ToArray();
                    }
                }
            }
            else
            {                
                table.Rows.Cast<DataRow>().ToList().ForEach(dataRow =>
                {
                    table.Columns.Cast<DataColumn>().ToList().ForEach(column =>
                    {
                        stringBuilder.AppendFormat("{0}:{1} ", column.ColumnName, dataRow[column]);
                    });
                    stringBuilder.Append(Environment.NewLine);
                });

                using (WordDocument document = new WordDocument())
                {
                    //Adds a section and a paragraph to the document
                    document.EnsureMinimal();
                    // document.
                    //Appends text to the last paragraph of the document
                    document.LastParagraph.AppendText(stringBuilder.ToString());//change here for our condition
                                                                                // document.
                    using (MemoryStream stream = new MemoryStream())
                    {
                        //Saves the Word document to  MemoryStream
                        document.Save(stream, FormatType.Docx);
                        stream.Position = 0;
                        fileBytes = stream.ToArray();                        
                    }
                }
            }
            return fileBytes;
        }

        /// <summary>
        /// Generate Report Name
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="tableName"></param>
        /// <param name="tableCount"></param>
        /// <param name="exportType"></param>
        /// <returns></returns>
        public static string GenerateReportName(string tableName, int tableCount, string exportType)
        {
            string reportName = tableName + DateTime.Now.ToString("yyyy") + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd") + (tableCount > 1 ? "_main" : string.Empty) + "." + exportType;
            return reportName;
        }
    }
}

