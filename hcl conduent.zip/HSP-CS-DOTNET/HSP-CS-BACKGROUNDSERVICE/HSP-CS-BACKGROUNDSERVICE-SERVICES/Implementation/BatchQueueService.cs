﻿using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Helpers;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_ENTITIES.DTO.FormLetters;
using HSP_CS_COMMON_ENTITIES.DTO.PDFStream;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Request.Documents;
using HSP_CS_COMMON_SERVICES.Request.QueueProcess;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Implementation
{
    public class BatchQueueService : IBatchQueueService
    {
        private readonly IFormLettersRepository _formLettersRepository;
        private readonly IUserReportsRepository _userReportsRepository;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;
        private readonly IFileServerService _fileServerConnection;
        private readonly IBatchQueueRepository _batchQueueRepository;
        private readonly string _batchPdfFilePath;
        private readonly ILogger<BatchQueueService> _logger;
        public BatchQueueService(IFormLettersRepository formLettersRepository, IUserReportsRepository userReportsRepository, IHttpClientFactory clientFactory, IConfiguration configuration, IFileServerService fileServerConnection, IBatchQueueRepository batchQueueRepository, ILogger<BatchQueueService> logger)
        {
            _formLettersRepository = formLettersRepository;
            _userReportsRepository = userReportsRepository;
            _clientFactory = clientFactory;
            _configuration = configuration;
            _fileServerConnection = fileServerConnection;
            _batchQueueRepository = batchQueueRepository;
            _batchPdfFilePath = _configuration["NetworkSettings:BatchPdfLocation"];
            _logger = logger;
        }
        public async void BatchQueueProcess(BatchQueueProcessRequest batchQueueProcessRequest)
        {
            ProcessBatchRequest parameters = new ProcessBatchRequest();
            BatchProcessFileUploadRequest batchProcessFileUploadRequest = new BatchProcessFileUploadRequest();
            ProcessBatchDto dto = new ProcessBatchDto();
            string ErrorMessage = "";
            UpdateFormLetterRequest updateFormLetterRequest = new UpdateFormLetterRequest();
            bool check = false;
            try
            {
                _logger.LogInformation("BatchQueueProcess Started");
                foreach (var rowid in batchQueueProcessRequest.RowId)
                {
                    _logger.LogInformation("BatchQueueProcess Started batchId is {0} and RowId is {1}", batchQueueProcessRequest.BatchId, rowid);
                    parameters.BatchId = batchQueueProcessRequest.BatchId;
                    parameters.IndividualCode = batchQueueProcessRequest.IndividualType;
                    parameters.SessionId = batchQueueProcessRequest.SessionId;
                    parameters.Usage = batchQueueProcessRequest.Usage;
                    parameters.RowId = rowid;
                    (var status, var getExtractedDataDetails) = await _formLettersRepository.GetLetterDetails(parameters);
                    _logger.LogInformation("BatchQueueProcess GetLetterDetails endpoint with response {0} ");
                    if (status.DbStatus == HSPDbStatus.Normal && getExtractedDataDetails != null && getExtractedDataDetails.ToList().Count > 0)
                    {
                        var data = getExtractedDataDetails.FirstOrDefault();
                        ProcessBatchExtractedDataDetailsDto processBatchExtractedDataDetailsDto = new ProcessBatchExtractedDataDetailsDto();
                        processBatchExtractedDataDetailsDto.UserReportId = data.UserReportId;
                        processBatchExtractedDataDetailsDto.SessionId = parameters.SessionId;
                        processBatchExtractedDataDetailsDto.Usage = "|ByUserReport|";
                        (var userreporstatus, var results) = await _userReportsRepository.GetUserReports(processBatchExtractedDataDetailsDto);
                       _logger.LogInformation("BatchQueueProcess GetUserReports endpoint  response "+results.ToList().Count);
                        if (results != null && results.ToList().Count > 0)
                        {
                            var userReportResult = results.FirstOrDefault();
                            _logger.LogInformation("BatchQueueProcess userReportResult results.FirstOrDefault() End result Count{0}", results.ToList().Count);
                            var reportParameters = new
                            {
                                UserReportId = processBatchExtractedDataDetailsDto.UserReportId??null,
                                BatchId = (int)parameters.BatchId,
                                RowId = (int)data.RowId,
                                IndividualCode = parameters.IndividualCode,
                                Usage = "|ForPrinting|"
                            };
                            CrystalReportsRequest objuserReport = new CrystalReportsRequest();
                            objuserReport.ReportPath = userReportResult.ReportPath;
                            objuserReport.StoredProcedureName = userReportResult.StoredProcedureName;
                            objuserReport.UserReportId = processBatchExtractedDataDetailsDto.UserReportId??null;
                            objuserReport.SessionId = parameters.SessionId;
                            objuserReport.Usage = "|ForPrinting|";
                            objuserReport.reportparameters = reportParameters;
                            var jsonRequest = JsonConvert.SerializeObject(objuserReport);
                            PDFStreamDto pdfStreamDto = new PDFStreamDto();

                            if (batchQueueProcessRequest.ExportType.ToLower() == "pdf")
                            {
                                _logger.LogInformation("BatchQueueProcess PDF creation Start");
                                if (userReportResult.ReportPath.ToLower().EndsWith(".rpt"))
                                {
                                    pdfStreamDto.pdfStream = await GetCrystalReportStream(jsonRequest);

                                    if (pdfStreamDto.pdfStream != null)
                                    {
                                        try
                                        {
                                            string st = pdfStreamDto.pdfStream.Trim(new char[] { '"' });
                                            batchProcessFileUploadRequest.FileByte
                                               = Convert.FromBase64String(st);
                                            batchProcessFileUploadRequest.FileName = parameters.BatchId + "_" + parameters.RowId + "." + batchQueueProcessRequest.ExportType;
                                            batchProcessFileUploadRequest.FilePath = Convert.ToString(parameters.BatchId);
                                            await _fileServerConnection.UploadFile(_batchPdfFilePath + batchProcessFileUploadRequest.FilePath + "\\", batchProcessFileUploadRequest.FileName, batchProcessFileUploadRequest.FileByte);
                                        }
                                        catch(Exception ex)
                                        {
                                            _logger.LogError(ex, $"Exception in updload pdf file.");
                                            _logger.LogInformation(ex, $"Exception in updload pdf file.");
                                            updateFormLetterRequest.RowId = parameters.RowId;
                                            updateFormLetterRequest.BatchId = parameters.BatchId;
                                            updateFormLetterRequest.SessionId = parameters.SessionId;
                                            updateFormLetterRequest.OutputStatus = "FLD";
                                            ErrorMessage = "PDF uploading exception. Process break";
                                            check = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                                            break;
                                        }
                                    }
                                }
                                else if (userReportResult.ReportPath.ToLower().EndsWith(".rdlc"))
                                {
                                    try
                                    {
                                        pdfStreamDto.pdfStream = await GetSSRSReportStream(jsonRequest);

                                        if (pdfStreamDto.pdfStream != null)
                                        {
                                            string st = pdfStreamDto.pdfStream.Trim(new char[] { '"' });
                                            batchProcessFileUploadRequest.FileByte
                                               = Convert.FromBase64String(st);
                                            batchProcessFileUploadRequest.FileName = parameters.BatchId + "_" + parameters.RowId + "." + batchQueueProcessRequest.ExportType;
                                            batchProcessFileUploadRequest.FilePath = Convert.ToString(parameters.BatchId);
                                            await _fileServerConnection.UploadFile(_batchPdfFilePath + batchProcessFileUploadRequest.FilePath + "\\", batchProcessFileUploadRequest.FileName, batchProcessFileUploadRequest.FileByte);
                                        }
                                    }
                                    catch(Exception ex)
                                    {
                                        _logger.LogError(ex, $"Exception in updload pdf file.");
                                        _logger.LogInformation(ex, $"Exception in updload pdf file.");
                                        updateFormLetterRequest.RowId = parameters.RowId;
                                        updateFormLetterRequest.BatchId = parameters.BatchId;
                                        updateFormLetterRequest.SessionId = parameters.SessionId;
                                        updateFormLetterRequest.OutputStatus = "FLD";
                                        ErrorMessage = "PDF uploading exception. Process break";
                                        check = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                                        break;
                                    }
                                }
                                _logger.LogInformation("BatchQueueProcess PDF creation End");
                            }
                            if (batchQueueProcessRequest.ExportType.ToLower() == "csv")
                            {
                                try
                                {
                                    _logger.LogInformation("BatchQueueProcess CSV creation Start");
                                    DataSet _csv = _batchQueueRepository.GetReportData(objuserReport.reportparameters, objuserReport.StoredProcedureName, parameters.SessionId);
                                    for (int i = 0; i < _csv.Tables.Count; i++)
                                    {
                                        byte[] arr = ReportGenerationHelper.CreateCSVFile(_csv.Tables[i], null);
                                        await _fileServerConnection.UploadFile(_batchPdfFilePath + Convert.ToString(parameters.BatchId) + "\\", _csv.Tables[i].TableName + DateTime.Now.ToString("yyyy") + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd") + Guid.NewGuid().ToString().Substring(0, 5) + (_csv.Tables.Count > 1 ? "_main" : string.Empty) + "." + batchQueueProcessRequest.ExportType.ToString(), arr);

                                    }
                                }catch(Exception ex)
                                {
                                    _logger.LogError(ex, $"Exception in updload csv file.");
                                    _logger.LogInformation(ex, $"Exception in updload csv file.");
                                    updateFormLetterRequest.RowId = parameters.RowId;
                                    updateFormLetterRequest.BatchId = parameters.BatchId;
                                    updateFormLetterRequest.OutputStatus = "FLD";
                                    updateFormLetterRequest.SessionId = parameters.SessionId;
                                    ErrorMessage = "CSV uploading exception. Process break";
                                    check = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                                    break;
                                }
                                _logger.LogInformation("BatchQueueProcess CSV creation End");
                            }
                            if (batchQueueProcessRequest.ExportType.ToLower() == "xls")
                            {
                                try
                                {
                                    _logger.LogInformation("BatchQueueProcess XLS creation Start");
                                    DataSet _csv = _batchQueueRepository.GetReportData(objuserReport.reportparameters, objuserReport.StoredProcedureName, parameters.SessionId);
                                    for (int i = 0; i < _csv.Tables.Count; i++)
                                    {
                                        byte[] arr = ReportGenerationHelper.CreateExcel(_csv.Tables[i], null);
                                        await _fileServerConnection.UploadFile(_batchPdfFilePath + Convert.ToString(parameters.BatchId) + "\\", _csv.Tables[i].TableName + DateTime.Now.ToString("yyyy") + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd") + Guid.NewGuid().ToString().Substring(0, 5) + (_csv.Tables.Count > 1 ? "_main" : string.Empty) + "." + batchQueueProcessRequest.ExportType.ToString(), arr);
                                    }
                                }
                                catch(Exception ex)
                                {
                                    _logger.LogError(ex, $"Exception in updload XLS file.");
                                    _logger.LogInformation(ex, $"Exception in updload XLS file.");
                                    updateFormLetterRequest.RowId = parameters.RowId;
                                    updateFormLetterRequest.BatchId = parameters.BatchId;
                                    updateFormLetterRequest.OutputStatus = "FLD";
                                    updateFormLetterRequest.SessionId = parameters.SessionId;
                                    ErrorMessage = "XLS uploading exception. Process break";
                                    check = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                                    break;
                                }
                                _logger.LogInformation("BatchQueueProcess XLS creation End");
                            }
                            if (batchQueueProcessRequest.ExportType.ToLower() == "doc")
                            {
                                _logger.LogInformation("BatchQueueProcess DOC creation Start");
                                DataSet _csv = _batchQueueRepository.GetReportData(objuserReport.reportparameters, objuserReport.StoredProcedureName, parameters.SessionId);
                                for (int i = 0; i < _csv.Tables.Count; i++)
                                {
                                    byte[] arr = ReportGenerationHelper.CreateDOC(_csv.Tables[i], null);
                                    await _fileServerConnection.UploadFile(_batchPdfFilePath + Convert.ToString(parameters.BatchId) + "\\", _csv.Tables[i].TableName + DateTime.Now.ToString("yyyy") + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd") + Guid.NewGuid().ToString().Substring(0, 5) + (_csv.Tables.Count > 1 ? "_main" : string.Empty) + "." + batchQueueProcessRequest.ExportType.ToString(), arr);
                                }
                                _logger.LogInformation("BatchQueueProcess DOC creation End");
                            }


                        }
                        else
                        {
                            updateFormLetterRequest.RowId = parameters.RowId;
                            updateFormLetterRequest.BatchId = parameters.BatchId;
                            updateFormLetterRequest.SessionId = parameters.SessionId;
                            updateFormLetterRequest.OutputStatus = "FLD";
                            ErrorMessage = "No Data available for selected queue";
                            _logger.LogInformation("Data is not Exist in GetUserReports Endpoint");
                            check =  _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);                            
                            break;
                        }
                    }
                    else
                    {
                        updateFormLetterRequest.RowId = parameters.RowId;
                        updateFormLetterRequest.BatchId = parameters.BatchId;
                        updateFormLetterRequest.SessionId = parameters.SessionId;
                        updateFormLetterRequest.OutputStatus = "FLD";
                        ErrorMessage = "No Data available for selected queue";
                        check = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                        _logger.LogInformation("Data is not Exist in GetLetterDetails Endpoint");
                        break;
                    }
                }
                if (batchQueueProcessRequest.ExportType.ToLower() == "pdf")
                {
                    _logger.LogInformation("BatchQueueProcess PDF Merge Start");
                    byte[] files = GetAllNetworkDriveFilesbyte(batchProcessFileUploadRequest.FilePath + "\\");
                    if (files?.Length > 0)
                    {
                        await _fileServerConnection.UploadFile(_batchPdfFilePath + Convert.ToString(parameters.BatchId) + "\\", Convert.ToString(parameters.BatchId) + "." + batchQueueProcessRequest.ExportType, files);
                    }
                    _logger.LogInformation("BatchQueueProcess PDF Merge End");
                }
                _logger.LogInformation("BatchQueueProcess Zip process Start");
                await _fileServerConnection.CreateZipFiles(_batchPdfFilePath + Convert.ToString(batchQueueProcessRequest.BatchId) + "\\", Convert.ToString(batchQueueProcessRequest.BatchId));
                _logger.LogInformation("BatchQueueProcess Zip process End");
                _logger.LogInformation("BatchQueueProcess Check BatchId is Exist or Deleted during queue process by other End point start");
                (var statusForBatch, var GetBatch) = await _formLettersRepository.GetLetterDetails(parameters);
                _logger.LogInformation("BatchQueueProcess Check BatchId is Exist or Deleted during queue process by other End point End");
                if (check == false)
                {
                    if (GetBatch.ToList().Count > 0)
                    {
                        _logger.LogInformation("BatchQueueProcess UpdateFormLetter Endpoint status start");
                        updateFormLetterRequest.BatchId = batchQueueProcessRequest.BatchId;
                        updateFormLetterRequest.SessionId = batchQueueProcessRequest.SessionId;
                        try
                        {
                            foreach (var rowId in batchQueueProcessRequest.RowId)
                            {
                                updateFormLetterRequest.RowId = rowId;
                                var success = await _formLettersRepository.UpdateFormLetter(updateFormLetterRequest);
                                if (success.DbStatus != HSPDbStatus.Normal)
                                {
                                    updateFormLetterRequest.OutputStatus = "FLD";
                                    ErrorMessage = "Session is Fail, Try again";
                                    var success1 = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                                    _fileServerConnection.RemoveDirectory(_batchPdfFilePath, Convert.ToString(parameters.BatchId));
                                    _logger.LogError(success.StatusRow.ErrorMessage);
                                    _logger.LogInformation(success.ErrorMessage);
                                }
                            }
                            _logger.LogInformation("BatchQueueProcess UpdateFormLetter Endpoint status End");
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, $"Exception in UpdateFormLetter.");
                        }
                    }
                    else
                    {
                        _logger.LogInformation("BatchQueueProcess batchId is Deleted remove file directory from network drive start");
                        _fileServerConnection.RemoveDirectory(_batchPdfFilePath, Convert.ToString(parameters.BatchId));
                        _logger.LogInformation("BatchQueueProcess batchId is Deleted remove file directory from network drive End");
                    }
                }

                _logger.LogInformation("BatchQueueProcess End");
            }
            catch (Exception ex)
            {
                updateFormLetterRequest.RowId = parameters.RowId;
                updateFormLetterRequest.BatchId = parameters.BatchId;
                updateFormLetterRequest.SessionId = parameters.SessionId;
                updateFormLetterRequest.OutputStatus = "FLD";
                ErrorMessage = "Something Went Wrong, Please try again";
                check = _batchQueueRepository.UpdateFormLetter(updateFormLetterRequest.RowId, updateFormLetterRequest.BatchId, updateFormLetterRequest.OutputStatus, ErrorMessage);
                _logger.LogInformation("Something Went Wrong, Please try again");
                
                _logger.LogError(ex, $"Exception in {nameof(BatchQueueProcess)}.");
            }
        }
        public byte[] GetAllNetworkDriveFilesbyte(string FilePath)
        {
            List<string> result = new List<string>();
            byte[] fileByte = null;
            try
            {
                string[] files = _fileServerConnection.GetAllNetworkDriveFiles(_batchPdfFilePath + FilePath);
                foreach (string file in files)
                {

                    string filepath = file;
                    result.Add(filepath);
                }
                fileByte = ReportGenerationHelper.MergepdFiles(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Exception in {nameof(GetAllNetworkDriveFilesbyte)}.");
            }
            return fileByte;
        }

        /// <summary>
        /// Get Crystal Report Stream
        /// </summary>
        /// <param name="jsonRequest"></param>
        /// <returns></returns>
        public async Task<string> GetCrystalReportStream(string jsonRequest)
        {
            string docEndpointurl = $"{_configuration["HSP-CS-REPORT-API:ServiceReportUrl"]}{_configuration["HSP-CS-REPORT-API:DownloadReport"]}";
            var data = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            string resultDownload = null;
            try
            {
                // call the crystal report api using HTTP Client Factory
                var client = _clientFactory.CreateClient();
                client.BaseAddress = new Uri(docEndpointurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var requestUri = new Uri(docEndpointurl);
                var responseDownloadReport = await client.PostAsync(requestUri, data);

                resultDownload = await responseDownloadReport.Content.ReadAsStringAsync();
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetCrystalReportStream)}.");
                throw;
            }
            return resultDownload;
        }

        /// <summary>
        /// GetSSRSReportStream
        /// </summary>
        /// <param name="jsonRequest"></param>
        /// <returns></returns>
        public async Task<string> GetSSRSReportStream(string jsonRequest)
        {
            string docEndpointurl = $"{_configuration["HSP-CS-REPORT-API:ServiceReportUrl"]}{_configuration["HSP-CS-REPORT-API:DownloadSSRSReport"]}";
            var data = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            string resultDownload = null;
            try
            {
                // call the crystal report api using HTTP Client Factory
                var client = _clientFactory.CreateClient();
                client.BaseAddress = new Uri(docEndpointurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var requestUri = new Uri(docEndpointurl);
                var responseDownloadReport = await client.PostAsync(requestUri, data);
                resultDownload = await responseDownloadReport.Content.ReadAsStringAsync();
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetSSRSReportStream)}.");
                throw;
            }
            return resultDownload;
        }
    }
}
