﻿using Confluent.Kafka;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE
{
    /// <summary>
    /// Kafka Consumer
    /// </summary>
    public class KafkaConsumerService : IHostedService
    {
        private readonly IBatchQueueService _batchQueueService;
        private readonly IReportQueueService _reportQueueService;
        private readonly ILogger<KafkaConsumerService> _logger;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Kafka Consumer Service
        /// </summary>
        /// <param name="batchQueueService"></param>
        /// <param name="reportQueueService"></param>
        /// <param name="logger"></param>
        /// <param name="configuration"></param>
        public KafkaConsumerService(IBatchQueueService batchQueueService,
                                    IReportQueueService reportQueueService,
                                    ILogger<KafkaConsumerService> logger,
                                    IConfiguration configuration)
        {
            _batchQueueService = batchQueueService;
            _reportQueueService = reportQueueService;
            _logger = logger;
            _configuration = configuration;
            _logger.LogInformation("Creating Kafka Consumer service");
        }

        /// <summary>
        /// Start Async
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("StartAsync Start");
            var conf = new ConsumerConfig
            {
                GroupId = _configuration["HSP-CS-KAFKA-Settings:BatchGroupID"],
                BootstrapServers = _configuration["HSP-CS-KAFKA-Settings:BootstrapServers"],
                AutoOffsetReset = AutoOffsetReset.Earliest
            };

            using (var builder = new ConsumerBuilder<Ignore, string>(conf).Build())
            {
                List<string> topics = new List<string>();
                topics.Add(_configuration["HSP-CS-KAFKA-Settings:BatchTopic"]);
                topics.Add(_configuration["HSP-CS-KAFKA-Settings:ReportTopic"]);
                builder.Subscribe(topics);

                var cancelToken = new CancellationTokenSource();
                while (true)
                {
                    try
                    {
                        var consumer = builder.Consume();
                        string recievedTopic = consumer.Topic;

                        _logger.LogInformation($"Message: {consumer.Message.Value} received from {recievedTopic}");
                        if (String.Equals(recievedTopic, _configuration["HSP-CS-KAFKA-Settings:BatchTopic"]))
                        {
                            var request = JsonConvert.DeserializeObject<BatchQueueProcessRequest>(consumer.Message.Value);
                            _batchQueueService.BatchQueueProcess(request);
                        }
                        else if (String.Equals(recievedTopic, _configuration["HSP-CS-KAFKA-Settings:ReportTopic"]))
                        {
                            var request = JsonConvert.DeserializeObject<ReportQueueRequest>(consumer.Message.Value);
                            _reportQueueService.ReportQueueProcess(request);
                        }
                    }
                    catch (Exception exception)
                    {
                        _logger.LogError($"Exception in start async method.", exception);
                    }
                }
            }            
        }

        /// <summary>
        /// Stop Async
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("StopAsync Start");
            return Task.CompletedTask;
        }
    }
}
