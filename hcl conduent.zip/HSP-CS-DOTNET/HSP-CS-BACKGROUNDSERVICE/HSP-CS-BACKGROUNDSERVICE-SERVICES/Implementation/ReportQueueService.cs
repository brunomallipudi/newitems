﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Helpers;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Report;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_ENTITIES.DTO.PDFStream;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace HSP_CS_BACKGROUNDSERVICE_SERVICES.Implementation
{
    public class ReportQueueService : IReportQueueService
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;
        private readonly ILogger<ReportQueueService> _logger;
        private readonly IFileServerService _fileServerConnection;
        private readonly IReportQueueRepository _backGroundProcessRepository;
        private readonly IReportsRepository _reportsRepository;

        /// <summary>
        /// Report Queue Service
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="clientFactory"></param>
        /// <param name="logger"></param>
        /// <param name="fileServerConnection"></param>
        /// <param name="backGroundProcessRepository"></param>
        /// <param name="reportsRepository"></param>
        public ReportQueueService(IConfiguration configuration,
                                   IHttpClientFactory clientFactory,
                                   ILogger<ReportQueueService> logger,
                                   IFileServerService fileServerConnection,
                                   IReportQueueRepository backGroundProcessRepository,
                                   IReportsRepository reportsRepository)
        {
            _configuration = configuration;
            _clientFactory = clientFactory;
            _logger = logger;
            _fileServerConnection = fileServerConnection;
            _backGroundProcessRepository = backGroundProcessRepository;
            _reportsRepository = reportsRepository;
        }

        /// <summary>
        /// Report Queue Process
        /// </summary>
        /// <param name="reportQueueRequest"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> ReportQueueProcess(ReportQueueRequest reportQueueRequest)
        {
            string ErrorMessage = "";
            _logger.LogInformation("ReportQueueProcess Started");
            string fileExtension = null;
            var status = new HSPDbResult<HSPStatusRow>();
            PDFStreamDto pdfStreamDto = new PDFStreamDto();
            string filePath = _configuration["NetworkSettings:ReportPath"];

            if (reportQueueRequest.ReportPath != null && reportQueueRequest.ExportType.ToUpper() == "PDF")
            {
                string fileName = Path.GetFullPath(reportQueueRequest.ReportPath);
                fileExtension = Path.GetExtension(fileName).ToUpper();
            }
            try
            {
                _logger.LogInformation($"ReportQueueProcess {reportQueueRequest.ExportType} creation Start for ReportUsageID {reportQueueRequest.ReportUsageID}");
                if (reportQueueRequest.ExportType.ToUpper() == "PDF")
                {
                    _logger.LogInformation("ReportQueueProcess PDf creation start");
                    CrystalReportsRequest objuserReport = new CrystalReportsRequest();
                    objuserReport.ReportPath = reportQueueRequest.ReportPath;
                    objuserReport.StoredProcedureName = reportQueueRequest.StoredProcedureName;
                    objuserReport.SessionId = reportQueueRequest.SessionId;
                    objuserReport.UserReportId = reportQueueRequest.ReportId;
                    objuserReport.Usage = "|BYUSERREPORT|";
                    objuserReport.reportparameters = reportQueueRequest.ReportParameters;

                    var jsonRequest = JsonConvert.SerializeObject(objuserReport);
                    if (!string.IsNullOrEmpty(fileExtension) && fileExtension.ToUpper() == ".RPT")
                    {
                        pdfStreamDto.pdfStream = await GetCrystalReportStream(jsonRequest);
                    }
                    else if (!string.IsNullOrEmpty(fileExtension) && fileExtension.ToUpper() == ".RDLC")
                    {
                        pdfStreamDto.pdfStream = await GetSSRSReportStream(jsonRequest);
                    }
                    if (pdfStreamDto.pdfStream != null)
                    {
                        try
                        {
                            string st = pdfStreamDto.pdfStream.Trim(new char[] { '"' });
                            byte[] fileBytes = Convert.FromBase64String(st);
                            await _fileServerConnection.UploadFile(filePath + reportQueueRequest.ReportUsageID.Value.ToString() + "\\", reportQueueRequest.ReportUsageID.Value.ToString() + ".pdf", fileBytes);
                            status.StatusRow = new HSPStatusRow { Status = HSPDbStatus.Normal, Success = true };
                        }catch(Exception ex)
                        {
                            var updateReportUsage = new UpdateReportUsageRequest()
                            {
                                ReportUsageID = reportQueueRequest.ReportUsageID,
                                
                            };
                            ErrorMessage = "No Data available for selected queue";
                            var res = _backGroundProcessRepository.UpdateReportUsage(updateReportUsage.ReportUsageID, ErrorMessage);
                            status = await _reportsRepository.UpdateReportUsage(updateReportUsage);
                            _logger.LogInformation(ex,"Something went wrong to upload file line 116.");
                            status.StatusRow = new HSPStatusRow { Status = HSPDbStatus.Normal, Success = false };
                        }
                    }                    
                }
                if (reportQueueRequest.ExportType.ToUpper() != "PDF")
                {
                    DataSet dataSet = _backGroundProcessRepository.GetReportData(reportQueueRequest.ReportParameters, reportQueueRequest.StoredProcedureName, reportQueueRequest.SessionId);                    
                    switch (reportQueueRequest.ExportType.ToUpper())
                    {
                        case "CSV":
                            status = await CreateCSVReports(filePath, dataSet, reportQueueRequest);
                            break;
                        case "XLS":
                            status = await CreateExcelReports(filePath, dataSet, reportQueueRequest);
                            break;
                        case "DOC":
                            status = await CreateDocReports(filePath, dataSet, reportQueueRequest);
                            break;
                    }                    
                    if (status.DbStatus == HSPDbStatus.Normal)
                    {                        
                        await _fileServerConnection.CreateZipFiles(filePath + Convert.ToString(reportQueueRequest.ReportUsageID) + "\\", Convert.ToString(reportQueueRequest.ReportUsageID));
                        _logger.LogInformation("ReportQueueProcess CreateZipFiles Complete");
                    }
                    else
                    {
                        var updateReportUsage = new UpdateReportUsageRequest()
                        {
                            ReportUsageID = reportQueueRequest.ReportUsageID,                           
                           
                        };
                        ErrorMessage = "No Data available for selected queue";
                        var res = _backGroundProcessRepository.UpdateReportUsage(updateReportUsage.ReportUsageID,ErrorMessage);
                    }

                }
                _logger.LogInformation($"ReportQueueProcess {reportQueueRequest.ExportType} creation End for ReportUsageID {reportQueueRequest.ReportUsageID}");
                
                if (status.DbStatus == HSPDbStatus.Normal)
                {
                    (var dbstatus, var result) =await _reportsRepository.GetReportStatus(reportQueueRequest.ReportUsageID.Value);
                    if(dbstatus.DbStatus == HSPDbStatus.Normal )
                    {
                        if (result != null && string.IsNullOrEmpty(result.Status))
                        {
                            var updateReportUsage = new UpdateReportUsageRequest()
                            {
                                ReportUsageID = reportQueueRequest.ReportUsageID,
                                ReportUsageStatus = "CMP",
                                SessionId = reportQueueRequest.SessionId
                            };
                            status = await _reportsRepository.UpdateReportUsage(updateReportUsage);
                            if (status.DbStatus != HSPDbStatus.Normal)
                            {
                                _fileServerConnection.RemoveDirectory(filePath, reportQueueRequest.ReportUsageID.Value.ToString());
                                _logger.LogError(status.ErrorMessage);
                                _logger.LogInformation(status.ErrorMessage + $"Error for ReportUsageID {reportQueueRequest.ReportUsageID.Value}");
                            }
                        }
                        else if(result != null && result.Status.ToUpper() == "CLS")
                        {
                            _fileServerConnection.RemoveDirectory(filePath, reportQueueRequest.ReportUsageID.Value.ToString());
                            _logger.LogInformation($"ReportQueueProcess Deleting Files for {reportQueueRequest.ReportUsageID.Value}");
                        }
                    }
                   
                }
                else
                {
                    var updateReportUsage = new UpdateReportUsageRequest()
                    {
                        ReportUsageID = reportQueueRequest.ReportUsageID,
                        
                    };
                    ErrorMessage = "No Data available for selected queue";
                    var res = _backGroundProcessRepository.UpdateReportUsage(updateReportUsage.ReportUsageID, ErrorMessage);

                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(ReportQueueProcess)}.");
                _logger.LogInformation($"ReportQueueProcess exception for {reportQueueRequest.ReportUsageID.Value}");
            }
            _logger.LogInformation("ReportQueueProcess End");
            return (status);
        }

        /// <summary>
        /// Get report stream
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<string> GetCrystalReportStream(string jsonRequest)
        {
            string docEndpointurl = $"{_configuration["HSP-CS-REPORT-API:ServiceReportUrl"]}{_configuration["HSP-CS-REPORT-API:DownloadReport"]}";
            var data = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            string resultDownload = null;
            try
            {
                // call the crystal report api using HTTP Client Factory
                var client = _clientFactory.CreateClient();
                client.BaseAddress = new Uri(docEndpointurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var requestUri = new Uri(docEndpointurl);
                var responseDownloadReport = await client.PostAsync(requestUri, data);

                resultDownload = await responseDownloadReport.Content.ReadAsStringAsync();
            }
            catch(Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetCrystalReportStream)}.");
                throw;
            }
            return resultDownload;
        }

        /// <summary>
        /// Get SSRS Reprt stream
        /// </summary>
        /// <param name="jsonRequest"></param>
        /// <returns></returns>
        public async Task<string> GetSSRSReportStream(string jsonRequest)
        {
            string docEndpointurl = $"{_configuration["HSP-CS-REPORT-API:ServiceReportUrl"]}{_configuration["HSP-CS-REPORT-API:DownloadSSRSReport"]}";
            var data = new StringContent(jsonRequest, Encoding.UTF8, "application/json");
            string resultDownload = null;
            try
            {
                // call the SSRS report api using HTTP Client Factory
                var client = _clientFactory.CreateClient();
                client.BaseAddress = new Uri(docEndpointurl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var requestUri = new Uri(docEndpointurl);
                var responseDownloadReport = await client.PostAsync(requestUri, data);
                resultDownload = await responseDownloadReport.Content.ReadAsStringAsync();
            }
            catch(Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetSSRSReportStream)}.");
                throw;
            }
            return resultDownload;
        }
        /// <summary>
        /// Create CSV Report
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="dataSet"></param>
        /// <param name="reportQueueRequest"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> CreateCSVReports(string filePath, DataSet dataSet, ReportQueueRequest reportQueueRequest)
        {
            byte[] fileBytes = null;
            var dbResult = new HSPDbResult<HSPStatusRow>();
            try
            {
                if (dataSet != null && dataSet.Tables != null && dataSet.Tables.Count > 0)
                {
                    foreach (DataTable dataTable in dataSet.Tables)
                    {
                        fileBytes = ReportGenerationHelper.CreateCSVFile(dataTable, reportQueueRequest.ReportColumns);
                        string fileName = ReportGenerationHelper.GenerateReportName(dataTable.TableName, dataSet.Tables.Count, reportQueueRequest.ExportType);
                        string path = filePath + reportQueueRequest.ReportUsageID.Value.ToString() + "\\";
                        await _fileServerConnection.UploadFile(path, fileName, fileBytes);
                    }
                    dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.Normal, Success = true };
                }
                else
                {
                    dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.BusinessError, Success = false };
                    _logger.LogInformation($"No data available for {reportQueueRequest.ReportUsageID}");
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(CreateCSVReports)}.");
                dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.ApiError, Success = false };
                dbResult.ErrorMessage = exception.Message;
                throw;
            }
           
            return (dbResult);
        }
        /// <summary>
        /// Create Excel Reports
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="dataSet"></param>
        /// <param name="reportQueueRequest"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> CreateExcelReports(string filePath, DataSet dataSet, ReportQueueRequest reportQueueRequest)
        {
            byte[] fileBytes = null;
            var dbResult = new HSPDbResult<HSPStatusRow>();
            try
            {
                if (dataSet != null && dataSet.Tables != null && dataSet.Tables.Count > 0)
                {
                    foreach (DataTable dataTable in dataSet.Tables)
                    {
                        fileBytes = ReportGenerationHelper.CreateExcel(dataTable, reportQueueRequest.ReportColumns);
                        string fileName = ReportGenerationHelper.GenerateReportName(dataTable.TableName, dataSet.Tables.Count, reportQueueRequest.ExportType);
                        string path = filePath + reportQueueRequest.ReportUsageID.Value.ToString() + "\\";
                        await _fileServerConnection.UploadFile(path, fileName, fileBytes);
                    }
                }
                else
                {
                    dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.BusinessError, Success = false };
                    _logger.LogInformation($"No data available for {reportQueueRequest.ReportUsageID}");
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(CreateExcelReports)}.");
                dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.ApiError, Success = false };
                dbResult.ErrorMessage = exception.Message;
                throw;
            }
            dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.Normal, Success = true };
            return (dbResult);
        }
        /// <summary>
        /// Create Doc Reports
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="dataSet"></param>
        /// <param name="reportQueueRequest"></param>
        /// <returns></returns>
        public async Task<HSPDbResult<HSPStatusRow>> CreateDocReports(string filePath, DataSet dataSet, ReportQueueRequest reportQueueRequest)
        {
            byte[] fileBytes = null;
            var dbResult = new HSPDbResult<HSPStatusRow>();
            try
            {
                if (dataSet != null && dataSet.Tables != null && dataSet.Tables.Count > 0)
                {
                    foreach (DataTable dataTable in dataSet.Tables)
                    {
                        fileBytes = ReportGenerationHelper.CreateDOC(dataTable, reportQueueRequest.ReportColumns);
                        string fileName = ReportGenerationHelper.GenerateReportName(dataTable.TableName, dataSet.Tables.Count, reportQueueRequest.ExportType);
                        string path = filePath + reportQueueRequest.ReportUsageID.Value.ToString() + "\\";
                        await _fileServerConnection.UploadFile(path, fileName, fileBytes);
                    }
                }
                else
                {
                    dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.BusinessError, Success = false };
                    _logger.LogInformation($"No data available for {reportQueueRequest.ReportUsageID}");
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(CreateDocReports)}.");
                dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.ApiError, Success = false };
                dbResult.ErrorMessage = exception.Message;
                throw;
            }
            dbResult.StatusRow = new HSPStatusRow { Status = HSPDbStatus.Normal, Success = true };
            return (dbResult);
        }
    }
}
