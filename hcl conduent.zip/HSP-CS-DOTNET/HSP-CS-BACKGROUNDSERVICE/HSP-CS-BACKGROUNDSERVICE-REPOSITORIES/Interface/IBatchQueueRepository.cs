﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface
{
    public interface IBatchQueueRepository
    {
        DataSet GetReportData(object objectParam, string storeProcedureName, int? SessionID);
        bool UpdateFormLetter(int? RowID, int BatchID, string OutPutStatus, string ErrorMessage);
    }
}
