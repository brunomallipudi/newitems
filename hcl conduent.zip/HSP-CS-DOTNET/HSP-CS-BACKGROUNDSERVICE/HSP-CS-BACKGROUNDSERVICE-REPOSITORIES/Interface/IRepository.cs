﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface
{
    public interface IRepository
    {
        DataSet GetReportData(object objectParam, string storeProcedureName, int? SessionID);
        List<string> GetTableNamesFromResultset(DataSet reportDataSet, bool removeStatusLineTable);
        bool UpdateData(SqlCommand cmd);
    }
}
