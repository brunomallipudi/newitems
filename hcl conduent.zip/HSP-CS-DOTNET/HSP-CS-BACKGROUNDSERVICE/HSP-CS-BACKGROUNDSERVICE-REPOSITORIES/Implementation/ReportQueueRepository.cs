﻿using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Implementation
{
    public class ReportQueueRepository : IReportQueueRepository
    {
        private readonly IConfiguration _configuration;        
        private readonly IRepository _repository;

        /// <summary>
        /// Report Queue Repository
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="ConnectionString"></param>
        /// <param name="repository"></param>
        public ReportQueueRepository(IConfiguration configuration, IDbConnectionString ConnectionString, IRepository repository) //: base(configuration, ConnectionString)
        {
            _configuration = configuration;            
            _repository = repository;
        }

        /// <summary>
        /// Get Report Data
        /// </summary>
        /// <param name="objectParam"></param>
        /// <param name="storeProcedureName"></param>
        /// <param name="SessionID"></param>
        /// <returns></returns>
        public DataSet GetReportData(object objectParam, string storeProcedureName, int? SessionID)
        {
            DataSet ds = _repository.GetReportData(objectParam, storeProcedureName, SessionID);
            List<string> tableNames = _repository.GetTableNamesFromResultset(ds, true);
            for (int i = 0; i < tableNames.Count; i++)
            {
                ds.Tables[i].TableName = tableNames[i];
            }
            return ds;
        }
        public bool UpdateReportUsage(int? ReportUsageId,string ErrorMessage)
        {
            string strQuery1;            
            SqlCommand cmd1;           
            strQuery1 = "update ReportUsage set ErrorMessage=@ErrorMessage,EndTime=@EndTime  where ReportUsageID=@ReportUsageID";
            
            cmd1 = new SqlCommand(strQuery1);
            cmd1.Parameters.AddWithValue("@ErrorMessage", ErrorMessage);
            cmd1.Parameters.AddWithValue("@ReportUsageID", ReportUsageId);
            cmd1.Parameters.AddWithValue("@EndTime", DateTime.Now);
            bool i = _repository.UpdateData(cmd1);
            if (i == true)
            {
                return i;
            }
            return false;
        }
    }
}
