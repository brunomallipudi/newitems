﻿using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Implementation
{
    public class Repository : IRepository
    {
        private readonly IConfiguration _configuration;
        private IDbConnectionString _ConnectionString;
        private readonly SqlConnection dbConnection;
        private const string TOTALRESULTSETS = "TotalResultSets";
        private const string RESULTSET_PREFIX = "Resultset{0}";
        private const string BYTABLE = "ByTable";
        private const string BYDATABASECONTROLLER = "ByDatabaseController";
        private readonly ILogger<Repository> _logger;

        /// <summary>
        /// Data Base Repository
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="ConnectionString"></param>
        /// <param name="logger"></param>
        public Repository(IConfiguration configuration, IDbConnectionString ConnectionString, ILogger<Repository> logger)
        {
            _configuration = configuration;
            _ConnectionString = ConnectionString;
            dbConnection = new SqlConnection(_ConnectionString.DefaultConnectionString);
            _logger = logger;
        }

        /// <summary>
        /// Get Report Data
        /// </summary>
        /// <param name="objectParam"></param>
        /// <param name="storeProcedureName"></param>
        /// <param name="SessionID"></param>
        /// <returns>DataSet</returns>
        public DataSet GetReportData(object objectParam, string storeProcedureName, int? SessionID)
        {
            DataSet ds = new DataSet();
            try
            {
                dbConnection.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = dbConnection;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = storeProcedureName;

                var jsonRequest = JsonConvert.SerializeObject(objectParam);
                Dictionary<string, object> dictParameters = new Dictionary<string, object>();
                dictParameters = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonRequest);

                SqlParameter SessionId = new SqlParameter("@SessionId", SessionID);
                cmd.Parameters.Add(SessionId);
                if (dictParameters != null)
                {
                    foreach (KeyValuePair<string, object> p in dictParameters)
                    {
                        cmd.Parameters.AddWithValue("@" + p.Key, (p.Value.ToString().Length == 0) ? DBNull.Value.ToString() : p.Value);
                    }
                }
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                var reader = cmd.ExecuteReader();

                if (reader != null && !reader.IsClosed)
                {
                    ds = new DataSet();
                    while (!reader.IsClosed)
                    {
                        DataTable dtData = new DataTable();
                        dtData.Load(reader);
                        ds.Tables.Add(dtData);
                    }
                }
                da.Dispose();
                dbConnection.Close();
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetReportData)}.");
            }
            return ds;
        }

        /// <summary>
        /// Get Table Names
        /// </summary>
        /// <param name="reportDataSet"></param>
        /// <param name="removeStatusLineTable"></param>
        /// <returns>List<string></returns>
        public List<string> GetTableNamesFromResultset(DataSet reportDataSet, bool removeStatusLineTable)
        {
            List<string> resultList = new List<string>();
            DataTable dataTable = null;
            DataRow dataRow = null;
            try
            {
                if (reportDataSet.Tables.Count > 0 && reportDataSet.Tables[0].Rows.Count > 0)
                {
                    dataTable = reportDataSet.Tables[0];
                    dataRow = dataTable.Rows[0];
                    if (reportDataSet.Tables[0].Columns.Contains(TOTALRESULTSETS))
                    {
                        int totalRS = (int)dataRow[TOTALRESULTSETS];
                        for (int i = 1; i <= totalRS; i++)
                        {
                            if (dataTable.Columns.Contains(string.Format(RESULTSET_PREFIX, i))
                            && dataRow[string.Format(RESULTSET_PREFIX, i)] != null)
                            {
                                resultList.Add(dataRow[string.Format(RESULTSET_PREFIX, i)].ToString());
                            }
                        }
                    }
                }
                // Remove row 0 so that the table count will work out more easily in the SetReportDataSource method
                if (removeStatusLineTable)
                {
                    reportDataSet.Tables.RemoveAt(0);
                }
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, $"Exception in {nameof(GetTableNamesFromResultset)}.");
            }
            return resultList;
        }

        public bool UpdateData(SqlCommand cmd)
        {
           SqlConnection Connection = new SqlConnection(_ConnectionString.DefaultConnectionString);
            Connection.Open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = Connection;
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, $"Exception in {nameof(UpdateData)}.");
                return false;
            }

            finally
            {
                Connection.Close();
                Connection.Dispose();

            }

        }
    }
}
