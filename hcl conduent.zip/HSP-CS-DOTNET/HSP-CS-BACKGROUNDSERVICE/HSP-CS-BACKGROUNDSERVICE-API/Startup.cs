using HSP_CS_BACKGROUNDSERVICE;
using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Implementation;
using HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Helpers;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Implementation;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_COMMON_CORE.Enums;
using HSP_CS_COMMON_CORE.Infrastructure.Implementation;
using HSP_CS_COMMON_CORE.Infrastructure.Interfaces;
using HSP_CS_COMMON_CORE.ResultHandling;
using HSP_CS_COMMON_HELPERS.Security;
using HSP_CS_COMMON_REPOSITORIES.Implementation;
using HSP_CS_COMMON_REPOSITORIES.Interfaces;
using HSP_CS_COMMON_SERVICES.Implementation.Cache;
using HSP_CS_COMMON_SERVICES.Implementation.Infrastructure;
using HSP_CS_COMMON_SERVICES.Interfaces.Cache;
using HSP_CS_COMMON_SERVICES.Interfaces.Infrastructure;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System;
using System.Linq;

namespace HSP_CS_BACKGROUNDSERVICE_API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();

            services.AddSingleton<IDbConnectionString>(new DbConnectionString(Configuration.GetConnectionString("HSPCSUIDB")));
            services.AddScoped<IDbConnectionTester, DbConnectionTester>();            
            services.AddSingleton<IBatchQueueService, BatchQueueService>();
            services.AddSingleton<IReportQueueService, ReportQueueService>();
            services.AddSingleton<IReportQueueRepository, ReportQueueRepository>();
            services.AddSingleton<IBatchQueueRepository, BatchQueueRepository>();
            services.AddSingleton<IFormLettersRepository, FormLettersRepository>();
            services.AddSingleton<IUserReportsRepository, UserReportsRepository>();
            services.AddSingleton<HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Interface.IRepository, HSP_CS_BACKGROUNDSERVICE_REPOSITORIES.Implementation.Repository>();
            services.AddSingleton<IFileServerService, NetworkConnection>();
            services.AddSingleton<IReportsRepository, ReportsRepository>();

            services.AddHostedService<KafkaConsumerService>();

            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddScoped<IUrlHelper>(x =>
            {
                var actionContext = x.GetRequiredService<IActionContextAccessor>().ActionContext;
                var factory = x.GetRequiredService<IUrlHelperFactory>();
                return factory.GetUrlHelper(actionContext);
            });

            // Entity Framework            
            services.AddDbContext<HSPDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("HSPCSUIDB")), ServiceLifetime.Transient, ServiceLifetime.Singleton);


            services.AddTransient<ICacheService, MemoryCacheService>();
            services.AddMemoryCache();
            services.AddHttpClient();
            services.AddAutoMapper(typeof(Startup));

            JwtServiceHelper.AddJwtAuthentication(Configuration, services);

            services.AddControllers()
                    .AddNewtonsoftJson();

            services.AddControllers()
                    .AddNewtonsoftJson()
                    .ConfigureApiBehaviorOptions(options =>
                    {
                        options.InvalidModelStateResponseFactory = context =>
                        {
                            string errorMessage = context.ModelState.Values.FirstOrDefault()?.Errors.FirstOrDefault()?.ErrorMessage
                                                        ?? "A bad request error has occurred";

                            var dbResult = new HSPDbResult<HSPStatusRow>
                            {
                                StatusRow = new HSPStatusRow
                                {
                                    Success = false,
                                    Status = HSPDbStatus.ApiBadRequestError,
                                    ErrorMessage = errorMessage,
                                    IsCached = false
                                },
                                ErrorMessage = errorMessage
                            };

                            return new OkObjectResult(dbResult);
                        };
                    });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "HSP_CS_BACKGROUNDSERVICE", Version = "v1" });

                var securityScheme = new OpenApiSecurityScheme
                {
                    Name = "JWT token",
                    Description = "Enter JWT Bearer token",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    Reference = new OpenApiReference
                    {
                        Id = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme,
                        Type = ReferenceType.SecurityScheme
                    }
                };

                c.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {securityScheme, new string[] { }}
                });

                c.MapType<object>(() => new OpenApiSchema { Type = "object", Nullable = true });
            });

            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "HSP_CS_BACKGROUNDSERVICE v1"));
            }

            app.UseExceptionHandler("/error");
            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors
            (
                x => x
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .SetIsOriginAllowed(origin => true)
                    .AllowCredentials()
            );

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
