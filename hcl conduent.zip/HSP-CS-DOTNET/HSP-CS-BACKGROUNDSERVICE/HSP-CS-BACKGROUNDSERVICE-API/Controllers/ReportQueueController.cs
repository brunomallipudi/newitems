﻿using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace HSP_CS_BACKGROUNDSERVICE_API.Controllers
{
    [Route("[Controller]")]
    [ApiController]
    public class ReportQueueController : ControllerBase
    {
        private readonly IReportQueueService _reportQueueService;
        private readonly ILogger<ReportQueueController> _logger;
        public ReportQueueController(IReportQueueService reportQueueService, ILogger<ReportQueueController> logger)
        {
            _reportQueueService = reportQueueService;
            _logger = logger;
        }

        [HttpPost]
        [Route("ReportQueueProcess")]
        public async Task<IActionResult> ReportQueueProcess(ReportQueueRequest reportQueueRequest)
        {
            _logger.LogInformation("ReportQueueProcess in ReportQueueController Start");
            await _reportQueueService.ReportQueueProcess(reportQueueRequest);
            _logger.LogInformation("ReportQueueProcess in ReportQueueController End");
            return Ok();
        }
    }
}
