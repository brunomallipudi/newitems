﻿using HSP_CS_BACKGROUNDSERVICE_SERVICES.Interfaces;
using HSP_CS_BACKGROUNDSERVICE_SERVICES.Request.Batch;
using Microsoft.AspNetCore.Mvc;

namespace HSP_CS_BACKGROUNDSERVICE_API.Controllers
{
    [Route("[Controller]")]
    [ApiController]
    public class BatchQueueController : ControllerBase
    {
        private readonly IBatchQueueService _batchQueueService;
        public BatchQueueController(IBatchQueueService batchQueueService)
        {
            _batchQueueService = batchQueueService;
        }
        [HttpPost]
        [Route("BatchQueueProcess")]
        public IActionResult BatchQueueProcess(BatchQueueProcessRequest parameters)
        {
            _batchQueueService.BatchQueueProcess(parameters);
            return Ok();
        }
    }
}
